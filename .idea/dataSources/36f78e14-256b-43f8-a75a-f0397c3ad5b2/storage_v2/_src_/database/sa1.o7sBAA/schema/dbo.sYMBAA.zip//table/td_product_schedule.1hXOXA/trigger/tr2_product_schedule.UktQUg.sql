
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：生産スケジュールデータの展開トリガ(DELETE)
* トリガ名		：TR2_PRODUCT_SCHEDULE
* 概要          ：生産スケジュールデータにDELETEされた内容を計画値データへ展開
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/09/18
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR2_PRODUCT_SCHEDULE] ON [dbo].[TD_PRODUCT_SCHEDULE] AFTER DELETE
AS
BEGIN

	DECLARE @Equipment_No as int
	DECLARE @Product_Plan_Date as date
	DECLARE @Manu_Order as int

	DECLARE Delete_Sch CURSOR FOR
	SELECT Equipment_No,Product_Plan_Date,Manu_Order
	FROM DELETED

	--カーソルをオープンし、内容を確認
	OPEN Delete_Sch

	--行の取り出し
	FETCH NEXT FROM Delete_Sch INTO @Equipment_No,@Product_Plan_Date,@Manu_Order

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--対応する計画値データを削除する
			DELETE TD_TARGET_VALUE WHERE Equipment_No = @Equipment_No 
				AND Start_Date = @Product_Plan_Date AND Manu_Order = @Manu_Order

			--行の取り出し
			FETCH NEXT FROM Delete_Sch INTO @Equipment_No,@Product_Plan_Date,@Manu_Order

		END
	
	--カーソルを閉じる
	CLOSE Delete_Sch
	DEALLOCATE Delete_Sch

END

go

