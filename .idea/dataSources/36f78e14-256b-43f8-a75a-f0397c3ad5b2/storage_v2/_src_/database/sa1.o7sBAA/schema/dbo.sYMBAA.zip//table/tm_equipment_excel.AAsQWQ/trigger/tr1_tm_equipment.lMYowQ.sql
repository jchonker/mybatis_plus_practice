
/***********************************************************************************
*
* 製品名        ：上位システム連携機能
* 処理名        ：装置設定　展開用トリガ(INSERT用)
* トリガ名		：TR1_TM_EQUIPMENT
* 概要          ：TM_EQUIPMENT_EXCLE→TM_EQUIPMENT_INFO、TM_EQUIPMENT_NAMEへの展開(INSERT)
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/12/19
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR1_TM_EQUIPMENT] ON [dbo].[TM_EQUIPMENT_EXCEL] AFTER INSERT 
AS
BEGIN

	DECLARE @Equipment_No as int
	DECLARE @Lang_Mode as tinyint
	DECLARE @Unit_No as int
	DECLARE @Collection_Mode as tinyint
	DECLARE @Group_No as int
	DECLARE @Item_No as int
	DECLARE @Tag_No as bigint
	DECLARE @Decimal_Place as int
	DECLARE @Equipment_Name as varchar(32)
	DECLARE @Abbreviation_Name as varchar(8)

	DECLARE @Chk_Equipment as int
	DECLARE @Insert_Flg as tinyint

	DECLARE @COLLECT_MODE_TAG as int

	--初期化
	set @COLLECT_MODE_TAG = 1

	DECLARE InsertData CURSOR FOR
	SELECT Equipment_No, Lang_Mode, Unit_No, Collection_Mode, Group_No, Item_No, Decimal_Place, 
		Equipment_Name, Abbreviation_Name
	FROM INSERTED

    --カーソルをオープンし、内容を確認
    OPEN InsertData
    
    --行の取り出し
    FETCH NEXT FROM InsertData INTO @Equipment_No, @Lang_Mode, @Unit_No, @Collection_Mode, @Group_No, @Item_No, 
		@Decimal_Place, @Equipment_Name, @Abbreviation_Name
    
    --ループ処理
    WHILE (@@FETCH_STATUS = 0)
    	BEGIN
    		--初期化
			SET @Tag_No = 0

			--フラグ初期化
			SET @Insert_Flg = 1

			--装置情報マスタに既にデータが存在するかを確認する
			DECLARE ChkData CURSOR FOR
			SELECT Equipment_No
			FROM TM_EQUIPMENT_INFO
			WHERE Equipment_No = @Equipment_No

			--カーソルをオープンし、内容を確認
			OPEN ChkData

			--行の取り出し
			FETCH NEXT FROM ChkData INTO @Chk_Equipment

			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					--フラグに0をセット(既にデータあり(他の言語設定値))
					SET @Insert_Flg = 0

					--行の取り出し
					FETCH NEXT FROM ChkData INTO @Chk_Equipment
				END

			--収集種別の確認
			IF (@Collection_Mode = @COLLECT_MODE_TAG)
				BEGIN
					--タグNo.の生成
					set @Tag_No =CONVERT(bigint, convert(varchar(3), @Group_No) + right('0000000' + convert(varchar(10), @Item_No),7) + '00')

				END

			--装置情報マスタへの展開有無チェック
			IF(@Insert_Flg = 1)
				BEGIN
					--装置情報設定(TM_EQUIPMENT_INFO)への展開
					INSERT INTO TM_EQUIPMENT_INFO (Equipment_No, Unit_No, Collection_Mode, Group_No, Item_No, Tag_No, Decimal_Place, Last_Update)
						VALUES (@Equipment_No, @Unit_No, @Collection_Mode, @Group_No, @Item_No, @Tag_No, @Decimal_Place,GETDATE())
				END
			ELSE
				BEGIN
					--後で登録しようとした内容へ更新する
					UPDATE TM_EQUIPMENT_INFO SET Unit_No = @Unit_No,Collection_Mode = @Collection_Mode,Group_No = @Group_No,Item_No = @Item_No,
						Tag_No = @Tag_No,Decimal_Place = @Decimal_Place,Last_Update = GETDATE()
					WHERE Equipment_No = @Equipment_No

				END
		
			--装置名称設定(TM_EQUIPMENT_NAME)への展開
			INSERT INTO TM_EQUIPMENT_NAME (Equipment_No, Lang_Mode, Equipment_Name, Abbreviation_Name, Last_Update)
				VALUES (@Equipment_No, @Lang_Mode, @Equipment_Name, @Abbreviation_Name,GETDATE())

    		--次の行へ移動
		    FETCH NEXT FROM InsertData INTO @Equipment_No, @Lang_Mode, @Unit_No, @Collection_Mode, @Group_No, @Item_No, 
				@Decimal_Place, @Equipment_Name, @Abbreviation_Name

			--カーソルを閉じる
			CLOSE ChkData
			DEALLOCATE ChkData
    
    	END
    --カーソルを閉じる
    CLOSE InsertData
    DEALLOCATE InsertData

END

go

