
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：計画値反映トリガ
* トリガ名		：TR_TD_TARGET_VALUE
* 概要          ：計画値データテーブルから装置製造状況データへの展開
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2017/02/23
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR_TD_TARGET_VALUE] ON [dbo].[TD_TARGET_VALUE] AFTER INSERT 
AS
BEGIN
	
	DECLARE @Equipment_No AS int				--装置No.
	DECLARE @Kind_Name as varchar(40)			--品目コード
	DECLARE @Kind_Class as varchar(40)			--品目区分
	DECLARE @Kind_Priority as bigint			--シーケンスNo.
	DECLARE @Start_Date as datetime				--収集日時
	DECLARE @Production_Cost as int
	DECLARE @Target_Value as float
	DECLARE @Target_No as bigint
	DECLARE @Sch_No as bigint

	--INSERTされた行から各種情報を取得
	SELECT	@Equipment_No = Equipment_No,
			@Kind_Name = Kind_Name,
			@Kind_Class = Kind_Class,
			@Kind_Priority = Kind_Priority,
			@Start_Date = Start_Date,
			@Production_Cost = Production_Cost,
			@Target_Value = Target_Value,
			@Target_No = Target_No,
			@Sch_No = Sch_No
	FROM INSERTED

	--現在の値確認

	DECLARE @E_Equipment_No as integer
	DECLARE @E_Collect_Date as datetime
	DECLARE @E_Kind_Name as varchar(40)
	DECLARE @E_Kind_Class as varchar(40)
	DECLARE @E_Kind_Priority as bigint
	DECLARE @E_Inst_No as bigint
	DECLARE @E_Target_Value as float
	DECLARE @E_Target_No as bigint
	DECLARE @E_Production_Cost as int
	DECLARE @Old_E_Data as tinyint

	--初期化
	SET @Old_E_Data = 0

	--前回値有無チェック
	DECLARE Old_EquData CURSOR FOR 
	SELECT Equipment_No,Collect_Date,Kind_Name,Kind_Class,Kind_Priority,Inst_No,Target_Value,Target_No,Production_Cost
	FROM TD_EQUIPMENT_STATUS
	WHERE Equipment_No = @Equipment_No

	--カーソルをオープンし、内容を確認
	OPEN Old_EquData

	--行の取りだし
	FETCH NEXT FROM Old_EquData INTO @E_Equipment_No,@E_Collect_Date,@E_Kind_Name,@E_Kind_Class,@E_Kind_Priority,
		@E_Inst_No,@E_Target_Value,@E_Target_No,@E_Production_Cost
	
	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--前回値取得済み
			SET @Old_E_Data = 1

			--行の取りだし
			FETCH NEXT FROM Old_EquData INTO @E_Equipment_No,@E_Collect_Date,@E_Kind_Name,@E_Kind_Class,@E_Kind_Priority,
				@E_Inst_No,@E_Target_Value,@E_Target_No,@E_Production_Cost
		END
	--カーソルを閉じる
	CLOSE Old_EquData
	DEALLOCATE Old_EquData

	--データ取得チェック
	IF(@Old_E_Data = 1)
		BEGIN
			--現在の状態と状況が一致すれば内容を更新する
			IF ((@E_Equipment_No = @Equipment_No) AND (@E_Kind_Name = @Kind_Name) AND (@E_Kind_Class = @Kind_Class) AND 
				(@E_Kind_Priority = @Kind_Priority) AND (@Start_Date = CONVERT(date,@E_Collect_Date)) )
				BEGIN
					--計画値の更新を行う
					UPDATE TD_EQUIPMENT_STATUS SET Target_Value = @Target_Value,Target_No = @Target_No,Production_Cost = @Production_Cost
					WHERE Equipment_No = @Equipment_No
				END
		END
END

go

