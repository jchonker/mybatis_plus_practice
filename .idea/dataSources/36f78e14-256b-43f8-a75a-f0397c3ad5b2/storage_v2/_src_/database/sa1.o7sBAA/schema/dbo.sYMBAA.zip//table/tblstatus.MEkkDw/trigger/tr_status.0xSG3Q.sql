
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：状態履歴データ作成トリガ
* トリガ名		：TR_STATUS
* 概要          ：操作状態一覧テーブルから状態履歴データへの展開
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/10/21
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR_STATUS] ON [dbo].[TBLSTATUS] AFTER INSERT 
AS
BEGIN
	DECLARE @Node_ID as int						--ノードID
	DECLARE @Tag_No as bigint					--タグNo.
	DECLARE @Get_Date as datetime				--取得日時
	DECLARE @Get_Description as nvarchar(64)	--内容
	DECLARE @EquipmentNo as int					--装置No.
	DECLARE @Status_No as int
	DECLARE @tmpNum as int
	DECLARE @Collection_Mode as int

	DECLARE @Kind_Name as varchar(40)			--品目コード
	DECLARE @Kind_Class as varchar(40)			--品目区分
	DECLARE @tmp_Kind_Name as varchar(40)	--テンポラリ(品目コード)
	DECLARE @tmp_Kind_Class as varchar(40)	--テンポラリ(品目区分)

	DECLARE @MODE_MEU as int
	DECLARE @MODE_SEU as int

	SET @MODE_MEU = 1
	SET @MODE_SEU = 3

	SET @Status_No = -1

	--INSERTされた行から各種情報を取得
	SELECT	@Node_ID = NodeId,
			@Tag_No = TagNo,
			@Get_Date = tmDate,
			@Get_Description = szDescription
	FROM INSERTED;
	
	--装置情報マスタより装置情報を取得
	DECLARE MasterData CURSOR FOR
	SELECT Equipment_No,Collection_Mode
	FROM TM_EQUIPMENT_INFO
	WHERE Collection_Mode in (@MODE_MEU,@MODE_SEU)
	  AND Group_No = @Node_ID
	  AND Tag_No = @Tag_No

	--カーソルをオープンし、内容を確認
	OPEN MasterData

	--行の取り出し(装置No.)
	FETCH NEXT FROM MasterData INTO @EquipmentNo,@Collection_Mode

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--初期化
			SET @tmp_Kind_Name = ''
			SET @tmp_Kind_Class = ''
			SET @Kind_Name = ''
			SET @Kind_Class = ''

			--【取得データあり】

			IF(@Collection_Mode = @MODE_SEU)
				BEGIN
					--セレクトパターン名称が一致する稼働状態を取得する
					DECLARE GetStatus CURSOR FOR
					SELECT Status_No
					FROM TM_STATUS_NAME
					WHERE Disp_Chara = @Get_Description

					OPEN GetStatus

					FETCH NEXT FROM GetStatus INTO @tmpNum

					WHILE (@@FETCH_STATUS = 0)
						BEGIN
							SET @Status_No = @tmpNum

							FETCH NEXT FROM GetStatus INTO @tmpNum
						END

					--カーソルを閉じる
					CLOSE GetStatus
					DEALLOCATE GetStatus

					if(@Status_No = -1)
						BEGIN
							--データが取得できなかったため、処理を抜ける
							goto Next_Loop
						END
				END
			ELSE IF(@Collection_Mode = @MODE_MEU)
				BEGIN
					--取得した文字を数値型に変換
					set @Status_No = CONVERT(int,@Get_Description)

					--数値チェック
					if(@Status_No > 10)
						BEGIN 
							goto Next_Loop
						END
				END
			ELSE
				BEGIN
					goto Next_Loop
				END

			--前回値データをチェックし、前回値データが存在する場合、
			--状態変化時間を演算し、内容を更新する。
			
			DECLARE @OldDate as datetime
			
			DECLARE OldStatusData CURSOR FOR
			SELECT TOP(1) Collect_Date
			FROM TD_COLLECT_STATUS
			WHERE Equipment_No = @EquipmentNo
			ORDER BY Collect_Date DESC
			
			--カーソルをオープンし、内容を確認
			OPEN OldStatusData
			
			--行の取り出し(収集日時)
			FETCH NEXT FROM OldStatusData INTO @OldDate
			
			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					DECLARE @TimeInterval as int
					
					--時間差を求める
					SET @TimeInterval = datediff(SECOND,@OldDate,@Get_Date)
					
					--時刻戻り時には0を書込む(マイナス値となるため）
					IF (@TimeInterval < 0)
						BEGIN
							SET @TimeInterval = 0
						
						END
					
					--=====================================================st 状態変化時間0秒対応 20170929 takasima
					----データベースの内容を更新する
					--UPDATE TD_Collect_STATUS SET Status_Time = @TimeInterval,Last_Update = GETDATE()
					--WHERE Equipment_No = @EquipmentNo AND Collect_Date = @OldDate


					--0秒確認
					IF (@TimeInterval = 0)
						BEGIN
							--前回のデータを削除する
							DELETE FROM TD_Collect_STATUS WHERE Equipment_No = @EquipmentNo AND Collect_Date = @OldDate
						
						END
					ELSE
						BEGIN
							--データベースの内容を更新する
							UPDATE TD_Collect_STATUS SET Status_Time = @TimeInterval,Last_Update = GETDATE()
							WHERE Equipment_No = @EquipmentNo AND Collect_Date = @OldDate
						END

					--=====================================================ed 状態変化時間0秒対応 20170929 takasima
					
					--次の行へ移動
					FETCH NEXT FROM OldStatusData INTO @OldDate
				END
			--カーソルを閉じる
			CLOSE OldStatusData
			DEALLOCATE OldStatusData

			DECLARE @GetFlg AS int				--操作履歴データ取得フラグ
			DECLARE @OldStatus_No AS tinyint		--状態No.
			
			--初期化
			SET @GetFlg = 0
			
			--同一時刻に変化していたかを確認
			DECLARE curGetStatus CURSOR FOR
			SELECT Status_No
			FROM TD_COLLECT_STATUS
			WHERE Equipment_No = @EquipmentNo
			  AND Collect_Date = @Get_Date
			
			--カーソルをオープンし、内容を確認
			OPEN curGetStatus
			
			--行の取り出し
			FETCH NEXT FROM curGetStatus INTO @OldStatus_No
					
			--処理の繰り返し
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					--既に同じ時刻の操作履歴データあり
					SET @GetFlg = 1

					--行の取り出し
					FETCH NEXT FROM curGetStatus INTO @OldStatus_No
				END

			--カーソルを閉じる
			CLOSE curGetStatus
			DEALLOCATE curGetStatus
			
			DECLARE curGet_Kind CURSOR FOR
			SELECT TOP(1) Kind_Name,Kind_Class
			FROM TD_COLLECT_HOUR_VALUE
			WHERE Equipment_No = @EquipmentNo
				AND Manufact_Flg = 1
				AND Collect_Date <= @Get_Date
			
			--カーソルをオープンし、内容を確認
			OPEN curGet_Kind

			--行の取り出し
			FETCH NEXT FROM curGet_Kind INTO @tmp_Kind_Name,@tmp_Kind_Class

			--処理の繰り返し
			WHILE (@@FETCH_STATUS = 0)
				BEGIN 
					--取得した内容を反映
					SET @Kind_Name = @tmp_Kind_Name
					SET @Kind_Class = @tmp_Kind_Class

					--行の取り出し
					FETCH NEXT FROM curGet_Kind INTO @tmp_Kind_Name,@tmp_Kind_Class
				END
			--カーソルを閉じる
			CLOSE curGet_Kind
			DEALLOCATE curGet_Kind

			--フラグチェック
			IF (@GetFlg = 0)
				BEGIN
					--状態履歴データにデータをInsert
					INSERT INTO TD_COLLECT_STATUS (Equipment_No,Collect_Date,Status_No,Kind_Name,Kind_Class,Last_Update) 
					VALUES (@EquipmentNo,@Get_Date,@Status_No,@Kind_Name,@Kind_Class,GETDATE())
				END
			ELSE
				BEGIN
					--既にデータが存在するため、上書きする

					--状態履歴データにデータをUpdate
					UPDATE TD_COLLECT_STATUS SET Status_No = @Status_No,Kind_Name = @Kind_Name,Kind_Class = @Kind_Class
					WHERE Equipment_No = @EquipmentNo AND Collect_Date = @Get_Date
				END
Next_Loop:
			--次の行へ移動(装置No.)
			FETCH NEXT FROM MasterData INTO @EquipmentNo,@Collection_Mode
		END

proc_end:
	--カーソルを閉じる
	CLOSE MasterData
	DEALLOCATE MasterData

END

go

