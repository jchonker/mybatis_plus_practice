
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：生産スケジュールデータの展開トリガ(INSERT)
* トリガ名		：TR1_PRODUCT_SCHEDULE
* 概要          ：生産スケジュールデータにINSERTされた内容を計画値データへ展開
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/09/18
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR1_PRODUCT_SCHEDULE] ON [dbo].[TD_PRODUCT_SCHEDULE] AFTER INSERT
AS
BEGIN
	
	DECLARE @Equipment_No as int
	DECLARE @Product_Plan_Date as date
	DECLARE @Manu_Order as int
	DECLARE @Manu_Count as float
	DECLARE @Inst_Row_No as bigint
	DECLARE @Sch_No as bigint

	DECLARE @Kind_Name as varchar(40)
	DECLARE @Kind_Class as varchar(40)
	DECLARE @Tact_Time as int
	DECLARE @Number_Of_Product as int
	DECLARE @Product_Time as int

	DECLARE @DEF_TACT_TIME as int
	DECLARE @DEF_NUM_PRODUCT as int	

	--初期値
	SET @DEF_TACT_TIME = 10
	SET @DEF_NUM_PRODUCT = 1

	DECLARE InsertData CURSOR FOR 
	SELECT Equipment_No,Product_Plan_Date,Manu_Order,Manu_Count,Inst_Row_No,Sch_No
	FROM INSERTED

	--カーソルをオープンし、内容を確認
	OPEN InsertData

	--行の取り出し
	FETCH NEXT FROM InsertData INTO @Equipment_No,@Product_Plan_Date,@Manu_Order,@Manu_Count,
		@Inst_Row_No,@Sch_No

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN			
			--計画値データ作成時に必要なデータを取得
			DECLARE GetData CURSOR FOR
			SELECT A.Kind_Name,A.Kind_Class,B.Tact_Time,B.Number_Of_Product
			FROM (SELECT Kind_Name,Kind_Class FROM TD_MANU_INSTRUCTION WHERE Inst_Row_No = @Inst_Row_No ) AS A
				LEFT JOIN TD_EQUIPMENT_KIND_INFO AS B ON B.Equipment_No = @Equipment_No
					AND A.Kind_Name = B.Kind_Name AND A.Kind_Class = B.Kind_Class

			--カーソルをオープンし、内容を確認
			OPEN GetData

			--行の取り出し
			FETCH NEXT FROM GetData INTO @Kind_Name,@Kind_Class,@Tact_Time,@Number_Of_Product

			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					
					--NULLチェック
					IF (@Tact_Time is null)
						BEGIN
							--強制的に値を入れる
							SET @Tact_Time = @DEF_TACT_TIME
						END
					IF(@Number_Of_Product is null)
						BEGIN
							--強制的に値を入れる
							SET @Number_Of_Product = @DEF_NUM_PRODUCT
						END
					--==========================================st 2017/03/02 takasima 小数点以下切り上げ処理追加
					----タクトタイムから生産時間を求める(秒⇒分へ変換)
					--SET @Product_Time = @Manu_Count * (@Tact_Time / @Number_Of_Product) / 60


					--タクトタイムから生産時間を求める(秒⇒分へ変換)
					SET @Product_Time = CEILING( @Manu_Count * (@Tact_Time / @Number_Of_Product) / 60)
					--==========================================ed 2017/03/02 takasima 小数点以下切り上げ処理追加

					--行の取り出し
					FETCH NEXT FROM GetData INTO @Kind_Name,@Kind_Class,@Tact_Time,@Number_Of_Product

				END

			--カーソルを閉じる
			CLOSE GetData
			DEALLOCATE GetData

			--既に書込まれた計画を削除
			DELETE TD_TARGET_VALUE WHERE Equipment_No = @Equipment_No AND Start_Date = @Product_Plan_Date
				AND Manu_Order = @Manu_Order

			--計画値の書込み
			INSERT INTO TD_TARGET_VALUE (Equipment_No,Kind_Name,Kind_Class,Start_Date,Manu_Order,Production_Cost,
				Target_Value,Instruct_No,Sch_No,Last_Update) VALUES (@Equipment_No,@Kind_Name,@Kind_Class,
				@Product_Plan_Date,@Manu_Order,@Product_Time,@Manu_Count,@Inst_Row_No,@Sch_No,GETDATE())

			--行の取り出し
			FETCH NEXT FROM InsertData INTO @Equipment_No,@Product_Plan_Date,@Manu_Order,@Manu_Count,
				@Inst_Row_No,@Sch_No
		END
	
	--カーソルを閉じる
	CLOSE InsertData
	DEALLOCATE InsertData

END

go

