
/***********************************************************************************
*
* 製品名			：生産分析機能
* 処理名			：生産時間収集処理
* ファンクション名	：MAN_ProductionTime
* 概要				：生産時間の取得関数
* 使用箇所　　　    ：稼働監視画面
* バージョン		：1.800
*
* 作成者			：Takasima Hironori
* 作成日			：2016/03/14
* 更新者			：
* 更新日			：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE FUNCTION [dbo].[MAN_ProductionTime]
(
	@Equipment_No			int,				--装置No.
	@Start_Date				date,				--検索開始日付
	@Search_Mode			int,				--検索モード(1:日選択、2:月選択、3:期間選択)
	@Search_Period			int,				--検索期間
	@Start_Hour				int,				--開始時刻
	--=========================================================st 時分処理に変更 20170817 takasima
	@Start_Min				int,				--開始時刻(分)
	--=========================================================ed 時分処理に変更 20170817 takasima
	@Mode_Flg				int					--取得したいモードを選択(0:生産時間、1:非生産時間)
)
RETURNS @retTbl TABLE
(
	Equipment_No int NOT NULL,					--装置No.
	Product_Time int NULL						--生産/非生産時間
)
BEGIN
	DECLARE @Product_Time AS int				--生産時間 or 非生産時間
	DECLARE @SearchDate AS DATETIME				--検索日時
	DECLARE @Search_EndTime AS DATETIME			--検索日時

	DECLARE @AddTime AS int						--追加時間
	DECLARE @NULL_GetFlg AS int
	DECLARE @NULL_GetDate AS datetime
	DECLARE @NULL_Production_Flg AS int
	DECLARE @Old_GetFlg AS int
	DECLARE @Old_Date AS datetime
	DECLARE @Old_Production_Flg as int

	DECLARE @tmpDatetime AS datetime			--テンポラリ
	DECLARE @tmpValue1 AS int					--テンポラリ
	DECLARE @tmpValue2 AS int					--テンポラリ
	DECLARE @tmpValue3 AS int					--テンポラリ

	--初期化
	SET @Product_Time = 0

	--検索日時のセット
	--=========================================================st 時分処理に変更 20170817 takasima
	--SET @SearchDate = Convert(datetime,FORMAT(@Start_Date,'yyyy/MM/dd') + ' ' + RIGHT('00' + Convert(varchar,@Start_Hour),2) + ':00:00')

	SET @SearchDate = Convert(datetime,FORMAT(@Start_Date,'yyyy/MM/dd') + ' ' + RIGHT('00' + Convert(varchar,@Start_Hour),2) + ':' + RIGHT('00' + Convert(varchar,@Start_Min),2) + ':00')
	--=========================================================ed 時分処理に変更 20170817 takasima

	--検索期間内のデータを取得
	IF(@Search_Mode = 1)					--日選択
		BEGIN
			IF(DATEADD(hour,@Search_Period,@SearchDate) > GETDATE())
				BEGIN
					--開始日が未来の日付を指定している場合には終了日を変更しない
					IF(@SearchDate < GETDATE())
						BEGIN
							SET @Search_EndTime = GETDATE()

						END
					ELSE
						BEGIN
							SET @Search_EndTime = DATEADD(hour,@Search_Period,@SearchDate)
						END
				END
			ELSE
				BEGIN
					SET @Search_EndTime = DATEADD(hour,@Search_Period,@SearchDate)
				END
		END
	ELSE IF (@Search_Mode = 2)				--月選択
		BEGIN
			IF(DATEADD(month,1,@SearchDate) > GETDATE())
				BEGIN
					--開始日が未来の日付を指定している場合には終了日を変更しない
					IF(@SearchDate < GETDATE())
						BEGIN
							SET @Search_EndTime = GETDATE()

						END
					ELSE
						BEGIN
							SET @Search_EndTime = DATEADD(month,1,@SearchDate)
						END
				END
			ELSE
				BEGIN
					SET @Search_EndTime = DATEADD(month,1,@SearchDate)
				END
		END
	ELSE									--期間選択
		BEGIN
			IF(DATEADD(DAY,@Search_Period,@SearchDate) > GETDATE())
				BEGIN
					--開始日が未来の日付を指定している場合には終了日を変更しない
					IF(@SearchDate < GETDATE())
						BEGIN
							SET @Search_EndTime = GETDATE()

						END
					ELSE
						BEGIN
							SET @Search_EndTime = DATEADD(DAY,@Search_Period,@SearchDate)
						END
				END
			ELSE
				BEGIN
					SET @Search_EndTime = DATEADD(DAY,@Search_Period,@SearchDate)
				END
		END

	DECLARE TIME_VAL CURSOR FOR
	SELECT B.Collect_Date,B.Status_No,B.Status_Time,TM_ST.Production_Flg
	FROM (
		SELECT TD_ST1.Equipment_No,TD_ST1.Collect_Date,TD_ST1.Status_No,TD_ST1.Status_Time
		FROM (
			SELECT Equipment_No,MAX(Row_No) AS Row_No
			FROM TD_COLLECT_STATUS
			WHERE Equipment_No = @Equipment_No
				AND Collect_Date <= @SearchDate
			Group BY Equipment_No
		) AS A LEFT JOIN TD_COLLECT_STATUS AS TD_ST1 ON A.Row_No = TD_ST1.Row_No
		UNION 
		SELECT TD_ST2.Equipment_No,TD_ST2.Collect_Date,TD_ST2.Status_No,TD_ST2.Status_Time
		FROM TD_COLLECT_STATUS AS TD_ST2
		WHERE TD_ST2.Equipment_No = @Equipment_No
			AND Collect_Date > @SearchDate AND Collect_Date <= @Search_EndTime
	) AS B LEFT JOIN TM_STATUS_INFO AS TM_ST ON B.Status_No = TM_ST.Status_No
	ORDER BY B.Equipment_No ASC,B.Collect_Date ASC	

	--カーソルのOPEN
	OPEN TIME_VAL

	--行の取り出し
	FETCH NEXT FROM TIME_VAL INTO @tmpDatetime,@tmpValue1,@tmpValue2,@tmpValue3

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--初期化
			SET @AddTime = 0

			--前回取込んだ値がNULLの場合、その差分を実績値として加算する
			IF(@NULL_GetFlg = 1)
				BEGIN
					--該当状態が加算対象項目かをチェックする
					IF(@NULL_Production_Flg = @Mode_Flg)
						BEGIN
							--該当状態の終了時刻までを書込む
							SET @AddTime = DATEDIFF(second,@NULL_GetDate,@tmpDatetime)
						END

					--加算時間を加える
					SET @Product_Time = @Product_Time + @AddTime
					--加算完了後、フラグを初期化
					SET @NULL_GetFlg = 0

					--値を初期化
					SET @AddTime = 0
				END
			--開始時刻以前のデータ有無確認(表示期間内のデータなし)
			IF(@Old_GetFlg = 1)
				BEGIN
					--開始時刻以前からのデータを加算
					SET @AddTime = DATEDIFF(second,@SearchDate,@tmpDatetime)
					--取得した日付が過去の場合、値を初期化
					IF(@SearchDate > @tmpDatetime) OR (@Old_Production_Flg <> @Mode_Flg)
						BEGIN
							--過去の値または対象の状態ではないため、演算値を初期化
							SET @AddTime = 0

						END

					--加算時間を加える
					SET @Product_Time = @Product_Time + @AddTime

					--加算完了後、フラグを更新
					SET @Old_GetFlg = 2

					--値を初期化
					SET @AddTime = 0
				END
			--取得した日時が開始時刻以前かをチェック
			IF(@tmpDatetime <= @SearchDate)
				BEGIN
					--前回値を記録
					SET @Old_Date = @tmpDatetime
					SET @Old_Production_Flg = @tmpValue3
					
					--フラグを更新
					SET @Old_GetFlg = 1

				END
			ELSE
				BEGIN
					--取得した項目の状態変化時間のNULLチェック
					IF(@tmpValue2 IS NULL)
						BEGIN
							--NULLフラグを設定
							SET @NULL_GetFlg = 1
							--NULLだった値を設定
							SET @NULL_GetDate = @tmpDatetime
							SET @NULL_Production_Flg = @tmpValue3
							
							--値を初期化
							SET @AddTime = 0

						END
					ELSE
						BEGIN
							--該当状態の終了時間が表示範囲内かをチェック	
							IF(@Search_EndTime >= DATEADD(second,@tmpValue2,@tmpDatetime))
								BEGIN
									--状態の変化時間をそのまま書込み
									SET @AddTime = @tmpValue2									
								END
							ELSE
								BEGIN
									--NULLとして値を更新
									SET @NULL_GetFlg = 1
									--NULLだった値を設定
									SET @NULL_GetDate = @tmpDatetime
									SET @NULL_Production_Flg = @tmpValue3
							
									--値を初期化
									SET @AddTime = 0

								END
						END
				END
			--フラグが一致した場合、値を加算する
			IF(@tmpValue3 = @Mode_Flg)
				BEGIN
					--時間の追加
					SET @Product_Time = @Product_Time + @AddTime
				END

			--行の取り出し
			FETCH NEXT FROM TIME_VAL INTO @tmpDatetime,@tmpValue1,@tmpValue2,@tmpValue3

		END
	--カーソルを閉じる
	CLOSE TIME_VAL
	DEALLOCATE TIME_VAL

	--フラグ残りチェック
	IF(@Old_GetFlg = 1)
		BEGIN
			--表示範囲にて稼働状態の変化がなかったため、表示範囲の時間を加算
			IF(@Mode_Flg = @Old_Production_Flg)
				BEGIN
					SET @AddTime = DATEDIFF(second,@SearchDate,@Search_EndTime)
					--値を加算
					SET @Product_Time = @Product_Time + @AddTime

					--値を初期化
					SET @AddTime = 0

				END
		END
	--NULLデータ取得チェック
	IF(@NULL_GetFlg = 1)
		BEGIN
			--該当状態の終了時刻までを書込む
			IF(@Mode_Flg = @NULL_Production_Flg)
				BEGIN
					SET @AddTime = DATEDIFF(second,@NULL_GetDate,@Search_EndTime)
					--値を加算
					SET @Product_Time = @Product_Time + @AddTime				
				END			
		END

		--データのインサート
		INSERT INTO @retTbl VALUES (@Equipment_No,@Product_Time)

Proc_End:

	RETURN
END

go

