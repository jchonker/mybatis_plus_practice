
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：状態履歴データ転送トリガ
* トリガ名		：TR_TD_COLLECT_STATUS
* 概要          ：状態履歴データテーブルから状態履歴データ(日)へ展開
* バージョン    ：1.12.0.0
*
* 作成者        ：Takasima Hironori
* 作成日        ：2017/07/08
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR_COLLECT_STATUS] ON [dbo].[TD_COLLECT_STATUS] AFTER INSERT
AS 
BEGIN

	 DECLARE @Equipment_No as int				--装置No.
	 DECLARE @Collect_Date as datetime			--収集日時
	 DECLARE @Status_No as tinyint				--ステータス
	 DECLARE @Status_Time as int				--状態変化時間
	 DECLARE @tmpSetData as varchar(20)
	 DECLARE @Start_Hour as int
	 DECLARE @Target_Date as date
	 DECLARE @Start_Min as int

	 --初期化
	 SET @Start_Hour = -1
	 SET @Start_Min = -1

	 --INSERTされた行から各種情報を取得
	 SELECT @Equipment_No = Equipment_No,
			@Collect_Date = Collect_Date,
			@Status_No = Status_No,
			@Status_Time = Status_Time
	FROM inserted;

	--収集開始時刻の取得
	DECLARE OptionSet1 CURSOR FOR 
	SELECT Setting_Value
	FROM TM_OPTION_SETTING
	WHERE Key_Name = 'Start_Hour'

	--カーソルをオープンし、内容を確認
	OPEN OptionSet1

	--行の取り出し
	FETCH NEXT FROM OptionSet1 INTO @tmpSetData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--数値に変換する
			SET @Start_Hour = CONVERT(int,@tmpSetData)

			--行の取り出し
			FETCH NEXT FROM OptionSet1 INTO @tmpSetData

		END
	--カーソルを閉じる
	CLOSE OptionSet1
	DEALLOCATE OptionSet1

	--収集開始時刻の取得
	DECLARE OptionSet2 CURSOR FOR 
	SELECT Setting_Value
	FROM TM_OPTION_SETTING
	WHERE Key_Name = 'Start_Min'

	--カーソルをオープンし、内容を確認
	OPEN OptionSet2

	--行の取り出し
	FETCH NEXT FROM OptionSet2 INTO @tmpSetData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--数値に変換する
			SET @Start_Min = CONVERT(int,@tmpSetData)

			--行の取り出し
			FETCH NEXT FROM OptionSet2 INTO @tmpSetData

		END
	--カーソルを閉じる
	CLOSE OptionSet2
	DEALLOCATE OptionSet2
	--処理の確認
	IF((@Start_Hour = -1) or (@Start_Min = -1))
		BEGIN
			--処理を抜ける
			goto proc_end

		END

	DECLARE @tmpHour as int
	DECLARE @tmpMin as int
	DECLARE @tmpSec as int

	SET @Target_Date = CONVERT(date, format(@Collect_Date,'yyyy/MM/dd'))
	SET @tmpHour = CONVERT(int,format(@Collect_Date,'HH'))
	SET @tmpMin = CONVERT(int,FORMAT(@Collect_Date,'mm'))

	--時刻チェック
	if((@tmpHour < @Start_Hour) OR ((@tmpHour = @Start_Hour) AND (@tmpMin <= @Start_Min)))
		BEGIN
			--前日にずらす
			SET @Target_Date = DATEADD(day,-1,@Target_Date)
		END

	--処理を実行
	EXECUTE DayCollect_Status @Equipment_No,@Target_Date

	--装置製造状況データへの反映
	DECLARE @RecodeFlg as tinyint
	DECLARE @tmpData as int
	SET @RecodeFlg = 0

	DECLARE EQ_STAT CURSOR FOR
	SELECT Equipment_No
	FROM TD_EQUIPMENT_STATUS
	WHERE Equipment_No = @Equipment_No

	OPEN EQ_STAT

	FETCH NEXT FROM EQ_STAT INTO @tmpData

	WHILE(@@FETCH_STATUS = 0)
		BEGIN
			SET @RecodeFlg = 1

			FETCH NEXT FROM EQ_STAT INTO @tmpData
		END

	CLOSE EQ_STAT
	DEALLOCATE EQ_STAT

	IF(@RecodeFlg = 1)
		BEGIN
			--データをUpdate
			UPDATE TD_EQUIPMENT_STATUS SET Status_No = @Status_No
			WHERE Equipment_No = @Equipment_No
		END
	ELSE
		BEGIN
			--データをInsert
			INSERT INTO TD_EQUIPMENT_STATUS (Equipment_No,Collect_Date,Kind_Name,Collect_Value,Status_No,Last_Update)
			VALUES (@Equipment_No,GETDATE(),'',0,@Status_No,GETDATE())
		END

proc_end:

END

go

