
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：製造指示データの更新トリガ
* トリガ名		：TR1_MANU_INSTRUCTION
* 概要          ：製造指示データが更新された時の設定内容展開処理
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/09/18
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR1_MANU_INSTRUCTION] ON [dbo].[TD_MANU_INSTRUCTION] AFTER UPDATE
AS
BEGIN

	DECLARE @Seq_No1 as bigint
	DECLARE @Seq_No2 as bigint
	DECLARE @Order_Count as float
	DECLARE @Performance_Reporting as float
	DECLARE @Report_Count as int
	DECLARE @Setting_Sch_Count as int
	DECLARE @Product_Comp_Flg as tinyint
	DECLARE @Inst_Row_No as bigint

	DECLARE @Comp_Flg as tinyint
	DECLARE @Sch_Index as bigint

	--==================================st 20170301 takasima 【仕様変更】生産数変更に伴うスケジュールの自動削除機能をなくす
	--DECLARE @Delete_Count as int
	--==================================ed 20170301 takasima 【仕様変更】生産数変更に伴うスケジュールの自動削除機能をなくす

	DECLARE @Count_Chg_Flg as tinyint		--設定スケジュールチェックフラグ
	DECLARE @Sch_Count as int	

	--フラグ初期化
	SET @Count_Chg_Flg = 0		

	DECLARE UpdateData CURSOR FOR
	SELECT Seq_No1,Seq_No2,Order_Count,Performance_Reporting,Report_Count,
		Setting_Sch_Count,Product_Comp_Flg,Inst_Row_No
	FROM INSERTED

	--カーソルをオープンし、内容を確認
	OPEN UpdateData

	--行の取り出し
	FETCH NEXT FROM UpdateData INTO @Seq_No1,@Seq_No2,@Order_Count,@Performance_Reporting,
		@Report_Count,@Setting_Sch_Count,@Product_Comp_Flg,@Inst_Row_No

	--ループ処理
    WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--フラグを初期化する
			SET @Count_Chg_Flg = 0
			--==================================st 20170301 takasima 【仕様変更】生産数変更に伴うスケジュールの自動削除機能をなくす
			--SET @Delete_Count = 0
			--==================================ed 20170301 takasima 【仕様変更】生産数変更に伴うスケジュールの自動削除機能をなくす
			SET @Sch_Count = @Setting_Sch_Count
			
			--製造完了フラグの状態を確認
			IF(@Product_Comp_Flg <> 3)
				BEGIN
					--報告実績数と生産数を比較
					IF(@Order_Count <= @Performance_Reporting)
						BEGIN
							--設定スケジュールや報告回数のチェックを行う
							SET @Count_Chg_Flg = 1
						END
				END

			--==================================st 20170301 takasima 【仕様変更】生産数変更に伴うスケジュールの自動削除機能をなくす
			----設定スケジュールのチェック処理有無
			--IF(@Count_Chg_Flg = 1)
			--	BEGIN
			--		--現在設定されているスケジュールのチェック
			--		DECLARE ChkSchedule CURSOR FOR
			--		SELECT Comp_Flg,Sch_Index
			--		FROM TD_SCHEDULE
			--		WHERE Inst_Row_No = @Inst_Row_No

			--		--カーソルをOPENし、内容を確認
			--		OPEN ChkSchedule

			--		--行の取り出し
			--		FETCH NEXT FROM ChkSchedule INTO @Comp_Flg,@Sch_Index

			--		--ループ処理
			--		WHILE (@@FETCH_STATUS = 0)
			--			BEGIN
			--				--まだ指示が完了していないスケジュールかチェック
			--				--(指示済みのスケジュールは削除対象外)
			--				IF(@Comp_Flg = 0)
			--					BEGIN
			--						--設定スケジュール数を1件減らす
			--						SET @Delete_Count = @Delete_Count + 1

			--						--対象のスケジュール(計画値テーブル)を削除する
			--						--【削除したSch_Indexから作成された計画値を削除する処理を追加する必要あり】

			--						--対象のスケジュールを削除する(TD_SCHEDULE)
			--						DELETE FROM TD_SCHEDULE WHERE Sch_Index = @Sch_Index

			--						--対象のスケジュール(装置用)を削除する
			--						DELETE FROM TD_PRODUCT_SCHEDULE WHERE Sch_Index = @Sch_Index

			--					END

			--				--行の取り出し
			--				FETCH NEXT FROM ChkSchedule INTO @Comp_Flg,@Sch_Index
			--			END

			--		--カーソルを閉じる
			--		CLOSE ChkSchedule
			--		DEALLOCATE ChkSchedule

			--		--設定スケジュール数の変更
			--		SET @Sch_Count = @Setting_Sch_Count - @Delete_Count

			--		--マイナスチェック
			--		IF(@Sch_Count < 0)
			--			BEGIN
			--				--強制的に設定スケジュール数を「0」に変更
			--				SET @Sch_Count = 0
			--			END

			--		--削除対象件数の確認
			--		IF(@Delete_Count > 0)
			--			BEGIN
							
			--				--設定スケジュール数と報告回数のチェック
			--				IF(@Sch_Count <= @Report_Count)
			--					BEGIN
			--						--報告された回数が設定スケジュール数を超えたため、
			--						--製造完了扱いに変更
			--						UPDATE TD_MANU_INSTRUCTION SET Setting_Sch_Count = @Sch_Count,Product_Comp_Flg = 3
			--						WHERE Inst_Row_No = @Inst_Row_No
			--					END
			--				ELSE
			--					BEGIN
			--						--まだ動作中のスケジュールが存在するため、
			--						--設定スケジュール数のみを減らす
			--						UPDATE TD_MANU_INSTRUCTION SET Setting_Sch_Count = @Sch_Count
			--						WHERE Inst_Row_No = @Inst_Row_No
			--					END
			--			END
					
			--	END
			--==================================ed 20170301 takasima 【仕様変更】生産数変更に伴うスケジュールの自動削除機能をなくす

			--製造完了フラグ確認
			IF(@Sch_Count <> 0)
				BEGIN
					IF((@Sch_Count <= @Report_Count) AND (@Order_Count <= @Performance_Reporting))
						BEGIN
							--既に製造が完了しているため、製造完了扱いに変更
							UPDATE TD_MANU_INSTRUCTION SET Product_Comp_Flg = 3
							WHERE Inst_Row_No = @Inst_Row_No
						END
					ELSE IF((@Sch_Count > @Report_Count) AND (@Order_Count <= @Performance_Reporting))
						BEGIN
							--生産数を超えているが、まだ製造中の項目が存在するため、一時完了扱いに変更
							UPDATE TD_MANU_INSTRUCTION SET Product_Comp_Flg = 2
							WHERE Inst_Row_No = @Inst_Row_No
						END
					ELSE IF((@Sch_Count <= @Report_Count) AND (@Order_Count > @Performance_Reporting))
						BEGIN
							--設定スケジュール数は超えているがまだ生産数を超えていないため、一時完了扱いに変更
							UPDATE TD_MANU_INSTRUCTION SET Product_Comp_Flg = 2
							WHERE Inst_Row_No = @Inst_Row_No
						END
					ELSE
						BEGIN
							--その他(スケジュール設定済み状態に変更)
							UPDATE TD_MANU_INSTRUCTION SET Product_Comp_Flg = 1
							WHERE Inst_Row_No = @Inst_Row_No
						END
				END
		
			--行の取り出し
			FETCH NEXT FROM UpdateData INTO @Seq_No1,@Seq_No2,@Order_Count,@Performance_Reporting,
				@Report_Count,@Setting_Sch_Count,@Product_Comp_Flg,@Inst_Row_No

		END
	--カーソルを閉じる
	CLOSE UpdateData
	DEALLOCATE UpdateData

END

go

