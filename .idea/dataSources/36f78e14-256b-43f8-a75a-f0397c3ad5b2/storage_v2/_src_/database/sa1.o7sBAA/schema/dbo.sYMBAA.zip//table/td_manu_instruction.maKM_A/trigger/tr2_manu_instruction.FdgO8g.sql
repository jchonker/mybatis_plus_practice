
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：製造指示データの削除トリガ
* トリガ名		：TR2_MANU_INSTRUCTION
* 概要          ：製造指示データが削除された時の設定内容展開処理
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/09/18
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR2_MANU_INSTRUCTION] ON [dbo].[TD_MANU_INSTRUCTION] AFTER DELETE
AS
BEGIN

	DECLARE @Inst_Row_No as bigint
	DECLARE @Product_Plan_Date as date
	DECLARE @Manu_Order as int
	DECLARE @Equipment_No as int

	DECLARE DeleteData CURSOR FOR
	SELECT Inst_Row_No
	FROM DELETED

	--カーソルをオープンし、内容を確認
	OPEN DeleteData

	--行の取り出し
	FETCH NEXT FROM DeleteData INTO @Inst_Row_No

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			--まだ指示が出ていないスケジュールデータを削除
			DELETE TD_SCHEDULE WHERE Inst_Row_No = @Inst_Row_No

			--まだ指示が出ていないスケジュール項目を削除
			DELETE TD_PRODUCT_SCHEDULE WHERE Inst_Row_No = @Inst_Row_No

			--行の取り出し
			FETCH NEXT FROM DeleteData INTO @Inst_Row_No
		END
	
	--カーソルを閉じる
	CLOSE DeleteData
	DEALLOCATE DeleteData

END

go

