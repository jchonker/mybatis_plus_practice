
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：状態履歴の転送処理(外部接続機器のデータベースからの展開)
* プロシージャ名：MAN_STATUS_TRANSFER
* 概要          ：外部接続機器からの実績値データの展開
* 使用箇所　　　：通信プログラム
* バージョン    ：1.12.0.0
*
* 作成者        ：Takasima Hironori
* 作成日        ：2017/08/29
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE PROCEDURE [dbo].[MAN_STATUS_TRANSFER]
	@Equipment_No			int					--装置No.
AS
BEGIN
	DECLARE @resultcd as int					--実行結果
	DECLARE @DB_NAME as varchar(32)				--リンクサーバ名
	DECLARE @PC_MODE as int						--PCモード

	--初期化
	SET @PC_MODE = 2

	set @resultcd = @@ERROR

	--リンクサーバ名の取得
	DECLARE CONNECT_DATA CURSOR FOR
	SELECT DB_Server_Name FROM TM_CONNECT_GROUP
	WHERE Group_No in (SELECT Group_No FROM TM_EQUIPMENT_INFO WHERE Equipment_No = @Equipment_No AND Collection_Mode = @PC_MODE)

	--カーソルをオープンし、内容を確認
	OPEN CONNECT_DATA

	--行の取り出し
	FETCH NEXT FROM CONNECT_DATA INTO @DB_NAME

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			BEGIN TRY
				--取得したリンクサーバ名を用いて実績データを取得
				DECLARE @CreateSQL as nvarchar(1000)
				DECLARE @Connect_DB_Name as nvarchar(64)
				--DECLARE @GET_COLLECT as CURSOR			--カーソル(実績レコード)

				DECLARE @Collect_Date as datetime		--収集日時
				DECLARE @Status_No as tinyint			--状態No.
				DECLARE @Kind_Name as varchar(40)		--品目コード
				DECLARE @Kind_Class as varchar(40)		--品目区分
				DECLARE @Status_Time as int				--状態変化時間

				DECLARE @WriteSQL as nvarchar(1000)
				DECLARE @ParamSQL AS nvarchar(1000)

				SET @Connect_DB_Name = '[' + convert(nvarchar, @DB_NAME) + ']' + '.[SA1].[dbo].[TD_COLLECT_STATUS]'
			
				SET @CreateSQL = 'DECLARE GET_COLLECT CURSOR FOR '
				SET @CreateSQL = @CreateSQL + 'SELECT Collect_Date,Status_No,Kind_Name,Kind_Class,Status_Time'
				SET @CreateSQL = @CreateSQL + ' FROM ' + @Connect_DB_Name
				SET @CreateSQL = @CreateSQL + ' WHERE Equipment_No = ' + convert(varchar, @Equipment_No)
				SET @CreateSQL = @CreateSQL + ' AND Trans_Flg = 0'
				SET @CreateSQL = @CreateSQL + ' AND Status_Time is not null '
			
				--SQL実行
				EXEC sp_executesql @CreateSQL	
					
				--カーソルをオープンし、内容を確認
				OPEN GET_COLLECT

				FETCH NEXT FROM GET_COLLECT INTO @Collect_Date,@Status_No,@Kind_Name,@Kind_Class,@Status_Time

			END TRY
			BEGIN CATCH
				--異常発生
				goto NEXT_DATA
			END CATCH

			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN					
					--取得した値をINSERTする前にデータを削除
					DELETE FROM TD_COLLECT_STATUS
					WHERE Equipment_No = @Equipment_No
					  AND Collect_Date = FORMAT(@Collect_Date,'yyyy-MM-dd HH:mm:ss.fff')

					--DELETE処理結果チェック					
					set @resultcd = @@ERROR

					if(@resultcd <> 0)
						--処理を抜ける
						goto proc_end
					
					--取得した値を自身のテーブルにINSERT
					INSERT INTO TD_COLLECT_STATUS (Equipment_No,Collect_Date,Status_No,Kind_Name,Kind_Class,Status_Time,Last_Update)
						VALUES (@Equipment_No,@Collect_Date,@Status_No,@Kind_Name,@Kind_Class,@Status_Time,GETDATE())

					--INSERT処理結果チェック					
					set @resultcd = @@ERROR

					if(@resultcd <> 0)
						--処理を抜ける
						goto proc_end

					DECLARE @Col_Date as varchar(23)
					DECLARE @Equipment_Data1 as int

					SET @Col_Date = FORMAT(@Collect_Date,'yyyy-MM-dd HH:mm:ss.fff')
					SET @Equipment_Data1 = @Equipment_No

					--リンクサーバのデータにて取込完了項目のフラグを「1」に変更
					SET @WriteSQL = 'UPDATE ' + @Connect_DB_Name
					SET @WriteSQL = @WriteSQL + ' SET Trans_Flg = 1'
					SET @WriteSQL = @WriteSQL + ' WHERE Equipment_No = @E_No'
					SET @WriteSQL = @WriteSQL + ' AND Collect_Date = @C_Date'

					SET @ParamSQL = '@E_No int,'
					SET @ParamSQL = @ParamSQL + '@C_Date varchar(23)'
					
					--SQL実行
					EXEC sp_executesql @WriteSQL,@ParamSQL,@E_No=@Equipment_Data1,@C_Date=@Col_Date

					--UPDATE処理結果チェック					
					set @resultcd = @@ERROR

					if(@resultcd <> 0)
						--処理を抜ける
						goto proc_end
					
					--次の行へ移動
					FETCH NEXT FROM GET_COLLECT INTO @Collect_Date,@Status_No,@Kind_Name,@Kind_Class,@Status_Time
				END

			--カーソルを閉じる
			CLOSE GET_COLLECT
			DEALLOCATE GET_COLLECT

NEXT_DATA:
			--次の行へ移動
			FETCH NEXT FROM CONNECT_DATA INTO @DB_NAME
		END

	set @resultcd = @@ERROR

	--カーソルを閉じる
	CLOSE CONNECT_DATA
	DEALLOCATE CONNECT_DATA

	--処理結果確認
	if(@resultcd = 0)
		RETURN(1)
	ELSE
		BEGIN

proc_end:
			--異常
			RETURN (-1)
		END
END

go

