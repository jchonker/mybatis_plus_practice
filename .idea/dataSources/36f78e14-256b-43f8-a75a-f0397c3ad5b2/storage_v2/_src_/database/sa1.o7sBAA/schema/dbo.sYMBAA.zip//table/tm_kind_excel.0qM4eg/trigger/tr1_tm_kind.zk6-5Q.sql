
/***********************************************************************************
*
* 製品名        ：上位システム連携機能
* 処理名        ：品目マスタ　展開用トリガ(INSERT用)
* トリガ名		：TR1_TM_KIND
* 概要          ：TM_KIND_EXCLE→TM_KIND_INFO、TM_KIND_NAMEへの展開(INSERT)
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/12/19
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR1_TM_KIND] ON [dbo].[TM_KIND_EXCEL] AFTER INSERT 
AS
BEGIN

	DECLARE @Kind_Name as varchar(40)
	DECLARE @Kind_Class as varchar(40)
	DECLARE @Model_Number as varchar(160)
	DECLARE @Unit_No as int
	DECLARE @Manu_Lot as float
	DECLARE @Manu_Lead_Time as float
	DECLARE @Delete_Flg as tinyint
	DECLARE @Lang_Mode as tinyint
	DECLARE @Item_Name as varchar(160)
	DECLARE @Abbreviation_Name as varchar(32)
	DECLARE @K_Name as varchar(40)
	DECLARE @K_Class as varchar(40)
	DECLARE @Insert_Flg as tinyint

	DECLARE InsertData CURSOR FOR
	SELECT Kind_Name,Kind_Class,Model_Number,Unit_No,Manu_Lot,Manu_Lead_Time,Delete_Flg,
           Lang_Mode,Item_Name,Abbreviation_Name
	FROM INSERTED

    --カーソルをオープンし、内容を確認
    OPEN InsertData
    
    --行の取り出し
    FETCH NEXT FROM InsertData INTO @Kind_Name,@Kind_Class,@Model_Number,@Unit_No,@Manu_Lot,
    		@Manu_Lead_Time,@Delete_Flg,@Lang_Mode,@Item_Name,@Abbreviation_Name
    
    --ループ処理
    WHILE (@@FETCH_STATUS = 0)
    	BEGIN
    		
			--フラグ初期化
			SET @Insert_Flg = 1

			--品目情報マスタに既にデータが存在するかを確認する
			DECLARE ChkData CURSOR FOR
			SELECT Kind_Name,Kind_Class
			FROM TM_KIND_INFO
			WHERE Kind_Name = @Kind_Name AND Kind_Class = @Kind_Class

			--カーソルをオープンし、内容を確認
			OPEN ChkData

			--行の取り出し
			FETCH NEXT FROM ChkData INTO @K_Name,@K_Class

			--ループ処理

			WHILE (@@FETCH_STATUS =0)
				BEGIN
					--フラグに0をセット(既にデータあり(他の言語設定時)
					SET @Insert_Flg = 0

					--行の取り出し
					FETCH NEXT FROM ChkData INTO @K_Name,@K_Class

				END
			
			--品目情報マスタへの展開有無チェック
			IF (@Insert_Flg = 1)
				BEGIN
					--品目情報マスタ(TM_KIND_INFO)への展開
					INSERT INTO TM_KIND_INFO (Kind_Name,Kind_Class,Model_Number,Unit_No,Manu_Lot,Manu_Lead_Time,Delete_Flg,Last_Update)
						VALUES (@Kind_Name,@Kind_Class,@Model_Number,@Unit_No,@Manu_Lot,@Manu_Lead_Time,@Delete_Flg,GETDATE())

				END
			ELSE
				BEGIN
					--後で登録しようとした内容へ更新する
					UPDATE TM_KIND_INFO SET Model_Number = @Model_Number,Unit_No = @Unit_No,Manu_Lot = @Manu_Lot,
						Manu_Lead_Time = @Manu_Lead_Time,Delete_Flg = @Delete_Flg,Last_Update = GETDATE()
					WHERE Kind_Name = @Kind_Name AND Kind_Class = @Kind_Class

				END
		
			--品目名称マスタ(TM_KIND_NAME)への展開
			INSERT INTO TM_KIND_NAME (Kind_Name,Kind_Class,Lang_Mode,Item_Name,Abbreviation_Name,Last_Update)
				VALUES (@Kind_Name,@Kind_Class,@Lang_Mode,@Item_Name,@Abbreviation_Name,GETDATE())

    		--次の行へ移動
		    FETCH NEXT FROM InsertData INTO @Kind_Name,@Kind_Class,@Model_Number,@Unit_No,@Manu_Lot,
    				@Manu_Lead_Time,@Delete_Flg,@Lang_Mode,@Item_Name,@Abbreviation_Name

			--カーソルを閉じる
			CLOSE ChkData
			DEALLOCATE ChkData
    
    	END
    --カーソルを閉じる
    CLOSE InsertData
    DEALLOCATE InsertData

END

go

