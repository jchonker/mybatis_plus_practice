create procedure paging_procedure
(	@pageIndex int, -- 第几页
	@pageSize int  -- 每页包含的记录数
)
as
begin 
	select top (select @pageSize) *     -- 这里注意一下，不能直接把变量放在这里，要用select
	from (select row_number() over(order by SerialNumber) as rownumber,*  from DY_Product) temp_row 
	where rownumber>(@pageIndex-1)*@pageSize;
end
go

