
/***********************************************************************************
*
* 製品名			：生産分析機能
* 処理名			：稼動監視画面用データ収集処理
* ファンクション名	：MAN_OpeMonitor
* 概要				：稼動監視のグラフ表示時に使用するデータの取得処理
* 使用箇所　　　    ：稼働監視画面
* バージョン		：1.910
*
* 作成者			：Takasima Hironori
* 作成日			：2016/10/20
* 更新者			：
* 更新日			：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE FUNCTION [dbo].[MAN_OpeMonitor]
(
	@Hierarchy_No			int,				--階層No.
	@Start_Date				date,				--検索開始日付
	@End_Date				date,				--検索終了日付
	@Start_Hour				int,				--開始時刻
	--=========================================================st 時分処理に変更 20170817 takasima
	@Start_Min				int,				--開始時刻(分)
	--=========================================================ed 時分処理に変更 20170817 takasima
	@Data_Type				tinyint				--データタイプ(1:Collect_Value、2:OK_Value)
)
RETURNS @retTbl TABLE
(
	Data_Date date NOT NULL,					--データ日付
	Equipment_No int NOT NULL,					--装置No.
	Manu_Value float NULL,						--生産合計値
	Target_Value float NULL,					--生産計画値(合計)
	Normal_Time int NULL,						--正常運転時間
	ALL_TIME int NULL							--総運転時間
)
BEGIN
	--検索日付チェック
	IF(@Start_Date > @End_Date)
		BEGIN
			--処理を終了する
			GOTO Proc_End
		END

	DECLARE @tmpDate AS date				--一時格納データ(date)
	DECLARE @SearchDate AS  datetime		--検索日時
	DECLARE @SUM_Value AS float				--生産合計値
	DECLARE @Target_Value AS float			--生産計画値
	DECLARE @Operation_Time AS int			--正常運転時間
	DECLARE @ALL_Operation_Time AS int		--総運転時間

	DECLARE @Hierarchy_ID AS varchar(18)		--階層ID
	DECLARE @Hierarchy_Level AS int				--階層レベル
	DECLARE @Equipment_No as int			--装置No.

	DECLARE @tmpHieID AS varchar(18)

	--=================================================st 2017/03/15 takasima 該当日の最初の実績値を引く処理を追加
	DECLARE @tmpCollect_Value as float
	DECLARE @tmpOK_Value as float
	DECLARE @tmpNum_Cav as float
	--=================================================ed 2017/03/15 takasima 該当日の最初の実績値を引く処理を追加

	--初期化
	SET @Hierarchy_ID = ''
	SET @Hierarchy_Level = 0

	--階層情報の取得
	DECLARE HIE_VAL CURSOR FOR
	SELECT Hierarchy_ID
	FROM TM_HIERARCHY_INFO 
	WHERE Hierarchy_No = @Hierarchy_No 

	--カーソルをOPEN
	OPEN HIE_VAL

	--行の取り出し
	FETCH NEXT FROM HIE_VAL INTO @tmpHieID
		
	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--データの格納
			SET @Hierarchy_ID = @tmpHieID

			--行の移動
			FETCH NEXT FROM HIE_VAL INTO @tmpHieID
		END

	--カーソルを閉じる
	CLOSE HIE_VAL
	DEALLOCATE HIE_VAL

	IF(@Hierarchy_ID = '')
		BEGIN
			GOTO Proc_End
		END

	DECLARE @tmpHieLevel AS int
	DECLARE @tmpData AS int

	SET @tmpHieLevel = 1

	--階層IDから階層レベルを求める
	WHILE (@Hierarchy_Level = 0)
		BEGIN
			--文字列から数値の取得
			SET @tmpData = CONVERT(int,SUBSTRING(@Hierarchy_ID,(@tmpHieLevel-1)*3+1,3))
			--数値チェック
			IF(@tmpData = 0)
				BEGIN
					--階層レベルを設定
					SET @Hierarchy_Level = @tmpHieLevel -1

				END
			ELSE IF (@tmpData = 0 AND @tmpHieLevel = 6)
				BEGIN
					--階層レベルを6に設定
					SET @Hierarchy_Level = 6

				END
			--テンポラリを追加
			SET @tmpHieLevel = @tmpHieLevel + 1

		END

	--*******************************************************
	--　　選択された階層に含まれる装置情報
	--*******************************************************
	
	--階層に含まれる装置をもとに、各装置の稼働状態を取得
	DECLARE EQU_VAL CURSOR FOR
	SELECT A.Equipment_No
	FROM (
		SELECT MIN(HIE_INFO.Hierarchy_No) AS HieNo,HIE_INFO.Equipment_No
		FROM TM_HIERARCHY_INFO AS HIE_INFO 
			LEFT JOIN TM_HIERARCHY_NAME AS HIE_NAME ON HIE_INFO.Hierarchy_No = HIE_NAME.Hierarchy_No
		WHERE (
			(SELECT SUBSTRING(Hierarchy_ID, 1, @Hierarchy_Level*3) 
			FROM TM_HIERARCHY_INFO WHERE Hierarchy_No =@Hierarchy_No
			) = SUBSTRING(Hierarchy_ID,1,@Hierarchy_Level*3))
		GROUP BY Equipment_No
	) AS A ,TM_EQUIPMENT_INFO AS B
	WHERE  A.Equipment_No = B.Equipment_No
	ORDER BY HieNo ASC	
	
	--カーソルをOPEN
	OPEN EQU_VAL

	--行の取り出し
	FETCH NEXT FROM EQU_VAL INTO @Equipment_No

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
	
			--開始日付の設定
			SET @tmpDate = @Start_Date

			--終了日まで繰り返す
			WHILE (@tmpDate <= @End_Date)
				BEGIN
					--検索日時の取得
					--=========================================================st 時分処理に変更 20170817 takasima
					--SET @SearchDate = Convert(datetime,FORMAT(@tmpDate,'yyyy/MM/dd') + ' ' + RIGHT('00' + Convert(varchar,@Start_Hour),2) + ':00:00')

					SET @SearchDate = Convert(datetime,FORMAT(@tmpDate,'yyyy/MM/dd') + ' ' + RIGHT('00' + Convert(varchar,@Start_Hour),2) + ':' + RIGHT('00' + Convert(varchar,@Start_Min),2) + ':00')
					--=========================================================st 時分処理に変更 20170817 takasima
	
					--*******************************************************
					--　　　　　生産数の取得
					--*******************************************************

					DECLARE @tmpEquData AS int				--一時格納データ(装置No.)
					DECLARE @tmpValue AS float				--一時格納データ(計測値)
					DECLARE @tmpTarget AS float				--一時格納データ(目標値)

					IF(@Data_Type = 2)
						BEGIN
							--OK_Value時の処理
							DECLARE SUM_DATA2 CURSOR FOR
							SELECT E.Equipment_No,E.SUM_VALUE,F.TARGET_VAL 
							FROM
							(
								SELECT D.Equipment_No,sum(D.Sum_OK_Value)AS SUM_VALUE
								FROM
								(
									SELECT B.Equipment_No,sum(Collect_Value) AS Sum_Collect_Value,sum(OK_Value) AS Sum_OK_Value
									FROM
									(
										SELECT A.Equipment_No,A.Collect_Value * A.Number_Of_Cavities AS Collect_Value,
											A.OK_Value * A.Number_Of_Cavities AS OK_Value
										FROM (
											SELECT
												TD_VAL1.Equipment_No
												, TD_VAL1.Kind_Name
												, TD_VAL1.Kind_Priority
												, TD_VAL1.Collect_Value
												, TD_VAL1.OK_Value 
												, CASE WHEN EQ_KIND.Number_Of_Cavities IS NULL THEN 1 ELSE EQ_KIND.Number_Of_Cavities END AS Number_Of_Cavities
											FROM
												TD_COLLECT_HOUR_VALUE AS TD_VAL1 LEFT JOIN TD_EQUIPMENT_KIND_INFO AS EQ_KIND ON
						 							TD_VAL1.Equipment_No = EQ_KIND.Equipment_No AND TD_VAL1.Kind_Name = EQ_KIND.Kind_Name 
													AND TD_VAL1.Kind_Class = EQ_KIND.Kind_Class 
											WHERE
												TD_VAL1.Equipment_No = @Equipment_No
												AND Collect_Date > @SearchDate
												AND Collect_Date <= DATEADD(day, 1, @SearchDate) 
												AND Manufact_Flg = 2
										) AS A
									) AS B
									GROUP BY Equipment_No
									UNION
									SELECT C.Equipment_No,CASE WHEN C.HOUR_FLG = 0 THEN C.Sum_Collect_Value ELSE 0 END AS Sum_Collect_Value,
										CASE WHEN C.HOUR_FLG = 0 THEN C.Sum_OK_Value ELSE 0 END AS Sum_OK_Value
									FROM
									(
										SELECT A.Equipment_No, A.Collect_Value * A.Number_Of_Cavities AS Sum_Collect_Value
											, A.OK_Value * A.Number_Of_Cavities AS Sum_OK_Value, CASE WHEN B.OK_Value IS NULL THEN 0 ELSE 1 END AS HOUR_FLG 
										FROM 
										(
											SELECT TOP(1) TD_VAL2.Equipment_No,TD_VAL2.Kind_Name,TD_VAL2.Kind_Priority,TD_VAL2.Collect_Value,TD_VAL2.OK_Value,
												CASE WHEN EQ_KIND.Number_Of_Cavities IS NULL THEN 1 ELSE EQ_KIND.Number_Of_Cavities END AS Number_Of_Cavities
											FROM TD_COLLECT_VALUE AS TD_VAL2 
												LEFT JOIN TD_EQUIPMENT_KIND_INFO AS EQ_KIND ON TD_VAL2.Equipment_No = EQ_KIND.Equipment_No 
													AND TD_VAL2.Kind_Name = EQ_KIND.Kind_Name AND TD_VAL2.Kind_Class = EQ_KIND.Kind_Class 
											WHERE TD_VAL2.Equipment_No = @Equipment_No AND TD_VAL2.Collect_Date > @SearchDate 
												  AND TD_VAL2.Collect_Date <= DATEADD(day, 1, @SearchDate) 
											ORDER BY TD_VAL2.Collect_Date DESC
										) AS A 
										LEFT JOIN 
										(
											SELECT TD_VAL1.Equipment_No,TD_VAL1.Kind_Name,TD_VAL1.Kind_Priority,TD_VAL1.Collect_Value,TD_VAL1.OK_Value,
												CASE WHEN EQ_KIND.Number_Of_Cavities IS NULL THEN 1 ELSE EQ_KIND.Number_Of_Cavities END AS Number_Of_Cavities
											FROM TD_COLLECT_HOUR_VALUE AS TD_VAL1 LEFT JOIN TD_EQUIPMENT_KIND_INFO AS EQ_KIND ON
												TD_VAL1.Equipment_No = EQ_KIND.Equipment_No AND TD_VAL1.Kind_Name = EQ_KIND.Kind_Name AND TD_VAL1.Kind_Class = EQ_KIND.Kind_Class 
											WHERE TD_VAL1.Equipment_No = @Equipment_No AND TD_VAL1.Collect_Date > @SearchDate
														  AND TD_VAL1.Collect_Date <= DATEADD(day, 1, @SearchDate) 
														  AND TD_VAL1.Manufact_Flg = 2
										) AS B ON  A.Equipment_No = B.Equipment_No AND A.Kind_Name = B.Kind_Name AND A.Kind_Priority = B.Kind_Priority
									) AS C
								) AS D
								GROUP BY D.Equipment_No
							) AS E LEFT JOIN 
							(
								SELECT Equipment_No,SUM(Target_Value) AS TARGET_VAL
								FROM TD_TARGET_VALUE
								WHERE Equipment_No = @Equipment_No AND Start_Date = @tmpDate
								GROUP BY Equipment_No
							) AS F ON E.Equipment_No = F.Equipment_No
						END
					ELSE
						BEGIN

							--Collect_Value時の処理
							DECLARE SUM_DATA1 CURSOR FOR
							SELECT E.Equipment_No,E.SUM_VALUE,F.TARGET_VAL 
							FROM
							(
								SELECT D.Equipment_No,sum(D.Sum_Collect_Value)AS SUM_VALUE
								FROM
								(
									SELECT B.Equipment_No,sum(Collect_Value) AS Sum_Collect_Value,sum(OK_Value) AS Sum_OK_Value
									FROM
									(
										SELECT A.Equipment_No,A.Collect_Value * A.Number_Of_Cavities AS Collect_Value,
											A.OK_Value * A.Number_Of_Cavities AS OK_Value
										FROM (
											SELECT
												TD_VAL1.Equipment_No
												, TD_VAL1.Kind_Name
												, TD_VAL1.Kind_Priority
												, TD_VAL1.Collect_Value
												, TD_VAL1.OK_Value 
												, CASE WHEN EQ_KIND.Number_Of_Cavities IS NULL THEN 1 ELSE EQ_KIND.Number_Of_Cavities END AS Number_Of_Cavities
											FROM
												TD_COLLECT_HOUR_VALUE AS TD_VAL1 LEFT JOIN TD_EQUIPMENT_KIND_INFO AS EQ_KIND ON
						 							TD_VAL1.Equipment_No = EQ_KIND.Equipment_No AND TD_VAL1.Kind_Name = EQ_KIND.Kind_Name 
													AND TD_VAL1.Kind_Class = EQ_KIND.Kind_Class 
											WHERE
												TD_VAL1.Equipment_No = @Equipment_No
												AND Collect_Date > @SearchDate
												AND Collect_Date <= DATEADD(day, 1, @SearchDate) 
												AND Manufact_Flg = 2
										) AS A
									) AS B
									GROUP BY Equipment_No
									UNION
									SELECT C.Equipment_No,CASE WHEN C.HOUR_FLG = 0 THEN C.Sum_Collect_Value ELSE 0 END AS Sum_Collect_Value,
										CASE WHEN C.HOUR_FLG = 0 THEN C.Sum_OK_Value ELSE 0 END AS Sum_OK_Value
									FROM
									(
										SELECT A.Equipment_No, A.Collect_Value * A.Number_Of_Cavities AS Sum_Collect_Value
											, A.OK_Value * A.Number_Of_Cavities AS Sum_OK_Value, CASE WHEN B.OK_Value IS NULL THEN 0 ELSE 1 END AS HOUR_FLG 
										FROM 
										(
											SELECT TOP(1) TD_VAL2.Equipment_No,TD_VAL2.Kind_Name,TD_VAL2.Kind_Priority,TD_VAL2.Collect_Value,TD_VAL2.OK_Value,
												CASE WHEN EQ_KIND.Number_Of_Cavities IS NULL THEN 1 ELSE EQ_KIND.Number_Of_Cavities END AS Number_Of_Cavities
											FROM TD_COLLECT_VALUE AS TD_VAL2 
												LEFT JOIN TD_EQUIPMENT_KIND_INFO AS EQ_KIND ON TD_VAL2.Equipment_No = EQ_KIND.Equipment_No 
													AND TD_VAL2.Kind_Name = EQ_KIND.Kind_Name AND TD_VAL2.Kind_Class = EQ_KIND.Kind_Class 
											WHERE TD_VAL2.Equipment_No = @Equipment_No AND TD_VAL2.Collect_Date > @SearchDate 
												  AND TD_VAL2.Collect_Date <= DATEADD(day, 1, @SearchDate) 
											ORDER BY TD_VAL2.Collect_Date DESC
										) AS A 
										LEFT JOIN 
										(
											SELECT TD_VAL1.Equipment_No,TD_VAL1.Kind_Name,TD_VAL1.Kind_Priority,TD_VAL1.Collect_Value,TD_VAL1.OK_Value,
												CASE WHEN EQ_KIND.Number_Of_Cavities IS NULL THEN 1 ELSE EQ_KIND.Number_Of_Cavities END AS Number_Of_Cavities
											FROM TD_COLLECT_HOUR_VALUE AS TD_VAL1 LEFT JOIN TD_EQUIPMENT_KIND_INFO AS EQ_KIND ON
												TD_VAL1.Equipment_No = EQ_KIND.Equipment_No AND TD_VAL1.Kind_Name = EQ_KIND.Kind_Name AND TD_VAL1.Kind_Class = EQ_KIND.Kind_Class 
											WHERE TD_VAL1.Equipment_No = @Equipment_No AND TD_VAL1.Collect_Date > @SearchDate
														  AND TD_VAL1.Collect_Date <= DATEADD(day, 1, @SearchDate) 
														  AND TD_VAL1.Manufact_Flg = 2
										) AS B ON  A.Equipment_No = B.Equipment_No AND A.Kind_Name = B.Kind_Name AND A.Kind_Priority = B.Kind_Priority
									) AS C
								) AS D
								GROUP BY D.Equipment_No
							) AS E LEFT JOIN 
							(
								SELECT Equipment_No,SUM(Target_Value) AS TARGET_VAL
								FROM TD_TARGET_VALUE
								WHERE Equipment_No = @Equipment_No AND Start_Date = @tmpDate
								GROUP BY Equipment_No
							) AS F ON E.Equipment_No = F.Equipment_No
						END

					--データタイプチェック
					IF(@Data_Type = 2)
						BEGIN
							--カーソルをOPEN
							OPEN SUM_DATA2

							--行の取り出し
							FETCH NEXT FROM SUM_DATA2 INTO @tmpEquData,@tmpValue,@tmpTarget

							--ループ処理
							WHILE (@@FETCH_STATUS = 0)
								BEGIN
									--値の更新
									SET @SUM_Value = @tmpValue
									SET @Target_Value = @tmpTarget

									--行の取り出し
									FETCH NEXT FROM SUM_DATA2 INTO @tmpEquData,@tmpValue,@tmpTarget

								END
							--カーソルを閉じる
							CLOSE SUM_DATA2
							DEALLOCATE SUM_DATA2

						END
					ELSE
						BEGIN
							--カーソルをOPEN
							OPEN SUM_DATA1

							--行の取り出し
							FETCH NEXT FROM SUM_DATA1 INTO @tmpEquData,@tmpValue,@tmpTarget

							--ループ処理
							WHILE (@@FETCH_STATUS = 0)
								BEGIN
									--値の更新
									SET @SUM_Value = @tmpValue
									SET @Target_Value = @tmpTarget

									--行の取り出し
									FETCH NEXT FROM SUM_DATA1 INTO @tmpEquData,@tmpValue,@tmpTarget

								END
							--カーソルを閉じる
							CLOSE SUM_DATA1
							DEALLOCATE SUM_DATA1
						END

					--実績がNULLの場合、次の日へ移動し、データをINSERTしない
					IF NOT(@SUM_Value IS NULL)
						BEGIN
							
							--=================================================st 2017/03/15 takasima 該当日の最初の実績値を引く処理を追加
							--初期化
							SET @tmpCollect_Value = 0
							SET @tmpOK_Value = 0
							SET @tmpNum_Cav = 0

							DECLARE START_VAL CURSOR FOR
							SELECT TOP(1) TD_CO.Collect_Value,TD_CO.OK_Value,
								CASE WHEN TD_EQ.Number_Of_Cavities IS NULL THEN 1 ELSE TD_EQ.Number_Of_Cavities END AS Number_Of_Cavities
							FROM TD_COLLECT_VALUE AS TD_CO
								LEFT JOIN TD_EQUIPMENT_KIND_INFO AS TD_EQ ON TD_CO.Equipment_No = TD_EQ.Equipment_No 
									AND TD_CO.Kind_Name = TD_EQ.Kind_Name AND TD_CO.Kind_Class = TD_EQ.Kind_Class
							WHERE TD_CO.Equipment_No = @Equipment_No 
								AND TD_CO.Collect_Date > @SearchDate 
								AND TD_CO.Collect_Date <= DATEADD(DAY,1,@SearchDate)
							ORDER BY TD_CO.Collect_Date ASC

							--カーソルをOPEN
							OPEN START_VAL

							--行の取り出し
							FETCH NEXT FROM START_VAL INTO @tmpCollect_Value,@tmpOK_Value,@tmpNum_Cav
							
							--ループ処理
							WHILE (@@FETCH_STATUS = 0 )
								BEGIN
									--取得完了


									--行の取り出し
									FETCH NEXT FROM START_VAL INTO @tmpCollect_Value,@tmpOK_Value,@tmpNum_Cav
								END
							--カーソルを閉じる
							CLOSE START_VAL
							DEALLOCATE START_VAL

							--データタイプチェック
							IF(@Data_Type = 2)
								BEGIN
									--OK_Valueを使用
									--最初の生産実績値(OK数)を引く
									SET @SUM_Value = @SUM_Value - (@tmpOK_Value * @tmpNum_Cav)
								END
							ELSE
								BEGIN
									--Collect_Valueを使用
									--最初の生産実績値(実績値)を引く
									SET @SUM_Value = @SUM_Value - (@tmpOK_Value * @tmpNum_Cav)

								END
							
							--マイナスチェック
							IF(@SUM_Value < 0)
								BEGIN
									--強制的に0に書き換える
									SET @SUM_Value = 0
											
								END

							--=================================================ed 2017/03/15 takasima 該当日の最初の実績値を引く処理を追加
							
							--*******************************************************
							--　　　　　運転時間の取得
							--*******************************************************
							DECLARE @tmpGet_Time AS int
			
							DECLARE OPE_VAL CURSOR FOR 
							SELECT Equipment_No,OPE_TIME
							--=========================================================st 時分処理に変更 20170817 takasima
							--FROM MAN_OperationTime(@Equipment_No,@tmpDate,1,24,@Start_Hour,0)

							FROM MAN_OperationTime(@Equipment_No,@tmpDate,1,24,@Start_Hour,@Start_Min,0)
							--=========================================================st 時分処理に変更 20170817 takasima

							--カーソルをOPEN
							OPEN OPE_VAL

							--行の取り出し
							FETCH NEXT FROM OPE_VAL INTO @tmpEquData,@tmpGet_Time
			
							--ループ処理
							WHILE (@@FETCH_STATUS = 0)
								BEGIN
									--目標値の更新
									SET @Operation_Time = @tmpGet_Time

									--行の移動
									FETCH NEXT FROM OPE_VAL INTO @tmpEquData,@tmpGet_Time
								END

							--カーソルを閉じる
							CLOSE OPE_VAL
							DEALLOCATE OPE_VAL

							--*******************************************************
							--　　　　　総運転時間の取得
							--*******************************************************
			
							DECLARE PRO_VAL CURSOR FOR
							SELECT Equipment_No,Product_Time
							--=========================================================st 時分処理に変更 20170817 takasima
							--FROM MAN_ProductionTime(@Equipment_No,@tmpDate,1,24,@Start_Hour,1)

							FROM MAN_ProductionTime(@Equipment_No,@tmpDate,1,24,@Start_Hour,@Start_Min,1)
							--=========================================================ed 時分処理に変更 20170817 takasima
			
							--カーソルのOPEN
							OPEN PRO_VAL 

							--行の取り出し
							FETCH NEXT FROM PRO_VAL INTO @tmpEquData,@tmpGet_Time

							--ループ処理
							WHILE (@@FETCH_STATUS = 0)
								BEGIN
									--目標値の更新
									SET @ALL_Operation_Time = @tmpGet_Time

									--行の移動
									FETCH NEXT FROM PRO_VAL INTO @tmpEquData,@tmpGet_Time
								END

							--カーソルを閉じる
							CLOSE PRO_VAL
							DEALLOCATE PRO_VAL

							--データの挿入
							INSERT INTO @retTbl VALUES (@tmpDate,@Equipment_No,@SUM_Value,@Target_Value,@Operation_Time,@ALL_Operation_Time)

						END

					--データの初期化
					SET @SUM_Value = NULL
					SET @Target_Value = NULL
					SET @Operation_Time = NULL
					SET @ALL_Operation_Time = NULL

					--一時格納日付を次の日へ移動
					SET @tmpDate = DATEADD(day,1,@tmpDate)
				END

			--行の取り出し
			FETCH NEXT FROM EQU_VAL INTO @Equipment_No

		END
	--カーソルを閉じる
	CLOSE EQU_VAL
	DEALLOCATE EQU_VAL

Proc_End:

	RETURN
END

go

