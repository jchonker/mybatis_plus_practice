
/***********************************************************************************
*
* 製品名        ：上位システム連携機能
* 処理名        ：装置設定　展開用トリガ
* トリガ名		：TR3_TM_EQUIPMENT
* 概要          ：TM_EQUIPMENT_EXCLE→TM_EQUIPMENT_INFO、TM_EQUIPMENT_NAMEへの展開(DELETE)
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/09/13
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR3_TM_EQUIPMENT] ON [dbo].[TM_EQUIPMENT_EXCEL] AFTER DELETE 
AS
BEGIN

	DECLARE @Equipment_No as int
	DECLARE @Lang_Mode as tinyint

	DECLARE @Chk_Equipment_No as int
	DECLARE @Delete_Flg as tinyint
    
    DECLARE DeleteData CURSOR FOR
    SELECT Equipment_No,Lang_Mode
    FROM DELETED
    
    --カーソルをオープンし、内容を確認
    OPEN DeleteData
    
    --行の取り出し
    FETCH NEXT FROM DeleteData INTO @Equipment_No,@Lang_Mode
    
    --ループ処理
    WHILE (@@FETCH_STATUS = 0)
    	BEGIN
			--フラグ初期化
			SET @Delete_Flg = 1

			--消そうとしているデータについて他の言語で使用しているかを確認
			DECLARE ChkDelete CURSOR FOR
			SELECT Equipment_No
			FROM TM_EQUIPMENT_NAME
			WHERE Equipment_No = @Equipment_No AND Lang_Mode <> @Lang_Mode

			--カーソルをオープンし、内容を確認
			OPEN ChkDelete

			--行の取り出し
			FETCH NEXT FROM ChkDelete INTO @Chk_Equipment_No

			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					--フラグを0にし、削除を行わない
					SET @Delete_Flg = 0

					--行の取り出し
					FETCH NEXT FROM ChkDelete INTO @Chk_Equipment_No

				END

			--削除フラグチェック
			IF(@Delete_Flg = 1)
				BEGIN
					--装置情報設定(TM_EQUIPMENT_INFO)への展開
					DELETE FROM TM_EQUIPMENT_INFO WHERE Equipment_No = @Equipment_No

				END

			--装置名称設定(TM_EQUIPMENT_NAME)への展開
			DELETE FROM TM_EQUIPMENT_NAME WHERE Equipment_No = @Equipment_No AND Lang_Mode = @Lang_Mode
    
    		--次の行へ移動
    		FETCH NEXT FROM DeleteData INTO @Equipment_No,@Lang_Mode

			--カーソルを閉じる
			CLOSE ChkDelete
			DEALLOCATE ChkDelete
    
    	END
    --カーソルを閉じる
    CLOSE DeleteData
    DEALLOCATE DeleteData

END

go

