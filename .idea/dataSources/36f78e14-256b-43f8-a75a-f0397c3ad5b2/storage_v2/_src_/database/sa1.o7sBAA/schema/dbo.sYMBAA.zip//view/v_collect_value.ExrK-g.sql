
CREATE VIEW [dbo].[V_COLLECT_VALUE] AS 
	SELECT COL_VAL.*,INST_LOG.Sch_No
	FROM [dbo].[TD_COLLECT_VALUE] AS COL_VAL
	LEFT JOIN [dbo].[TD_INSTRUCTION_LOG] AS INST_LOG ON COL_VAL.Inst_No = INST_LOG.Inst_No
go

exec sp_addextendedproperty 'MS_Description', '製造実績データビュー', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE'
go

exec sp_addextendedproperty 'MS_Description', '装置No.', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN',
                            'Equipment_No'
go

exec sp_addextendedproperty 'MS_Description', '収集日時', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN',
                            'Collect_Date'
go

exec sp_addextendedproperty 'MS_Description', '品目コード', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN', 'Kind_Name'
go

exec sp_addextendedproperty 'MS_Description', '品目区分', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN', 'Kind_Class'
go

exec sp_addextendedproperty 'MS_Description', 'シーケンスNo.', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN',
                            'Kind_Priority'
go

exec sp_addextendedproperty 'MS_Description', 'ロット情報', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN', 'Lot_Name'
go

exec sp_addextendedproperty 'MS_Description', '実績値', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN',
                            'Collect_Value'
go

exec sp_addextendedproperty 'MS_Description', 'OK数', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN', 'OK_Value'
go

exec sp_addextendedproperty 'MS_Description', 'NG数', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN', 'NG_Value'
go

exec sp_addextendedproperty 'MS_Description', '転送フラグ', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN', 'Trans_Flg'
go

exec sp_addextendedproperty 'MS_Description', '生産完了フラグ', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN',
                            'Comp_Product_Flg'
go

exec sp_addextendedproperty 'MS_Description', '指示No.', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN', 'Inst_No'
go

exec sp_addextendedproperty 'MS_Description', '最終更新日', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN',
                            'Last_Update'
go

exec sp_addextendedproperty 'MS_Description', 'RowNo', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN', 'Row_No'
go

exec sp_addextendedproperty 'MS_Description', 'スケジュールNo.', 'SCHEMA', 'dbo', 'VIEW', 'V_COLLECT_VALUE', 'COLUMN',
                            'Sch_No'
go

