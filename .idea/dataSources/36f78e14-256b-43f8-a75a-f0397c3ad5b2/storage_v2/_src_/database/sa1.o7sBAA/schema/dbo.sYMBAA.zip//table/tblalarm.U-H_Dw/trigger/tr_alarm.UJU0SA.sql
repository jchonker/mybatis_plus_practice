
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：警報履歴データ作成トリガ
* トリガ名		：TR_ALARM
* 概要          ：警報一覧テーブルから警報履歴データへの展開
* バージョン    ：1.12.0.0
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/10/21
* 更新者        ：Takasima Hironori
* 更新日        ：2017/07/08
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR_ALARM] ON [dbo].[TBLALARM] AFTER INSERT 
AS
BEGIN
	DECLARE @Node_ID as int				--ノードID
	DECLARE @Tag_No as bigint			--タグNo.
	DECLARE @Get_Date as datetime		--取得日付
	DECLARE @Alarm_Status as int		--警報種別
	DECLARE @EquipmentNo as int			--装置No.
	DECLARE @AlarmCode as int			--警報コード
	DECLARE @PROCESS_OCC as int			--処理区分(発生)
	DECLARE @PROCESS_REST as int		--処理区分(復旧)
	DECLARE @ALARM_OCC as int			--警報状態(発生)
	DECLARE @ALARM_REST as int			--警報状態(復旧)
	DECLARE @Kind_Name as varchar(40)	--品目コード
	DECLARE @Kind_Class as varchar(40)	--品目区分
	DECLARE @tmRecoveryDate as datetime

	DECLARE @tmp_Kind_Name as varchar(40)	--テンポラリ(品目コード)
	DECLARE @tmp_Kind_Class as varchar(40)	--テンポラリ(品目区分)

	--初期化
	SET @PROCESS_OCC = 0
	SET @PROCESS_REST = 1
	SET @ALARM_OCC = 1
	SET @ALARM_REST = 0
	
	--INSERTされた行から各種情報を取得
	SELECT 	@Node_ID = NodeId,
			@Tag_No = TagNo,
			@Get_Date = tmDate,
			@Alarm_Status = nStatus,
			@tmRecoveryDate = tmRecoveryDate
	FROM INSERTED;
	
	--警報情報マスタよりタグ情報を取得
	DECLARE MasterData CURSOR FOR
	SELECT Equipment_No,Alarm_Code
	FROM TM_ALARM_INFO
	WHERE	Node_Id = 	@Node_ID
	 AND	Tag_No = 	@Tag_No
	
	--カーソルをオープンし、内容を確認
	OPEN MasterData

	--行の取り出し(装置No.、警報コード)
	FETCH NEXT FROM MasterData INTO @EquipmentNo,@AlarmCode

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--初期化
			SET @tmp_Kind_Name = ''
			SET @tmp_Kind_Class = ''
			SET @Kind_Name = ''
			SET @Kind_Class = ''
			
			--警報種別(発生/復旧)の確認
			IF(@Alarm_Status = @ALARM_OCC)
				BEGIN
					--【警報種別が「発生」の場合】
					
					DECLARE @iGetFlg AS int				--警報データ取得フラグ
					DECLARE @Alarm_Date AS datetime		--警報日時
					
					--初期化
					SET @iGetFlg = 0
					
					--以前に警報が発生しているかを確認
					DECLARE curGetAlarm CURSOR FOR
					SELECT St_Date
					FROM TD_COLLECT_ALARM
					WHERE Equipment_No = @EquipmentNo
					  AND Alarm_Code = @AlarmCode
					  AND St_Date = @Get_Date
					
					--カーソルをオープンし、内容を確認
					OPEN curGetAlarm
					
					--行の取り出し(警報発生日時)
					FETCH NEXT FROM curGetAlarm INTO @Alarm_Date
					
					--処理の繰り返し
					WHILE (@@FETCH_STATUS = 0)
						BEGIN
							--既に同じ時刻の警報データあり
							SET @iGetFlg = 1

							--行の取り出し(警報発生日時)
							FETCH NEXT FROM curGetAlarm INTO @Alarm_Date
						END

					--カーソルを閉じる
					CLOSE curGetAlarm
					DEALLOCATE curGetAlarm
					
					--フラグチェック
					IF (@iGetFlg = 0)
						BEGIN
							--現在の生産中の品目コードや品目区分を取得する
							--(製造開始フラグが警報の発生時刻に一番近い項目を取得)
							DECLARE curGet_Kind CURSOR FOR
							SELECT TOP(1) Kind_Name,Kind_Class
							FROM TD_COLLECT_HOUR_VALUE
							WHERE Equipment_No = @EquipmentNo
								AND Manufact_Flg = 1
								AND Collect_Date <= @Get_Date

							--カーソルをオープンし、内容を確認
							OPEN curGet_Kind

							--行の取り出し(品種情報)
							FETCH NEXT FROM curGet_Kind INTO @tmp_Kind_Name,@tmp_Kind_Class

							--処理の繰り返し
							WHILE (@@FETCH_STATUS = 0)
								BEGIN
									--取得した内容を反映
									SET @Kind_Name = @tmp_Kind_Name
									SET @Kind_Class = @tmp_Kind_Class

									--行の取り出し(品種情報)
									FETCH NEXT FROM curGet_Kind INTO @tmp_Kind_Name,@tmp_Kind_Class
								END

							--カーソルを閉じる
							CLOSE curGet_Kind
							DEALLOCATE curGet_Kind

							--警報履歴データの挿入
							INSERT INTO TD_COLLECT_ALARM (Equipment_No,Alarm_Code,St_Date,Ed_Date,Process_Flg,Kind_Name,Kind_Class,Last_Update) 
							VALUES (@EquipmentNo,@AlarmCode,@Get_Date,'',@PROCESS_OCC,@Kind_Name,@Kind_Class,GETDATE())
						END
				END
			ELSE IF(@Alarm_Status = @ALARM_REST)
				BEGIN
					--【警報種別が「復旧」の場合】

					DECLARE @AlarmDate as datetime			--警報発生日付
					DECLARE @TIME_INT as int				--警報時間

					--警報が発生した時刻の取得
					DECLARE curAlarm CURSOR FOR
					SELECT St_Date
					FROM TD_COLLECT_ALARM
					--==================================================st 集計処理追加 20170725 takasima
					--WHERE Equipment_No = @EquipmentNo
					--  AND Alarm_Code = @AlarmCode
					--  AND Process_Flg = @PROCESS_OCC

					WHERE St_Date = @tmRecoveryDate
					  AND Equipment_No = @EquipmentNo
					  AND Alarm_Code = @AlarmCode
					  AND Process_Flg = @PROCESS_OCC
					--==================================================ed 集計処理追加 20170725 takasima

					--カーソルをオープンし、内容を確認
					OPEN curAlarm

					--行の取り出し(警報発生日付)
					FETCH NEXT FROM curAlarm INTO @AlarmDate

					WHILE (@@FETCH_STATUS = 0)
						BEGIN

							--時刻の差を求める
							SET @TIME_INT = datediff(SECOND,@AlarmDate,@Get_Date)

							--時刻戻り時には書込みを行わない(マイナス値となるため)
							IF(@TIME_INT > 0)
								BEGIN
									--警報履歴データの更新
									UPDATE TD_COLLECT_ALARM SET Ed_Date = @Get_Date,Alarm_Time = @TIME_INT,Process_Flg = @PROCESS_REST,Trans_Flg = 0,Last_Update = GETDATE() 
									WHERE (Equipment_No = @EquipmentNo AND Alarm_Code = @AlarmCode AND St_Date = @AlarmDate)
								END
							ELSE
								BEGIN
									--警報発生時間を強制的に「0」にし、復旧扱いに変更
									SET @TIME_INT = 0

									UPDATE TD_COLLECT_ALARM SET Ed_Date = @Get_Date,Alarm_Time = @TIME_INT,Process_Flg = @PROCESS_REST,Last_Update = GETDATE() 
									WHERE (Equipment_No = @EquipmentNo AND Alarm_Code = @AlarmCode AND St_Date = @AlarmDate)
								END
							--次の行へ移動(警報発生日付)
							FETCH NEXT FROM curAlarm INTO @AlarmDate

						END
					--カーソルを閉じる
					CLOSE curAlarm
					DEALLOCATE curAlarm

				END

			--次の行へ移動(装置No.、警報コード)
			FETCH NEXT FROM MasterData INTO @EquipmentNo,@AlarmCode

		END
	
	--カーソルを閉じる
	CLOSE MasterData
	DEALLOCATE MasterData

NON_DATA:

END

go

