
/***********************************************************************************
*
* 製品名        ：上位システム連携機能
* 処理名        ：装置設定　展開用トリガ
* トリガ名		：TR2_TM_EQUIPMENT
* 概要          ：TM_EQUIPMENT_EXCLE→TM_EQUIPMENT_INFO、TM_EQUIPMENT_NAMEへの展開(UPDATE)
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/12/19
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR2_TM_EQUIPMENT] ON [dbo].[TM_EQUIPMENT_EXCEL] AFTER UPDATE 
AS
BEGIN

	DECLARE @Equipment_No as int
	DECLARE @Lang_Mode as tinyint
	DECLARE @Unit_No as int
	DECLARE @Collection_Mode as tinyint
	DECLARE @Group_No as int
	DECLARE @Item_No as int
	DECLARE @Tag_No as bigint
	DECLARE @Decimal_Place as int
	DECLARE @Equipment_Name as varchar(32)
	DECLARE @Abbreviation_Name as varchar(8)
	DECLARE @Old_Equipment as int
	DECLARE @Old_Lang_Mode as tinyint

	DECLARE @Chk_Flg as tinyint
	DECLARE @Data_Flg as tinyint
	DECLARE @Chk_Equipment_No as int
	DECLARE @Chk_Equipment_No2 as int
	DECLARE @Info_Update_Flg as tinyint

	DECLARE @COLLECT_MODE_TAG as int

	--初期化
	set @COLLECT_MODE_TAG = 1

	DECLARE DeleteData CURSOR FOR
	SELECT Equipment_No,Lang_Mode
	FROM DELETED

	DECLARE UpdateData CURSOR FOR
	SELECT Equipment_No, Lang_Mode, Unit_No, Collection_Mode, Group_No, Item_No, 
		Decimal_Place, Equipment_Name, Abbreviation_Name
	FROM INSERTED

    --カーソルをオープンし、内容を確認
    OPEN DeleteData
	OPEN UpdateData
    
    --行の取り出し
	FETCH NEXT FROM DeleteData INTO @Old_Equipment,@Old_Lang_Mode

    FETCH NEXT FROM UpdateData INTO @Equipment_No, @Lang_Mode, @Unit_No, @Collection_Mode, @Group_No, @Item_No, 
		@Decimal_Place, @Equipment_Name, @Abbreviation_Name
    
    --ループ処理
    WHILE (@@FETCH_STATUS = 0)
    	BEGIN
			--初期化
			SET @Chk_Equipment_No = 0
			SET @Chk_Equipment_No2 = 0
			--フラグ初期化
			SET @Chk_Flg = 0
			SET @Info_Update_Flg = 0

			--装置情報変更確認
			IF(@Old_Equipment <> @Equipment_No)
				BEGIN
					--変更フラグをONする
					SET @Chk_Flg = 1

				END

			--収集種別の確認
			IF (@Collection_Mode = @COLLECT_MODE_TAG)
				BEGIN
					--タグNo.の生成
					set @Tag_No =CONVERT(bigint, convert(varchar(3), @Group_No) + right('0000000' + convert(varchar(10), @Item_No),7) + '00')

				END

			--変更フラグ確認
			IF(@Chk_Flg = 1)
				BEGIN
					--主キーが変更されている場合

					--装置名称設定(TM_EQUIPMENT_NAME)への展開
					UPDATE TM_EQUIPMENT_NAME SET Equipment_No = @Equipment_No,Lang_Mode = @Lang_Mode, Equipment_Name = @Equipment_Name,
							Abbreviation_Name = @Abbreviation_Name,Last_Update = GETDATE()
						WHERE Equipment_No = @Old_Equipment AND Lang_Mode = @Old_Lang_Mode

					--フラグ初期化
					SET @Data_Flg = 0

					--変更した内容が情報テーブル内に存在するかを確認
					DECLARE ChkInfoData CURSOR FOR
					SELECT Equipment_No
					FROM TM_EQUIPMENT_NAME
					WHERE Equipment_No = @Old_Equipment

					--カーソルをオープンし、内容を確認
					OPEN ChkInfoData

					--行の取り出し
					FETCH NEXT FROM ChkInfoData INTO @Chk_Equipment_No

					--ループ処理
					WHILE (@@FETCH_STATUS = 0)
						BEGIN
							--フラグON
							SET @Info_Update_Flg = 1

							--行の取り出し
							FETCH NEXT FROM ChkInfoData INTO @Chk_Equipment_No
						END

					--フラグ確認
					IF(@Info_Update_Flg = 1)
						BEGIN
							--他の言語で同様の情報を使用しているため、新たに情報を追加する必要あり

							--既に情報テーブル内に存在するかを確認
							DECLARE ChkInfoData2 CURSOR FOR
							SELECT Equipment_No
							FROM TM_EQUIPMENT_INFO
							WHERE Equipment_No = @Equipment_No

							--カーソルをオープンし、内容を確認
							OPEN ChkInfoData2

							--行の取り出し
							FETCH NEXT FROM ChkInfoData2 INTO @Chk_Equipment_No2

							--ループ処理
							WHILE (@@FETCH_STATUS = 0)
								BEGIN
									--データあり
									SET @Data_Flg = 1

									--行の取り出し
									FETCH NEXT FROM ChkInfoData2 INTO @Chk_Equipment_No2
								
								END
							--データ有無チェック
							IF(@Data_Flg = 1)
								BEGIN
									--データあり
									--情報データを更新する
									UPDATE TM_EQUIPMENT_INFO SET Equipment_No = @Equipment_No, Unit_No = @Unit_No,Collection_Mode = @Collection_Mode,
											Group_No = @Group_No,Item_No = @Item_No,Tag_No = @Tag_No,Decimal_Place = @Decimal_Place,Last_Update = GETDATE()
										WHERE Equipment_No = @Equipment_No
								END
							ELSE
								BEGIN
									--データなし
									--情報データを新規作成
									INSERT INTO TM_EQUIPMENT_INFO (Equipment_No, Unit_No, Collection_Mode, Group_No, Item_No, Tag_No, Decimal_Place, Last_Update)
										VALUES (@Equipment_No, @Unit_No, @Collection_Mode, @Group_No, @Item_No, @Tag_No, @Decimal_Place,GETDATE())

								END

							--カーソルを閉じる
							CLOSE ChkInfoData2
							DEALLOCATE ChkInfoData2

						END
					ELSE
						BEGIN
							--他の言語で同様の情報は使用していないため、一括更新を行う。

							--装置情報設定(TM_EQUIPMENT_INFO)への展開
							UPDATE TM_EQUIPMENT_INFO SET Equipment_No = @Equipment_No, Unit_No = @Unit_No,Collection_Mode = @Collection_Mode,
									Group_No = @Group_No,Item_No = @Item_No,Tag_No = @Tag_No,Decimal_Place = @Decimal_Place,Last_Update = GETDATE()
								WHERE Equipment_No = @Old_Equipment

						END
					--カーソルを閉じる
					CLOSE ChkInfoData
					DEALLOCATE ChkInfoData

				END
			ELSE
				BEGIN
					--主キーが変更されていない場合

					--装置名称設定(TM_EQUIPMENT_NAME)への展開
					UPDATE TM_EQUIPMENT_NAME SET Equipment_No = @Equipment_No,Lang_Mode = @Lang_Mode, Equipment_Name = @Equipment_Name,
							Abbreviation_Name = @Abbreviation_Name,Last_Update = GETDATE()
						WHERE Equipment_No = @Old_Equipment AND Lang_Mode = @Old_Lang_Mode

					--装置情報設定(TM_EQUIPMENT_INFO)への展開
					UPDATE TM_EQUIPMENT_INFO SET Equipment_No = @Equipment_No, Unit_No = @Unit_No,Collection_Mode = @Collection_Mode,
							Group_No = @Group_No,Item_No = @Item_No,Tag_No = @Tag_No,Decimal_Place = @Decimal_Place,Last_Update = GETDATE()
						WHERE Equipment_No = @Old_Equipment

				END

    		--次の行へ移動
		    FETCH NEXT FROM UpdateData INTO @Equipment_No, @Lang_Mode, @Unit_No, @Collection_Mode, @Group_No, @Item_No, 
				@Decimal_Place, @Equipment_Name, @Abbreviation_Name
    
    	END
    --カーソルを閉じる
    CLOSE UpdateData
	CLOSE DeleteData
    DEALLOCATE UpdateData
	DEALLOCATE DeleteData

END

go

