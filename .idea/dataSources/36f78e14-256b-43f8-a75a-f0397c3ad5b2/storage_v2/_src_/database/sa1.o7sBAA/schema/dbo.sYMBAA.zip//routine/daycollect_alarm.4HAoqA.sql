
/***********************************************************************************
*
* 製品名			：生産分析機能
* 処理名			：日データ収集(警報履歴)
* ファンクション名	：DayCollect_Alarm
* 概要				：稼働監視画面用警報履歴データ収集処理
* バージョン		：1.12.0.0
*
* 作成者			：Takasima Hironori
* 作成日			：2017/07/08
* 更新者			：
* 更新日			：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE PROCEDURE [dbo].[DayCollect_Alarm]
(
	@Equipment_No			int,		--装置No.
	@Target_Date			date		--収集対象日付
)
AS
BEGIN
	
	DECLARE @Start_Hour as int
	DECLARE @Start_Min as int
	DECLARE @tmpSetData as varchar(20)
	DECLARE @Start_Date as datetime
	DECLARE @End_Date as datetime
	DECLARE @tmpData as int
	DECLARE @Error_Count as int
	DECLARE @Error_Time as int

	--初期値
	SET @Start_Hour = -1
	SET @Start_Min = -1
	SET @tmpData = 0
	SET @Error_Count = 0
	SET @Error_Time = 0

	--収集開始時刻の取得
	DECLARE OptionSet1 CURSOR FOR
	SELECT Setting_Value
	FROM TM_OPTION_SETTING
	WHERE Key_Name = 'Start_Hour'

	--カーソルをオープンし、内容を確認
	OPEN OptionSet1

	--行の取り出し
	FETCH NEXT FROM OptionSet1 INTO @tmpSetData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			--数値に変換
			SET @Start_Hour = CONVERT(int,@tmpSetData)

			--行の取り出し
			FETCH NEXT FROM OptionSet1 INTO @tmpSetData
		END
	--カーソルを閉じる
	CLOSE OptionSet1
	DEALLOCATE OptionSet1

	--収集開始時刻の取得
	DECLARE OptionSet2 CURSOR FOR
	SELECT Setting_Value
	FROM TM_OPTION_SETTING
	WHERE Key_Name = 'Start_Min'

	--カーソルをオープンし、内容を確認
	OPEN OptionSet2

	--行の取り出し
	FETCH NEXT FROM OptionSet2 INTO @tmpSetData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			--数値に変換
			SET @Start_Min = CONVERT(int,@tmpSetData)

			--行の取り出し
			FETCH NEXT FROM OptionSet2 INTO @tmpSetData
		END
	--カーソルを閉じる
	CLOSE OptionSet2
	DEALLOCATE OptionSet2

	--処理確認
	IF((@Start_Hour = -1) or (@Start_Min = -1))
		BEGIN
			--処理を抜ける
			goto proc_end

		END

	--集計対象日時の設定
	--検索開始日時
	SET @Start_Date = CONVERT(datetime,FORMAT(@Target_Date,'yyyy/MM/dd') + ' ' + RIGHT('00' + CONVERT(varchar, @Start_Hour),2) + ':' + RIGHT('00' + CONVERT(varchar, @Start_Min),2) + ':00')
	--検索終了日時
	SET @End_Date = DATEADD(day,1,@Start_Date)

	--故障回数の取得
	DECLARE ERR_COUNT CURSOR FOR
	SELECT COUNT(A.St_Date) AS Alarm_Count
	FROM (
		SELECT TD_AL1.Equipment_No,TD_AL1.Alarm_Code,TD_AL1.St_Date
		FROM TD_COLLECT_ALARM AS TD_AL1
		WHERE TD_AL1.Equipment_No = @Equipment_No
			AND TD_AL1.St_Date > @Start_Date
			AND TD_AL1.St_Date <= @End_Date
		) AS A LEFT JOIN TM_ALARM_INFO AS TM_IN ON A.Equipment_No = TM_IN.Equipment_No
			AND A.Alarm_Code = TM_IN.Alarm_Code
	GROUP BY A.Equipment_No

	--カーソルをOPEN
	OPEN ERR_COUNT

	--行の取り出し
	FETCH NEXT FROM ERR_COUNT INTO @tmpData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--データの格納
			SET @Error_Count = @tmpData

			--行の取り出し
			FETCH NEXT FROM ERR_COUNT INTO @tmpData
		END
	--カーソルを閉じる
	CLOSE ERR_COUNT
	DEALLOCATE ERR_COUNT

	--初期化
	SET @tmpData = 0

	--故障時間の取得
	DECLARE ERR_TIME CURSOR FOR
	SELECT sum(D.Data_Count) AS Sum_Time
	FROM (
		SELECT C.Equipment_No,C.Alarm_Code,SUM(C.Data_Count) AS Data_Count
		FROM(
			SELECT *
			FROM(
				SELECT TD_AL1.Equipment_No,TD_AL1.Alarm_Code,sum(TD_AL1.Alarm_Time) AS Data_Count
				FROM TD_COLLECT_ALARM AS TD_AL1
				WHERE TD_AL1.Equipment_No = @Equipment_No
					AND TD_AL1.St_Date > @Start_Date
					AND TD_AL1.St_Date <= @End_Date
					AND NOT(TD_AL1.Alarm_Time IS NULL)
				GROUP BY TD_AL1.Equipment_No,TD_AL1.Alarm_Code
			) AS A 
			UNION (
				SELECT B.Equipment_No,B.Alarm_Code,sum(B.Data_Count) AS Data_Count
				FROM (
					SELECT TD_AL2.Equipment_No,TD_AL2.Alarm_Code,
					CASE WHEN @End_Date <= GETDATE() 
							THEN DATEDIFF(second,TD_AL2.St_Date,@End_Date)
						WHEN @End_Date > GETDATE() 
							THEN DATEDIFF(second,TD_AL2.St_Date,GETDATE()) END AS Data_Count
					FROM TD_COLLECT_ALARM AS TD_AL2
					WHERE TD_AL2.Equipment_No = @Equipment_No
						AND TD_AL2.St_Date > @Start_Date
						AND TD_AL2.St_Date <= @End_Date
						AND TD_AL2.Alarm_Time IS NULL
					) AS B
					GROUP BY B.Equipment_No,B.Alarm_Code
				)
			) AS C
			GROUP BY C.Equipment_No,C.Alarm_Code
		) AS D LEFT JOIN TM_ALARM_INFO AS TM_AL ON D.Equipment_No = TM_AL.Equipment_No AND D.Alarm_Code = TM_AL.Alarm_Code
	GROUP BY D.Equipment_No

	--カーソルをOPEN
	OPEN ERR_TIME

	--行の取り出し
	FETCH NEXT FROM ERR_TIME INTO @tmpData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--データの格納
			SET @Error_Time = @tmpData

			--行の取り出し
			FETCH NEXT FROM ERR_TIME INTO @tmpData
		END
	--カーソルを閉じる
	CLOSE ERR_TIME
	DEALLOCATE ERR_TIME

	--データの削除
	DELETE FROM TD_COLLECT_DAY_ALARM WHERE Equipment_No = @Equipment_No AND Data_Date = @Target_Date

	--データの挿入
	INSERT INTO TD_COLLECT_DAY_ALARM (Data_Date, Equipment_No, Error_Count, Error_Time, Last_Update)
	VALUES (@Target_Date,@Equipment_No,@Error_Count,@Error_Time,GETDATE())
	
proc_end:

END

go

