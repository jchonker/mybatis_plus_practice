
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：警報履歴データ作成トリガ
* トリガ名		：TR_COLLECT_ALARM
* 概要          ：警報履歴データから警報履歴集計データへの展開
* バージョン    ：1.12.0.0
*
* 作成者        ：Takasima Hironori
* 作成日        ：2017/07/24
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR_COLLECT_ALARM] ON [dbo].[TD_COLLECT_ALARM] AFTER UPDATE
AS
BEGIN

	DECLARE @Get_Date as datetime		--取得日付
	DECLARE @EquipmentNo as int			--装置No.

	--INSERTされた行から各種情報を取得
	SELECT 	@EquipmentNo = Equipment_No,
			@Get_Date = St_Date
	FROM INSERTED;

	DECLARE @Target_Date as date
	DECLARE @Start_Hour as int
	DECLARE @Start_Min as int
	DECLARE @tmpSetData as varchar(20)

	SET @Start_Hour = -1
	SET @Start_Min = -1

	--収集開始時刻の取得
	DECLARE OptionSet1 CURSOR FOR 
	SELECT Setting_Value
	FROM TM_OPTION_SETTING
	WHERE Key_Name = 'Start_Hour'

	--カーソルをオープンし、内容を確認
	OPEN OptionSet1

	--行の取り出し
	FETCH NEXT FROM OptionSet1 INTO @tmpSetData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--数値に変換する
			SET @Start_Hour = CONVERT(int,@tmpSetData)

			--行の取り出し
			FETCH NEXT FROM OptionSet1 INTO @tmpSetData

		END
	--カーソルを閉じる
	CLOSE OptionSet1
	DEALLOCATE OptionSet1

		--収集開始時刻の取得
	DECLARE OptionSet2 CURSOR FOR 
	SELECT Setting_Value
	FROM TM_OPTION_SETTING
	WHERE Key_Name = 'Start_Min'

	--カーソルをオープンし、内容を確認
	OPEN OptionSet2

	--行の取り出し
	FETCH NEXT FROM OptionSet2 INTO @tmpSetData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--数値に変換する
			SET @Start_Min = CONVERT(int,@tmpSetData)

			--行の取り出し
			FETCH NEXT FROM OptionSet2 INTO @tmpSetData

		END
	--カーソルを閉じる
	CLOSE OptionSet2
	DEALLOCATE OptionSet2
	
	--処理の確認
	IF((@Start_Hour = -1) or (@Start_Min = -1))
		BEGIN
			--処理を抜ける
			goto NON_DATA
		END

	DECLARE @tmpHour as int
	DECLARE @tmpMin as int
	DECLARE @tmpSec as int

	SET @Target_Date = CONVERT(date, format(@Get_Date,'yyyy/MM/dd'))
	SET @tmpHour = CONVERT(int,format(@Get_Date,'HH'))
	SET @tmpMin = CONVERT(int,FORMAT(@Get_Date,'mm'))

		--時刻チェック
	if((@tmpHour < @Start_Hour) OR ((@tmpHour = @Start_Hour) AND (@tmpMin <= @Start_Min)))
		BEGIN
			--前日にずらす
			SET @Target_Date = DATEADD(day,-1,@Target_Date)
		END

	--集計処理を実行
	EXECUTE DayCollect_Alarm @EquipmentNo,@Target_Date

NON_DATA:

END

go

