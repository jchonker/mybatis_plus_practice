
/***********************************************************************************
*
* 製品名        ：上位システム連携機能
* 処理名        ：品目マスタ　展開用トリガ(UPDATE用)
* トリガ名		：TR2_TM_KIND
* 概要          ：TM_KIND_EXCLE→TM_KIND_INFO、TM_KIND_NAMEへの展開(UPDATE)
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/12/19
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR2_TM_KIND] ON [dbo].[TM_KIND_EXCEL] AFTER UPDATE 
AS
BEGIN

	DECLARE @Kind_Name as varchar(40)
	DECLARE @Kind_Class as varchar(40)
	DECLARE @Model_Number as varchar(160)
	DECLARE @Unit_No as int
	DECLARE @Manu_Lot as float
	DECLARE @Manu_Lead_Time as float
	DECLARE @Delete_Flg as tinyint
	DECLARE @Lang_Mode as tinyint
	DECLARE @Item_Name as varchar(160)
	DECLARE @Abbreviation_Name as varchar(32)
	DECLARE @Old_Kind_Name as varchar(40)
	DECLARE @Old_Kind_Class as varchar(40)
	DECLARE @Old_Lang_Mode as int
	DECLARE @Chk_Kind_Name as varchar(40)
	DECLARE @Chk_Kind_Class as varchar(40)
	DECLARE @Chk_Kind_Name2 as varchar(40)
	DECLARE @Chk_Kind_Class2 as varchar(40)
	DECLARE @Chk_Flg as int
	DECLARE @Info_Update_Flg as tinyint
	DECLARE @Data_Flg as tinyint

	DECLARE DeleteData CURSOR FOR
	SELECT Kind_Name,Kind_Class,Lang_Mode
	FROM DELETED

	DECLARE UpdateData CURSOR FOR
	SELECT Kind_Name,Kind_Class,Model_Number,Unit_No,Manu_Lot,Manu_Lead_Time,Delete_Flg,
           Lang_Mode,Item_Name,Abbreviation_Name
	FROM INSERTED

    --カーソルをオープンし、内容を確認
	OPEN DeleteData
    OPEN UpdateData
    
    --行の取り出し
	FETCH NEXT FROM DeleteData INTO @Old_Kind_Name,@Old_Kind_Class,@Old_Lang_Mode

    FETCH NEXT FROM UpdateData INTO @Kind_Name,@Kind_Class,@Model_Number,@Unit_No,@Manu_Lot,
    		@Manu_Lead_Time,@Delete_Flg,@Lang_Mode,@Item_Name,@Abbreviation_Name
    
    --ループ処理
    WHILE (@@FETCH_STATUS = 0)
    	BEGIN
			--フラグ初期化
			SET @Info_Update_Flg = 0
			SET @Chk_Flg = 0
			SET @Chk_Kind_Name = ''
			SET @Chk_Kind_Class = ''
			SET @Chk_Kind_Name2 = ''
			SET @Chk_Kind_Class2 = ''

			--品目変更確認
			IF((@Old_Kind_Name <> @Kind_Name ) OR (@Old_Kind_Class <> @Kind_Class))
				BEGIN
					--どちらか片方でも変更があった場合、変更フラグをONする
					SET @Chk_Flg = 1

				END

			--変更フラグ確認
			IF(@Chk_Flg = 1)
				BEGIN
					--主キーが変更されている場合

					--品目名称マスタ(TM_KIND_NAME)への展開
					UPDATE TM_KIND_NAME SET Kind_Name = @Kind_Name,Kind_Class = @Kind_Class,Lang_Mode = @Lang_Mode, Item_Name = @Item_Name
							,Abbreviation_Name = @Abbreviation_Name,Last_Update = GETDATE()
						WHERE Kind_Name = @Old_Kind_Name AND Kind_Class = @Old_Kind_Class AND Lang_Mode = @Old_Lang_Mode

					--フラグ初期化
					SET @Data_Flg = 0

					--変更した内容が情報テーブル内に存在するかを確認
					DECLARE ChkInfoData CURSOR FOR 
					SELECT Kind_Name,Kind_Class
					FROM TM_KIND_NAME
					WHERE Kind_Name = @Old_Kind_Name AND Kind_Class = @Old_Kind_Class

					--カーソルをオープンし、内容を確認
					OPEN ChkInfoData

					--行の取り出し
					FETCH NEXT FROM ChkInfoData INTO @Chk_Kind_Name,@Chk_Kind_Class

					--ループ処理
					WHILE (@@FETCH_STATUS = 0)
						BEGIN
							--フラグON
							SET @Info_Update_Flg = 1

							--行の取り出し
							FETCH NEXT FROM ChkInfoData INTO @Chk_Kind_Name,@Chk_Kind_Class
						END

					--フラグ確認
					IF(@Info_Update_Flg = 1)
						BEGIN
							--他の言語で同様の情報を使用しているため、新たに情報を追加する必要あり

							--既に情報テーブル内に存在するかを確認
							DECLARE ChkInfoData2 CURSOR FOR
							SELECT Kind_Name,Kind_Class
							FROM TM_KIND_INFO
							WHERE Kind_Name = @Kind_Name AND Kind_Class = @Kind_Class

							--カーソルをオープンし、内容を確認
							OPEN ChkInfoData2

							--行の取り出し
							FETCH NEXT FROM ChkInfoData2 INTO @Chk_Kind_Name2,@Chk_Kind_Class2

							--ループ処理
							WHILE (@@FETCH_STATUS = 0)
								BEGIN
									--データあり
									SET @Data_Flg = 1

									--行の取り出し
									FETCH NEXT FROM ChkInfoData2 INTO @Chk_Kind_Name2,@Chk_Kind_Class2
								END

							--データ有無チェック
							IF(@Data_Flg = 1)
								BEGIN
									--データあり
									--情報データを更新する
									UPDATE TM_KIND_INFO SET Kind_Name = @Kind_Name,Kind_Class = @Kind_Class, Model_Number = @Model_Number,
											Unit_No = @Unit_No,Manu_Lot = @Manu_Lot,Manu_Lead_Time = @Manu_Lead_Time,Delete_Flg = @Delete_Flg,Last_Update = GETDATE()
										WHERE Kind_Name = @Kind_Name AND Kind_Class = @Kind_Name
								END
							ELSE
								BEGIN
									--データなし
									--情報データを新規作成
									INSERT INTO TM_KIND_INFO (Kind_Name,Kind_Class,Model_Number,Unit_No,Manu_Lot,Manu_Lead_Time,Delete_Flg,Last_Update)
										VALUES (@Kind_Name,@Kind_Class,@Model_Number,@Unit_No,@Manu_Lot,@Manu_Lead_Time,@Delete_Flg,GETDATE())
								END

							--カーソルを閉じる
							CLOSE ChkInfoData2
							DEALLOCATE ChkInfoData2

						END
					ELSE
						BEGIN
							--他の言語で同様の情報は使用されていないため、一括更新を行う。
							UPDATE TM_KIND_INFO SET Kind_Name = @Kind_Name,Kind_Class = @Kind_Class, Model_Number = @Model_Number,
									Unit_No = @Unit_No,Manu_Lot = @Manu_Lot,Manu_Lead_Time = @Manu_Lead_Time,Delete_Flg = @Delete_Flg,Last_Update = GETDATE()
							WHERE Kind_Name = @Old_Kind_Name AND Kind_Class = @Old_Kind_Name

						END

					--カーソルを閉じる
					CLOSE ChkInfoData
					DEALLOCATE ChkInfoData

				END
			ELSE
				BEGIN
					--主キーが変更されていない場合

					--品目名称マスタ(TM_KIND_NAME)への展開
					UPDATE TM_KIND_NAME SET Kind_Name = @Kind_Name,Kind_Class = @Kind_Class,Lang_Mode = @Lang_Mode, Item_Name = @Item_Name
							,Abbreviation_Name = @Abbreviation_Name,Last_Update = GETDATE()
						WHERE Kind_Name = @Old_Kind_Name AND Kind_Class = @Old_Kind_Name AND Lang_Mode = @Old_Lang_Mode

					--品目情報マスタ(TM_KIND_INFO)への展開
					UPDATE TM_KIND_INFO SET Kind_Name = @Kind_Name,Kind_Class = @Kind_Class, Model_Number = @Model_Number,
							Unit_No = @Unit_No,Manu_Lot = @Manu_Lot,Manu_Lead_Time = @Manu_Lead_Time,Delete_Flg = @Delete_Flg,Last_Update = GETDATE()
						WHERE Kind_Name = @Old_Kind_Name AND Kind_Class = @Old_Kind_Name
				END

    		--次の行へ移動
			FETCH NEXT FROM DeleteData INTO @Old_Kind_Name,@Old_Kind_Class,@Old_Lang_Mode
		
		    FETCH NEXT FROM UpdateData INTO @Kind_Name,@Kind_Class,@Model_Number,@Unit_No,@Manu_Lot,
    				@Manu_Lead_Time,@Delete_Flg,@Lang_Mode,@Item_Name,@Abbreviation_Name
    
    	END
    --カーソルを閉じる
    CLOSE UpdateData
	CLOSE DeleteData
    DEALLOCATE UpdateData
	DEALLOCATE DeleteData

END

go

