
/***********************************************************************************
*
* 製品名			：生産分析機能
* 処理名			：日データ収集(実績データ)
* ファンクション名	：DayCollect_Value
* 概要				：稼働監視画面用実績データ収集処理
* バージョン		：1.12.0.0
*
* 作成者			：Takasima Hironori
* 作成日			：2017/07/08
* 更新者			：
* 更新日			：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE PROCEDURE [dbo].[DayCollect_Value]
(
	@Equipment_No			int,		--装置No.
	@Target_Date			date		--収集対象日付
)
AS
BEGIN
	DECLARE @Start_Hour as int
	DECLARE @Start_Min as int
	DECLARE @tmpSetData as varchar(20)
	DECLARE @Start_Date as datetime
	DECLARE @End_Date as datetime
	DECLARE @Sum_Collect_Value as float
	DECLARE @Sum_OK_Value as float
	DECLARE @Sum_NG_Value as float
	DECLARE @Target_Value as float
	DECLARE @tmpData1 as float = 0
	DECLARE @tmpData2 as float = 0
	DECLARE @tmpData3 as float = 0
	DECLARE @tmpData4 as float = 0

	--初期化
	SET @Sum_Collect_Value = 0
	SET @Sum_OK_Value = 0
	SET @Sum_NG_Value = 0
	SET @Target_Value = 0
	SET @Start_Hour = -1
	SET @Start_Min = -1

	--収集開始時刻の取得
	DECLARE OptionSet1 CURSOR FOR
	SELECT Setting_Value
	FROM TM_OPTION_SETTING
	WHERE Key_Name = 'Start_Hour'

	--カーソルをオープンし、内容を確認
	OPEN OptionSet1

	--行の取り出し
	FETCH NEXT FROM OptionSet1 INTO @tmpSetData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			--数値に変換
			SET @Start_Hour = CONVERT(int,@tmpSetData)

			--行の取り出し
			FETCH NEXT FROM OptionSet1 INTO @tmpSetData
		END
	--カーソルを閉じる
	CLOSE OptionSet1
	DEALLOCATE OptionSet1

		--収集開始時刻の取得
	DECLARE OptionSet2 CURSOR FOR
	SELECT Setting_Value
	FROM TM_OPTION_SETTING
	WHERE Key_Name = 'Start_Min'

	--カーソルをオープンし、内容を確認
	OPEN OptionSet2

	--行の取り出し
	FETCH NEXT FROM OptionSet2 INTO @tmpSetData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			--数値に変換
			SET @Start_Min = CONVERT(int,@tmpSetData)

			--行の取り出し
			FETCH NEXT FROM OptionSet2 INTO @tmpSetData
		END
	--カーソルを閉じる
	CLOSE OptionSet2
	DEALLOCATE OptionSet2

	--処理確認
	IF((@Start_Hour = -1) or (@Start_Min = -1))
		BEGIN
			--処理を抜ける
			goto proc_end

		END

	--集計対象日時の設定
	--検索開始日時
	SET @Start_Date = CONVERT(datetime,FORMAT(@Target_Date,'yyyy/MM/dd') + ' ' + RIGHT('00' + CONVERT(varchar, @Start_Hour),2) + ':' + RIGHT('00' + CONVERT(varchar, @Start_Min),2) + ':00')
	--検索終了日時
	SET @End_Date = DATEADD(day,1,@Start_Date)

	--実績値の取得
	DECLARE GET_VAL CURSOR FOR
	SELECT E.Sum_Collect_Value,E.Sum_OK_Value,E.Sum_NG_Value,F.TARGET_VAL
	FROM
	(
		SELECT D.Equipment_No,sum(D.Sum_Collect_Value)AS Sum_Collect_Value,sum(D.Sum_OK_Value)AS Sum_OK_Value,sum(D.Sum_NG_Value)AS Sum_NG_Value
		FROM(
			SELECT B.Equipment_No,sum(Collect_Value) AS Sum_Collect_Value,sum(OK_Value) AS Sum_OK_Value,sum(NG_Value) AS Sum_NG_Value
			FROM(
				SELECT A.Equipment_No,A.Collect_Value AS Collect_Value,A.OK_Value AS OK_Value,A.NG_Value AS NG_Value
				FROM (
					SELECT TD_VAL1.Equipment_No, TD_VAL1.Kind_Name, TD_VAL1.Kind_Priority, TD_VAL1.Collect_Value, TD_VAL1.OK_Value,TD_VAL1.NG_Value 
					FROM TD_COLLECT_HOUR_VALUE AS TD_VAL1 
					WHERE TD_VAL1.Equipment_No = @Equipment_No
						AND Collect_Date > @Start_Date
						AND Collect_Date <= @End_Date
						AND Manufact_Flg = 2
				) AS A
			) AS B
			GROUP BY Equipment_No
			UNION
			SELECT C.Equipment_No,CASE WHEN C.HOUR_FLG1 = 0 THEN C.Sum_Collect_Value ELSE 0 END AS Sum_Collect_Value,
				CASE WHEN C.HOUR_FLG2 = 0 THEN C.Sum_OK_Value ELSE 0 END AS Sum_OK_Value,CASE WHEN C.HOUR_FLG3 = 0 THEN C.Sum_NG_Value ELSE 0 END AS Sum_NG_Value
			FROM(
				SELECT A.Equipment_No, A.Collect_Value AS Sum_Collect_Value, CASE WHEN B.Collect_Value IS NULL THEN 0 ELSE 1 END AS HOUR_FLG1
					, A.OK_Value AS Sum_OK_Value, CASE WHEN B.OK_Value IS NULL THEN 0 ELSE 1 END AS HOUR_FLG2, A.NG_Value AS Sum_NG_Value
					, CASE WHEN B.NG_Value IS NULL THEN 0 ELSE 1 END AS HOUR_FLG3
				FROM(
					SELECT TOP(1) TD_VAL2.Equipment_No,TD_VAL2.Kind_Name,TD_VAL2.Kind_Priority,TD_VAL2.Collect_Value,TD_VAL2.OK_Value,TD_VAL2.NG_Value
					FROM TD_COLLECT_VALUE AS TD_VAL2 
					WHERE TD_VAL2.Equipment_No = @Equipment_No AND TD_VAL2.Collect_Date > @Start_Date
							AND TD_VAL2.Collect_Date <= @End_Date
					ORDER BY TD_VAL2.Collect_Date DESC
				) AS A LEFT JOIN (
					SELECT TD_VAL1.Equipment_No,TD_VAL1.Kind_Name,TD_VAL1.Kind_Priority,TD_VAL1.Collect_Value,TD_VAL1.OK_Value,TD_VAL1.NG_Value
					FROM TD_COLLECT_HOUR_VALUE AS TD_VAL1 
					WHERE TD_VAL1.Equipment_No = @Equipment_No AND TD_VAL1.Collect_Date > @Start_Date
									AND TD_VAL1.Collect_Date <= @End_Date 
									AND TD_VAL1.Manufact_Flg = 2
				) AS B ON  A.Equipment_No = B.Equipment_No AND A.Kind_Name = B.Kind_Name AND A.Kind_Priority = B.Kind_Priority
			) AS C
		) AS D
		GROUP BY D.Equipment_No
	) AS E LEFT JOIN 
	(
		SELECT Equipment_No,SUM(Target_Value) AS TARGET_VAL
		FROM TD_TARGET_VALUE
		WHERE Equipment_No = @Equipment_No AND Start_Date = @Target_Date
		GROUP BY Equipment_No
	) AS F ON E.Equipment_No = F.Equipment_No

	--カーソルをOPEN
	OPEN GET_VAL

	--行の取り出し
	FETCH NEXT FROM GET_VAL INTO @tmpData1,@tmpData2,@tmpData3,@tmpData4

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--実績データの書込み
			SET @Sum_Collect_Value = @tmpData1
			SET @Sum_OK_Value = @tmpData2
			SET @Sum_NG_Value = @tmpData3
			SET @Target_Value = @tmpData4

			--行の取り出し
			FETCH NEXT FROM GET_VAL INTO @tmpData1,@tmpData2,@tmpData3,@tmpData4
		END
	--カーソルを閉じる
	CLOSE GET_VAL
	DEALLOCATE GET_VAL

	--データの削除
	DELETE FROM TD_COLLECT_DAY_VALUE WHERE Equipment_No = @Equipment_No AND Data_Date = @Target_Date

	--データの挿入
	INSERT INTO TD_COLLECT_DAY_VALUE (Data_Date, Equipment_No, Manu_Value, OK_Value, NG_Value, Target_Value, Last_Update)
		VALUES (@Target_Date,@Equipment_No,@Sum_Collect_Value,@Sum_OK_Value,@Sum_NG_Value,@Target_Value,GETDATE())


proc_end:

END

go

