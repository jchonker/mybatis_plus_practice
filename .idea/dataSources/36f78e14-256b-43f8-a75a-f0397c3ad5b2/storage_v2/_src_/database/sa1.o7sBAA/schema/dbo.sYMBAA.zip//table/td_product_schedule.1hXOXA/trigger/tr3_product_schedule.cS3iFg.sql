/***********************************************************************************
*
* 製品名        ：上位システム連携機能
* 処理名        ：スケジュール完了データ展開用トリガ
* トリガ名		：TR3_PRODUCT_SCHEDULE
* 概要          ：TD_PRODUCT_SCHEDULE→TD_SCHEDULEへの展開(UPDATE)
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/10/11
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR3_PRODUCT_SCHEDULE] ON [dbo].[TD_PRODUCT_SCHEDULE] AFTER UPDATE 
AS
BEGIN

	DECLARE @Comp_Flg as tinyint
	DECLARE @Sch_Index as bigint
	DECLARE @Sch_No as bigint
	DECLARE @Unfinish_Sch as tinyint

	DECLARE @COMPLETE_FLG as tinyint
	DECLARE @INST_FLG as tinyint
	
	--初期値
	SET @COMPLETE_FLG = 2
	SET @INST_FLG = 1

	DECLARE UpdateData CURSOR FOR 
	SELECT Sch_Index,Comp_Flg
	FROM inserted

	--カーソルをオープンし、内容を確認
	OPEN UpdateData

	--行の取り出し
	FETCH NEXT FROM UpdateData INTO @Sch_Index,@Comp_Flg

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--初期化
			SET @Unfinish_Sch = 0

			--指示完了フラグの確認
			IF (@Comp_Flg = @COMPLETE_FLG)
				BEGIN
					--【製造完了時】
					
					--製造完了していない項目の確認
					DECLARE ChkSchedule CURSOR FOR
					SELECT Sch_No
					FROM TD_PRODUCT_SCHEDULE
					WHERE Sch_Index = @Sch_Index AND Comp_Flg <> 2

					--カーソルをオープンし、内容を確認
					OPEN ChkSchedule

					--行の取り出し
					FETCH NEXT FROM ChkSchedule INTO @Sch_No

					--ループ処理
					WHILE (@@FETCH_STATUS = 0)
						BEGIN 
							--まだ未完のスケジュールあり
							SET @Unfinish_Sch = 1

							--行の取り出し
							FETCH NEXT FROM ChkSchedule INTO @Sch_No
						END
					--カーソルを閉じる
					CLOSE ChkSchedule
					DEALLOCATE ChkSchedule

					--未完スケジュールフラグのチェック
					IF (@Unfinish_Sch = 0)
						BEGIN
							--未完スケジュールなし(対象スケジュールの生産完了)

							--スケジュールデータの指示完了フラグを更新
							UPDATE TD_SCHEDULE SET Comp_Flg = @COMPLETE_FLG
								WHERE Sch_Index = @Sch_Index
						END
				END
			ELSE IF (@Comp_Flg = @INST_FLG)
				BEGIN
				
					--スケジュールデータの指示完了フラグを更新
					UPDATE TD_SCHEDULE SET Comp_Flg = @INST_FLG
						WHERE Sch_Index = @Sch_Index
				
				END
				
			--行の取り出し
			FETCH NEXT FROM UpdateData INTO @Sch_Index,@Comp_Flg
		END
	--カーソルを閉じる
	CLOSE UpdateData
	DEALLOCATE UpdateData

END

go

