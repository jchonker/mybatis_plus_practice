
/***********************************************************************************
*
* 製品名        ：生産分析機能
* 処理名        ：実績データ(1時間用)作成トリガ
* トリガ名		：TR_COLLECT_VALUE
* 概要          ：実績値テーブルから実績値テーブル(1時間用)への展開
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/09/18
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR_COLLECT_VALUE] ON [dbo].[TD_COLLECT_VALUE] AFTER INSERT
AS
BEGIN

	--変数宣言(今回値データ)
	DECLARE @Equipment_No AS int				--装置No.
	DECLARE @Collect_Date as datetime			--収集日時
	DECLARE @Kind_Name as varchar(40)			--品目コード
	DECLARE @Kind_Class as varchar(40)			--品目区分
	DECLARE @Kind_Priority as bigint			--シーケンスNo.
	DECLARE @Lot_Name as varchar(40)			--ロット情報
	DECLARE @Collect_Value as float				--実績値
	DECLARE @OK_Value as float					--OK数
	DECLARE @NG_Value as float					--NG数
	DECLARE @Comp_Product_Flg as tinyint		--生産完了フラグ
	DECLARE @Inst_No as bigint					--指示No.
	DECLARE @Lot_Change_Flg as tinyint			--ロット情報変更フラグ
	DECLARE @Manufact_Flg as tinyint			--生産開始/終了フラグ
	DECLARE @Row_No as bigint

	--変数宣言(前回値データ)
	DECLARE @OLD_Collect_Date as datetime			--収集日時
	DECLARE @OLD_Kind_Name as varchar(40)			--品目コード
	DECLARE @OLD_Kind_Class as varchar(40)			--品目区分
	DECLARE @OLD_Kind_Priority as bigint			--シーケンスNo.
	DECLARE @OLD_Lot_Name as varchar(40)			--ロット情報
	DECLARE @OLD_Collect_Value as float				--実績値
	DECLARE @OLD_OK_Value as float					--OK数
	DECLARE @OLD_NG_Value as float					--NG数
	DECLARE @OLD_Comp_Product_Flg as tinyint		--生産完了フラグ
	DECLARE @OLD_Inst_No as bigint					--指示No.

	--変数宣言(前回値データ(1時間))
	DECLARE @OLD_H_Collect_Date as datetime			--収集日時
	DECLARE @OLD_H_Kind_Name as varchar(40)			--品目コード
	DECLARE @OLD_H_Kind_Class as varchar(40)		--品目区分
	DECLARE @OLD_H_Kind_Priority as bigint			--シーケンスNo.
	DECLARE @OLD_H_Lot_Name as varchar(40)			--ロット情報
	DECLARE @OLD_H_Collect_Value as float			--実績値
	DECLARE @OLD_H_Manufact_Flg as tinyint			--生産開始/終了フラグ
	DECLARE @OLD_H_OK_Value as float					--OK数
	DECLARE @OLD_H_NG_Value as float					--NG数


	--変数宣言(フラグ)
	DECLARE @Old_Data_Flg as tinyint				--前回値データありフラグ
	DECLARE @Old_H_Data_Flg as tinyint				--前回値データ(1時間)ありフラグ
	DECLARE @Comp_Flg as tinyint					--完了フラグ
	DECLARE @Old_Update_Flg as tinyint				--前回値更新フラグ
	DECLARE @Product_Start_Flg as tinyint			--生産開始フラグ
	DECLARE @Data_Insert_Flg as tinyint				--データ挿入フラグ
	DECLARE @Lot_Chg_Flg as tinyint					--ロット変化フラグ


	--定数宣言
	DECLARE @TIME_DIFFERENCE as int					--時刻差(基準値)
	DECLARE @MANU_FLG_NORMAL as tinyint				--生産開始/終了フラグ用定数(通常)
	DECLARE @MANU_FLG_START as tinyint				--生産開始/終了フラグ用定数(生産開始)
	DECLARE @MANU_FLG_END as tinyint				--生産開始/終了フラグ用定数(生産終了)
	DECLARE @MANU_FLG_ITIJI as tinyint				--生産開始/終了フラグ用定数(一時完了)
	DECLARE @LOTCHG_FLG_NORMAL as tinyint			--ロット切替えフラグ用定数(通常)
	DECLARE @LOTCHG_FLG_CHANGE as tinyint			--ロット切替えフラグ用定数(通常)
	DECLARE @COMP_PRO_NORMAL as tinyint				--生産完了フラグ用定数(通常：生産中)
	DECLARE @COMP_PRO_ITIJI as tinyint				--生産完了フラグ用定数(一時完了)
	DECLARE @COMP_PRO_END as tinyint				--生産完了フラグ用定数(生産完了)


	--初期化
	SET @Old_Data_Flg = 0
	SET @Old_H_Data_Flg = 0
	SET @TIME_DIFFERENCE = 60
	SET @MANU_FLG_NORMAL = 0
	SET @MANU_FLG_START = 1
	SET @MANU_FLG_END = 2
	SET @MANU_FLG_ITIJI = 3
	SET @LOTCHG_FLG_NORMAL = 0
	SET @LOTCHG_FLG_CHANGE = 1
	SET @COMP_PRO_NORMAL = 0
	SET @COMP_PRO_ITIJI = 1
	SET @COMP_PRO_END = 2
	SET @Lot_Change_Flg = 0
	SET @Manufact_Flg = 0

	--INSERTされた行から各種情報を取得
	SELECT	@Equipment_No = Equipment_No,
			@Collect_Date = Collect_Date,
			@Kind_Name = Kind_Name,
			@Kind_Class = Kind_Class,
			@Kind_Priority = Kind_Priority,
			@Lot_Name = Lot_Name,
			@Collect_Value = Collect_Value,
			@OK_Value = OK_Value,
			@NG_Value = NG_Value,
			@Comp_Product_Flg = Comp_Product_Flg,
			@Inst_No = Inst_No,
			@Row_No = Row_No
	FROM INSERTED

	--前回値データの取得
	DECLARE OldValueData CURSOR FOR
	SELECT TOP(1) Collect_Date,Kind_Name,Kind_Class,Kind_Priority,Lot_Name,Collect_Value,
		OK_Value,NG_Value,Comp_Product_Flg,Inst_No
	FROM TD_COLLECT_VALUE
	WHERE Equipment_No = @Equipment_No AND Collect_Date < @Collect_Date
	ORDER BY Collect_Date DESC
	
	--カーソルを移動し、内容を確認
	OPEN OldValueData

	--行の取り出し(前回実績値)
	FETCH NEXT FROM OldValueData INTO @OLD_Collect_Date,@OLD_Kind_Name,@OLD_Kind_Class,
		@OLD_Kind_Priority,@OLD_Lot_Name,@OLD_Collect_Value,@OLD_OK_Value,@OLD_NG_Value,
		@OLD_Comp_Product_Flg,@OLD_Inst_No

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			--前回値取得フラグ
			SET @Old_Data_Flg = 1
			
			DECLARE @Time_Interval as int		--時刻間隔
			
			--時刻間隔の取得
			SET @Time_Interval = DATEDIFF(MINUTE,@OLD_Collect_Date,@Collect_Date)
			
			--時刻差の確認
			IF(@Time_Interval > @TIME_DIFFERENCE)
				BEGIN
					--前回の実績報告から60分以上経過しているため、
					--前回値データを実績データ(1時間)へ書込む

					--既に該当するデータが存在しないかを確認する

					DECLARE @tmp_Data as datetime
					DECLARE @tmp_Flg as tinyint		--データ有無確認用フラグ

					--初期化
					SET @tmp_Flg = 0

					DECLARE tmpCursor CURSOR FOR
					SELECT TOP(1) Collect_Date
					FROM TD_COLLECT_HOUR_VALUE
					WHERE Equipment_No = @Equipment_No AND Collect_Date = @OLD_Collect_Date
						AND Kind_Name = @OLD_Kind_Name AND Kind_Class = @OLD_Kind_Class AND Kind_Priority = @OLD_Kind_Priority

					--カーソルを移動し、内容を確認
					OPEN tmpCursor

					--行の取り出し
					FETCH NEXT FROM tmpCursor INTO @tmp_Data

					--ループ処理
					WHILE (@@FETCH_STATUS = 0)
						BEGIN
							--既にデータが存在する
							SET @tmp_Flg = 1
							--次の行へ移動
							FETCH NEXT FROM tmpCursor INTO @tmp_Data
						END
					--カーソルを閉じる
					CLOSE tmpCursor
					DEALLOCATE tmpCursor

					--データ有無確認用フラグチェック
					IF (@tmp_Flg = 0)
						BEGIN 
							--時刻差が基準値以上の為、実績値データ(1時間)に前回値を挿入
							INSERT INTO TD_COLLECT_HOUR_VALUE (Equipment_No,Collect_Date,Kind_Name,Kind_Class,Kind_Priority,
									Lot_Name,Collect_Value,OK_Value,NG_Value,Manufact_Flg,Lot_Change_Flg,Inst_No,Last_Update) 
								VALUES
								(@Equipment_No,@OLD_Collect_Date,@OLD_Kind_Name,@OLD_Kind_Class,@OLD_Kind_Priority,
									@OLD_Lot_Name,@OLD_Collect_Value,@OLD_OK_Value,@OLD_NG_Value,@MANU_FLG_NORMAL,
									@LOTCHG_FLG_NORMAL,@OLD_Inst_No,GETDATE())
						END
				END

			--行の取り出し(前回実績値)
			FETCH NEXT FROM OldValueData INTO @OLD_Collect_Date,@OLD_Kind_Name,@OLD_Kind_Class,
				@OLD_Kind_Priority,@OLD_Lot_Name,@OLD_Collect_Value,@OLD_OK_Value,@OLD_NG_Value,
				@OLD_Comp_Product_Flg,@OLD_Inst_No
		END

	--カーソルを閉じる
	CLOSE OldValueData
	DEALLOCATE OldValueData

	--前回値の有無チェック
	IF(@Old_Data_Flg = 0)
		BEGIN
			--前回値が存在しないため、生産開始データとして登録
			
			--今回の生産開始/完了フラグを「生産開始」に変更
			SET @Manufact_Flg = @MANU_FLG_START
			--今回値のロット切替えフラグを「1」に変更
			SET @Lot_Change_Flg = 1
		END

	--前回値データ(1時間データ)の取得
	DECLARE Old_ValueData_H CURSOR FOR
	SELECT TOP(1) Collect_Date,Kind_Name,Kind_Class,Kind_Priority,Lot_Name,Collect_Value,Manufact_Flg,OK_Value,NG_Value
	FROM TD_COLLECT_HOUR_VALUE
	WHERE Equipment_No = @Equipment_No
	ORDER BY Collect_Date DESC

	--カーソルをオープンし、内容を確認
	OPEN Old_ValueData_H

	--行の取りだし
	FETCH NEXT FROM Old_ValueData_H INTO @OLD_H_Collect_Date,@OLD_H_Kind_Name,@OLD_H_Kind_Class,
		@OLD_H_Kind_Priority,@OLD_H_Lot_Name,@OLD_H_Collect_Value,@OLD_H_Manufact_Flg,@OLD_H_OK_Value,@OLD_H_NG_Value
	
	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--前回値取得済み
			SET @Old_H_Data_Flg = 1

			--行の取りだし
			FETCH NEXT FROM Old_ValueData_H INTO @OLD_H_Collect_Date,@OLD_H_Kind_Name,@OLD_H_Kind_Class,
				@OLD_H_Kind_Priority,@OLD_H_Lot_Name,@OLD_H_Collect_Value,@OLD_H_Manufact_Flg,@OLD_H_OK_Value,@OLD_H_NG_Value
		END
	--カーソルを閉じる
	CLOSE Old_ValueData_H
	DEALLOCATE Old_ValueData_H

	--今回値の完了フラグの状態チェック
	IF(@Comp_Product_Flg = @COMP_PRO_NORMAL)
		BEGIN
			--【完了フラグなし】
			--前回値(1時間データ)有無チェック
			IF(@Old_H_Data_Flg = 1)
				BEGIN
					--【前回値(1時間データ)あり】
					--前回値との比較

					IF((@Kind_Name <> @OLD_Kind_Name) OR (@Kind_Class <> @OLD_Kind_Class) OR (@Kind_Priority <> @OLD_Kind_Priority)
							OR (@OLD_Collect_Value > @Collect_Value) OR (@OLD_OK_Value > @OK_Value)) 
						BEGIN
							--【データに変化あり】
							--生産開始フラグON
							SET @Product_Start_Flg = 0
							--前回値更新フラグON
							SET @Old_Update_Flg = 1
							--データ挿入フラグON
							SET @Data_Insert_Flg = 1
							
							--前回の1時間データとリアルタイムデータの収集時間を比較
							IF (@OLD_Collect_Date <> @OLD_H_Collect_Date)
								BEGIN
									--1時間データに前回値データをINSERT
									SET @OLD_H_Collect_Date = @OLD_Collect_Date
									SET @OLD_H_Kind_Name = @OLD_Kind_Name
									SET @OLD_H_Kind_Class = @OLD_Kind_Class
									SET @OLD_H_Kind_Priority = @OLD_Kind_Priority
									SET @OLD_H_Lot_Name = @OLD_Lot_Name
									SET @OLD_H_Collect_Value = @OLD_Collect_Value
									SET @OLD_H_OK_Value = @OLD_OK_Value
									SET @OLD_H_NG_Value = @OLD_NG_Value
									SET @OLD_H_Manufact_Flg = 0

									INSERT INTO TD_COLLECT_HOUR_VALUE (Equipment_No,Collect_Date,Kind_Name,Kind_Class,Kind_Priority,
										Lot_Name,Collect_Value,OK_Value,NG_Value,Manufact_Flg,Lot_Change_Flg,Inst_No,Last_Update) 
									VALUES
									(@Equipment_No,@OLD_H_Collect_Date,@OLD_H_Kind_Name,@OLD_H_Kind_Class,@OLD_H_Kind_Priority,
										@OLD_H_Lot_Name,@OLD_H_Collect_Value,@OLD_H_OK_Value,@OLD_H_NG_Value,@OLD_H_Manufact_Flg,
										@LOTCHG_FLG_NORMAL,@OLD_Inst_No,GETDATE())
								END
						END
					ELSE
						BEGIN
							--【データに変化なし】
							--日付の変化チェック
							IF((DATEPART(YEAR,@Collect_Date) <> DATEPART(YEAR,@OLD_Collect_Date)) OR 
									(DATEPART(MONTH,@Collect_Date) <> DATEPART(MONTH,@OLD_Collect_Date)) OR
									(DATEPART(DAY,@Collect_Date) <> DATEPART(DAY,@OLD_Collect_Date)) OR 
									(DATEPART(HOUR,@Collect_Date) <> DATEPART(HOUR,@OLD_Collect_Date)))
								BEGIN
									--【日時の変化あり】
									--前回値更新フラグOFF
									SET @Old_Update_Flg = 0
									--データ挿入フラグON
									SET @Data_Insert_Flg = 1
								END
						END
				END
			ELSE
				BEGIN
					--【前回値(1時間データ)なし】
					--前回値更新フラグOFF
					SET @Old_Update_Flg = 0
					--生産開始フラグON
					SET @Product_Start_Flg = 1				
					--データ挿入フラグON
					SET @Data_Insert_Flg = 1			
				END
		END
	ELSE IF ((@Comp_Product_Flg = @COMP_PRO_ITIJI) OR (@Comp_Product_Flg = @COMP_PRO_END))
		BEGIN 
			--【完了フラグあり】
			--完了フラグON
			SET @Comp_Flg = @Comp_Product_Flg
			--前回値更新フラグON
			SET @Old_Update_Flg = 1
			--生産開始フラグON
			SET @Product_Start_Flg = 1	
			--データ挿入フラグON
			SET @Data_Insert_Flg = 1			
		END
	ELSE
		BEGIN
			--その他
			--フラグを全てOFF
			SET @Comp_Flg = 0
			SET @Old_Update_Flg = 0
			SET @Product_Start_Flg = 0
		END

	--ロット情報の変化チェック
	IF(@Lot_Name <> @OLD_Lot_Name)
		BEGIN
			--【ロット情報変化あり】
			--ロット変化フラグON
			SET @Lot_Chg_Flg = 1
			--データ挿入フラグON
			SET @Data_Insert_Flg = 1
		END

	--データ挿入フラグチェック
	IF(@Data_Insert_Flg = 1)
		BEGIN
			--【挿入データあり】
			--前回値更新フラグチェック
			IF(@Old_Update_Flg = 1)
				BEGIN
					--【前回値更新データあり】
					--完了フラグチェック
					IF(@Comp_Flg  = @COMP_PRO_END)
						BEGIN
							--【生産完了】
							--生産開始/完了フラグを「生産完了に変更」
							SET @Manufact_Flg = @MANU_FLG_END
						END
					ELSE IF (@Comp_Flg = @COMP_PRO_ITIJI)
						BEGIN
							--【一時完了】
							--生産開始/完了フラグを「一時完了に変更」
							SET @Manufact_Flg = @MANU_FLG_ITIJI
						END
					ELSE
						BEGIN
							--生産開始フラグチェック
							IF((@Product_Start_Flg = 0) AND (@OLD_H_Manufact_Flg = 0))
								BEGIN
									--【生産開始フラグOFF】
									--前回値(1時間データ)の生産開始/終了フラグを
									--「生産完了」に変更

									UPDATE TD_COLLECT_HOUR_VALUE SET Manufact_Flg = @MANU_FLG_END
										WHERE Equipment_No = @Equipment_No AND Collect_Date = @OLD_Collect_Date
											AND Kind_Name = @OLD_Kind_Name AND Kind_Class = @OLD_Kind_Class
											AND Kind_Priority = @OLD_Kind_Priority
								END

							--今回の生産開始/完了フラグを「生産開始」に変更
							SET @Manufact_Flg = @MANU_FLG_START
						END
				END

			--ロット情報の変更チェック
			IF(@Lot_Chg_Flg = 1)
				BEGIN
					--【ロット情報の変更あり】
					--今回値のロット切替えフラグを「1」に変更
					SET @Lot_Change_Flg = 1
				END

			--今回値をINSERT
			INSERT INTO TD_COLLECT_HOUR_VALUE (Equipment_No,Collect_Date,Kind_Name,Kind_Class,Kind_Priority,
					Lot_Name,Collect_Value,OK_Value,NG_Value,Manufact_Flg,Lot_Change_Flg,Inst_No,Last_Update) 
				VALUES
				(@Equipment_No,@Collect_Date,@Kind_Name,@Kind_Class,@Kind_Priority,@Lot_Name,@Collect_Value,
					@OK_Value,@NG_Value,@Manufact_Flg,@Lot_Change_Flg,@Inst_No,GETDATE())

		END

	--装置製造状況への反映
	DECLARE @E_Equipment_No as integer
	DECLARE @E_Kind_Name as varchar(40)
	DECLARE @E_Kind_Class as varchar(40)
	DECLARE @E_Kind_Priority as bigint
	DECLARE @E_Lot_Name as varchar(40)
	DECLARE @E_Collect_Value as float
	DECLARE @E_OK_Value as float
	DECLARE @E_NG_Value as float
	DECLARE @E_Inst_No as bigint
	DECLARE @E_Target_Value as float
	DECLARE @E_Target_No as bigint
	DECLARE @E_Production_Cost as int
	DECLARE @Old_E_Data as tinyint
	DECLARE @E_Collect_Date as datetime

	DECLARE @Get_TargetFlg as tinyint

	--初期化
	SET @Old_E_Data = 0

	--前回値有無チェック
	DECLARE Old_EquData CURSOR FOR 
	SELECT Equipment_No,Collect_Date,Kind_Name,Kind_Class,Kind_Priority,Lot_Name,Collect_Value,OK_Value,
		NG_Value,Inst_No,Target_Value,Target_No,Production_Cost
	FROM TD_EQUIPMENT_STATUS
	WHERE Equipment_No = @Equipment_No

	--カーソルをオープンし、内容を確認
	OPEN Old_EquData

	--行の取りだし
	FETCH NEXT FROM Old_EquData INTO @E_Equipment_No,@E_Collect_Date,@E_Kind_Name,@E_Kind_Class,@E_Kind_Priority,
		@E_Lot_Name,@E_Collect_Value,@E_OK_Value,@E_NG_Value,@E_Inst_No,@E_Target_Value,
		@E_Target_No,@E_Production_Cost
	
	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--前回値取得済み
			SET @Old_E_Data = 1

		--行の取りだし
		FETCH NEXT FROM Old_EquData INTO @E_Equipment_No,@E_Collect_Date,@E_Kind_Name,@E_Kind_Class,@E_Kind_Priority,
			@E_Lot_Name,@E_Collect_Value,@E_OK_Value,@E_NG_Value,@E_Inst_No,@E_Target_Value,
			@E_Target_No,@E_Production_Cost
		END
	--カーソルを閉じる
	CLOSE Old_EquData
	DEALLOCATE Old_EquData

	DECLARE @Sch_No as bigint
	DECLARE @Get_Sch_Flg as tinyint

	--初期化
	SET @Get_Sch_Flg = 0 

	--計画値の取得
	DECLARE SchData CURSOR FOR
	SELECT TOP(1) Sch_No
	FROM V_Collect_Value
	WHERE Row_No = @Row_No

	--カーソルをオープンし、内容を確認
	OPEN SchData

	--行の取り出し
	FETCH NEXT FROM SchData INTO @Sch_No

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--スケジュールデータの取得成功
			SET @Get_Sch_Flg = 1
			--行の取り出し
			FETCH NEXT FROM SchData INTO @Sch_No
		END
	--カーソルを閉じる
	CLOSE SchData
	DEALLOCATE SchData

	--データのNULLチェック
	IF(@Sch_No is null)
		BEGIN
			--強制的に0を書込む
			SET @Get_Sch_Flg = 0

		END

	--指示No.の有無チェック
	IF(@Get_Sch_Flg = 0)
		BEGIN
			--計画値の取得
			DECLARE Target_Data1 CURSOR FOR
			SELECT TOP(1) Target_No,Target_Value,Production_Cost
			FROM TD_TARGET_VALUE
			WHERE Equipment_No = @Equipment_No
				AND Kind_Name = @Kind_Name
				AND Kind_Class = @Kind_Class
				AND Kind_Priority = @Kind_Priority
				AND Start_Date <= @Collect_Date
			ORDER BY Start_Date DESC,Manu_Order DESC

			--カーソルをオープンし、内容を確認
			OPEN Target_Data1

			--行の取り出し
			FETCH NEXT FROM Target_Data1 INTO @E_Target_No,@E_Target_Value,@E_Production_Cost

			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					--行の取り出し
					FETCH NEXT FROM Target_Data1 INTO @E_Target_No,@E_Target_Value,@E_Production_Cost
				END
			--カーソルを閉じる
			CLOSE Target_Data1
			DEALLOCATE Target_Data1
		END
	ELSE
		BEGIN
			--計画値の取得
			DECLARE Target_Data2 CURSOR FOR
			SELECT TOP(1) Target_No,Target_Value,Production_Cost
			FROM TD_TARGET_VALUE
			WHERE Sch_No = @Sch_No

			--カーソルをオープンし、内容を確認
			OPEN Target_Data2

			--行の取り出し
			FETCH NEXT FROM Target_Data2 INTO @E_Target_No,@E_Target_Value,@E_Production_Cost

			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					--行の取り出し
					FETCH NEXT FROM Target_Data2 INTO @E_Target_No,@E_Target_Value,@E_Production_Cost
				END
			--カーソルを閉じる
			CLOSE Target_Data2
			DEALLOCATE Target_Data2
		END

	--フラグチェック
	IF(@Old_E_Data = 1)
		BEGIN
			--データの移動
			SET @E_Equipment_No = @Equipment_No
			SET @E_Kind_Name = @Kind_Name
			SET @E_Kind_Class = @Kind_Class
			SET @E_Kind_Priority = @Kind_Priority
			SET @E_Lot_Name = @Lot_Name
			SET @E_Collect_Value = @Collect_Value
			SET @E_OK_Value = @OK_Value
			SET @E_NG_Value = @NG_Value
			SET @E_Inst_No = @Inst_No

			IF(@Manufact_Flg = @MANU_FLG_START)
				BEGIN
					SET @E_Collect_Date = @Collect_Date
				END

			--UPDATE処理の実施			
			UPDATE TD_EQUIPMENT_STATUS SET Equipment_No = @E_Equipment_No,Collect_Date = @E_Collect_Date,Kind_Name = @E_Kind_Name,
				Kind_Class = @E_Kind_Class,Kind_Priority = @E_Kind_Priority,Lot_Name = @E_Lot_Name,Collect_Value = @E_Collect_Value,
				OK_Value = @E_OK_Value,NG_Value = @E_NG_Value,Inst_No = @E_Inst_No,Target_Value = @E_Target_Value,
				Target_No = @E_Target_No,Production_Cost = @E_Production_Cost,Last_Update = GETDATE()
			 WHERE Equipment_No = @Equipment_No

		END
	ELSE
		BEGIN
			--データの移動
			SET @E_Equipment_No = @Equipment_No
			SET @E_Collect_Date = @Collect_Date
			SET @E_Kind_Name = @Kind_Name
			SET @E_Kind_Class = @Kind_Class
			SET @E_Kind_Priority = @Kind_Priority
			SET @E_Lot_Name = @Lot_Name
			SET @E_Collect_Value = @Collect_Value
			SET @E_OK_Value = @OK_Value
			SET @E_NG_Value = @NG_Value
			SET @E_Inst_No = @Inst_No

			--INSERT処理の実施
			INSERT INTO TD_EQUIPMENT_STATUS (Equipment_No,Collect_Date,Kind_Name,Kind_Class,Kind_Priority,Lot_Name,
				Collect_Value,OK_Value,NG_Value,Status_No,Inst_No,Target_Value,Target_No,Production_Cost,Last_Update)
			VALUES (@E_Equipment_No,@E_Collect_Date,@E_Kind_Name,@E_Kind_Class,@E_Kind_Priority,@E_Lot_Name,@E_Collect_Value,
				@E_OK_Value,@E_NG_Value,0,@E_Inst_No,@E_Target_Value,@E_Target_No,@E_Production_Cost,GETDATE())

		END

END

go

