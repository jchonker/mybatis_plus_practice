
CREATE VIEW [dbo].[V_MANU_INSTRUCT] AS 
	SELECT A.*,[PRO_RECIPE].[Setting_Comment1],[PRO_RECIPE].[Setting_Value1],[PRO_RECIPE].[Setting_Comment2],[PRO_RECIPE].[Setting_Value2],[PRO_RECIPE].[Setting_Comment3],
		[PRO_RECIPE].[Setting_Value3],[PRO_RECIPE].[Setting_Comment4],[PRO_RECIPE].[Setting_Value4],[PRO_RECIPE].[Setting_Comment5],[PRO_RECIPE].[Setting_Value5],
		[PRO_RECIPE].[Setting_Comment6],[PRO_RECIPE].[Setting_Value6],[PRO_RECIPE].[Setting_Comment7],[PRO_RECIPE].[Setting_Value7],[PRO_RECIPE].[Setting_Comment8],
		[PRO_RECIPE].[Setting_Value8],[PRO_RECIPE].[Setting_Comment9],[PRO_RECIPE].[Setting_Value9],[PRO_RECIPE].[Setting_Comment10],[PRO_RECIPE].[Setting_Value10]
	FROM (
		SELECT [MANU_INST].[Seq_No1],[MANU_INST].[Seq_No2],[MANU_INST].[Serial_Number],[MANU_INST].[Kind_Name],[MANU_INST].[Kind_Class],[MANU_INST].[Process_Code],
			[MANU_INST].[Depart_Code],[MANU_INST].[Order_Count],[MANU_INST].[Delivery_Date],[MANU_INST].[Lead_Time],[MANU_INST].[Cancel_Flg],[MANU_INST].[Model_Number],
			[MANU_INST].[Performance_Reporting],[MANU_INST].[Report_Count],[MANU_INST].[Setting_Sch_Count],[MANU_INST].[Product_Comp_Flg],[MANU_INST].[Inst_Row_No],
			[PRO_SCH].[Product_Plan_Date],[PRO_SCH].[Manu_Order],[PRO_SCH].[Equipment_No],[PRO_SCH].[Manu_Count],[PRO_SCH].[Sch_No],[PRO_SCH].[Sch_Index],
			[PRO_SCH].[Maulti_Dev_Flg],[PRO_SCH].[Comp_Flg]
		FROM [SA1].[dbo].[TD_PRODUCT_SCHEDULE] AS [PRO_SCH] LEFT JOIN [SA1].[dbo].[TD_MANU_INSTRUCTION] AS [MANU_INST] ON [PRO_SCH].[Inst_Row_No] = [MANU_INST].[Inst_Row_No]
		) AS A LEFT JOIN  [SA1].[dbo].[TD_PRODUCTION_RECIPE] AS [PRO_RECIPE] ON A.[Equipment_No] = [PRO_RECIPE].[Equipment_No] AND A.[Kind_Name] = [PRO_RECIPE].[Kind_Name]
			AND A.[Kind_Class] = [PRO_RECIPE].[Kind_Class]
go

exec sp_addextendedproperty 'MS_Description', '製造指示ビュー', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT'
go

exec sp_addextendedproperty 'MS_Description', '指示シーケンスNo.1', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Seq_No1'
go

exec sp_addextendedproperty 'MS_Description', '指示シーケンスNo.2', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Seq_No2'
go

exec sp_addextendedproperty 'MS_Description', '製番', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Serial_Number'
go

exec sp_addextendedproperty 'MS_Description', '品目コード', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN', 'Kind_Name'
go

exec sp_addextendedproperty 'MS_Description', '品目区分', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN', 'Kind_Class'
go

exec sp_addextendedproperty 'MS_Description', '工程コード', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Process_Code'
go

exec sp_addextendedproperty 'MS_Description', '部署コード', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Depart_Code'
go

exec sp_addextendedproperty 'MS_Description', '生産数', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN', 'Order_Count'
go

exec sp_addextendedproperty 'MS_Description', '納期', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Delivery_Date'
go

exec sp_addextendedproperty 'MS_Description', 'リードタイム', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Lead_Time'
go

exec sp_addextendedproperty 'MS_Description', '取消フラグ', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Cancel_Flg'
go

exec sp_addextendedproperty 'MS_Description', '型式', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN', 'Model_Number'
go

exec sp_addextendedproperty 'MS_Description', '報告実績値', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Performance_Reporting'
go

exec sp_addextendedproperty 'MS_Description', '報告回数', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Report_Count'
go

exec sp_addextendedproperty 'MS_Description', '設定スケジュール数', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Sch_Count'
go

exec sp_addextendedproperty 'MS_Description', '製造完了フラグ', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Product_Comp_Flg'
go

exec sp_addextendedproperty 'MS_Description', '指示RowNo', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Inst_Row_No'
go

exec sp_addextendedproperty 'MS_Description', '製造予定日', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Product_Plan_Date'
go

exec sp_addextendedproperty 'MS_Description', '製造順序', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN', 'Manu_Order'
go

exec sp_addextendedproperty 'MS_Description', '装置No.', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Equipment_No'
go

exec sp_addextendedproperty 'MS_Description', '製造予定数', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Manu_Count'
go

exec sp_addextendedproperty 'MS_Description', 'スケジュールNo.', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Sch_No'
go

exec sp_addextendedproperty 'MS_Description', 'スケジュールIndex.', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Sch_Index'
go

exec sp_addextendedproperty 'MS_Description', '複数装置対応フラグ', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Maulti_Dev_Flg'
go

exec sp_addextendedproperty 'MS_Description', '指示完了フラグ', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Comp_Flg'
go

exec sp_addextendedproperty 'MS_Description', '設定内容No.1', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Comment1'
go

exec sp_addextendedproperty 'MS_Description', '設定値No.1', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Value1'
go

exec sp_addextendedproperty 'MS_Description', '設定内容No.2', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Comment2'
go

exec sp_addextendedproperty 'MS_Description', '設定値No.2', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Value2'
go

exec sp_addextendedproperty 'MS_Description', '設定内容No.3', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Comment3'
go

exec sp_addextendedproperty 'MS_Description', '設定値No.3', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Value3'
go

exec sp_addextendedproperty 'MS_Description', '設定内容No.4', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Comment4'
go

exec sp_addextendedproperty 'MS_Description', '設定値No.4', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Value4'
go

exec sp_addextendedproperty 'MS_Description', '設定内容No.5', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Comment5'
go

exec sp_addextendedproperty 'MS_Description', '設定値No.5', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Value5'
go

exec sp_addextendedproperty 'MS_Description', '設定内容No.6', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Comment6'
go

exec sp_addextendedproperty 'MS_Description', '設定値No.6', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Value6'
go

exec sp_addextendedproperty 'MS_Description', '設定内容No.7', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Comment7'
go

exec sp_addextendedproperty 'MS_Description', '設定値No.7', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Value7'
go

exec sp_addextendedproperty 'MS_Description', '設定内容No.8', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Comment8'
go

exec sp_addextendedproperty 'MS_Description', '設定値No.8', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Value8'
go

exec sp_addextendedproperty 'MS_Description', '設定内容No.9', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Comment9'
go

exec sp_addextendedproperty 'MS_Description', '設定値No.9', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Value9'
go

exec sp_addextendedproperty 'MS_Description', '設定内容No.10', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Comment10'
go

exec sp_addextendedproperty 'MS_Description', '設定値No.10', 'SCHEMA', 'dbo', 'VIEW', 'V_MANU_INSTRUCT', 'COLUMN',
                            'Setting_Value10'
go

