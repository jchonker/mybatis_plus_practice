
/***********************************************************************************
*
* 製品名        ：上位システム連携機能
* 処理名        ：品目マスタ　展開用トリガ(DELETE用)
* トリガ名		：TR3_TM_KIND
* 概要          ：TM_KIND_EXCLE→TM_KIND_INFO、TM_KIND_NAMEへの展開(DELETE)
* バージョン    ：1.910
*
* 作成者        ：Takasima Hironori
* 作成日        ：2016/09/13
* 更新者        ：
* 更新日        ：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE TRIGGER [dbo].[TR3_TM_KIND] ON [dbo].[TM_KIND_EXCEL] AFTER DELETE 
AS
BEGIN

	DECLARE @Kind_Name as varchar(40)
	DECLARE @Kind_Class as varchar(40)
	DECLARE @Lang_Mode as tinyint
    
	DECLARE @Chk_Kind_Name as varchar(40)
	DECLARE @Delete_Flg as tinyint

    DECLARE DeleteData CURSOR FOR
    SELECT Kind_Name,Kind_Class,Lang_Mode
    FROM DELETED
    
    --カーソルをオープンし、内容を確認
    OPEN DeleteData
    
    --行の取り出し
    FETCH NEXT FROM DeleteData INTO @Kind_Name,@Kind_Class,@Lang_Mode
    
    --ループ処理
    WHILE (@@FETCH_STATUS = 0)
    	BEGIN
    		
			--フラグ初期化
			SET @Delete_Flg = 1

			--消そうとしているデータについて他の言語で使用しているかを確認
			DECLARE ChkDelete CURSOR FOR
			SELECT Kind_Name
			FROM TM_KIND_NAME
			WHERE Kind_Name = @Kind_Name AND Kind_Class = @Kind_Class AND Lang_Mode <> @Lang_Mode

			--カーソルをオープンし、内容を確認
			OPEN ChkDelete

			--行の取り出し
			FETCH NEXT FROM ChkDelete INTO @Chk_Kind_Name

			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					--フラグを0にし、削除を行わない
					SET @Delete_Flg = 0

					--行の取り出し
					FETCH NEXT FROM ChkDelete INTO @Chk_Kind_Name
				END
			
			--削除フラグチェック
			IF(@Delete_Flg = 1)
				BEGIN

					--品目情報マスタ(TM_KIND_INFO)への展開
					DELETE FROM TM_KIND_INFO WHERE Kind_Name = @Kind_Name AND Kind_Class = @Kind_Class

				END
		
			--品目名称マスタ(TM_KIND_NAME)への展開
			DELETE FROM TM_KIND_NAME WHERE Kind_Name = @Kind_Name AND Kind_Class = @Kind_Class AND Lang_Mode = @Lang_Mode
    
    		--次の行へ移動
    		FETCH NEXT FROM DeleteData INTO @Kind_Name,@Kind_Class,@Lang_Mode

			--カーソルを閉じる
			CLOSE ChkDelete
			DEALLOCATE ChkDelete
    
    	END
    --カーソルを閉じる
    CLOSE DeleteData
    DEALLOCATE DeleteData

END

go

