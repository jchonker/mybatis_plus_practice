
/***********************************************************************************
*
* 製品名			：生産分析機能
* 処理名			：日データ収集(状態履歴)
* ファンクション名	：DayCollect_Status
* 概要				：稼働監視画面用状態履歴データ収集処理
* バージョン		：1.12.0.0
*
* 作成者			：Takasima Hironori
* 作成日			：2017/07/08
* 更新者			：
* 更新日			：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE PROCEDURE [dbo].[DayCollect_Status]
(
	@Equipment_No			int,		--装置No.
	@Target_Date			date		--収集対象日付
)
AS
BEGIN
	
	DECLARE @tmpSetData as varchar(20)
	DECLARE @Start_Hour as int
	DECLARE @Start_Min as int
	DECLARE @Start_Date as datetime
	DECLARE @End_Date as datetime
	DECLARE @Status_Count0 AS int = 0				--稼働状態0 発生回数
	DECLARE @Status_Time0 AS int = 0				--稼働状態0 発生時間
	DECLARE @Status_Count1 AS int = 0				--稼働状態1 発生回数
	DECLARE @Status_Time1 AS int = 0				--稼働状態1 発生時間
	DECLARE @Status_Count2 AS int = 0				--稼働状態2 発生回数
	DECLARE @Status_Time2 AS int = 0				--稼働状態2 発生時間
	DECLARE @Status_Count3 AS int = 0				--稼働状態3 発生回数
	DECLARE @Status_Time3 AS int = 0				--稼働状態3 発生時間
	DECLARE @Status_Count4 AS int = 0				--稼働状態4 発生回数
	DECLARE @Status_Time4 AS int = 0				--稼働状態4 発生時間
	DECLARE @Status_Count5 AS int = 0				--稼働状態5 発生回数
	DECLARE @Status_Time5 AS int = 0				--稼働状態5 発生時間
	DECLARE @Status_Count6 AS int = 0				--稼働状態6 発生回数
	DECLARE @Status_Time6 AS int = 0				--稼働状態6 発生時間
	DECLARE @Status_Count7 AS int = 0				--稼働状態7 発生回数
	DECLARE @Status_Time7 AS int = 0				--稼働状態7 発生時間
	DECLARE @Status_Count8 AS int = 0				--稼働状態8 発生回数
	DECLARE @Status_Time8 AS int = 0				--稼働状態8 発生時間
	DECLARE @Status_Count9 AS int = 0				--稼働状態9 発生回数
	DECLARE @Status_Time9 AS int = 0				--稼働状態9 発生時間
	DECLARE @Normal_Time AS int = 0
	DECLARE @All_Time as int = 0

	--初期値
	SET @Start_Hour = -1
	SET @Start_Min = -1

	--収集開始時刻の取得
	DECLARE OptionSet1 CURSOR FOR
	SELECT Setting_Value
	FROM TM_OPTION_SETTING
	WHERE Key_Name = 'Start_Hour'

	--カーソルをオープンし、内容を確認
	OPEN OptionSet1

	--行の取り出し
	FETCH NEXT FROM OptionSet1 INTO @tmpSetData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			--数値に変換
			SET @Start_Hour = CONVERT(int,@tmpSetData)

			--行の取り出し
			FETCH NEXT FROM OptionSet1 INTO @tmpSetData
		END
	--カーソルを閉じる
	CLOSE OptionSet1
	DEALLOCATE OptionSet1

	--収集開始時刻の取得
	DECLARE OptionSet2 CURSOR FOR
	SELECT Setting_Value
	FROM TM_OPTION_SETTING
	WHERE Key_Name = 'Start_Min'

	--カーソルをオープンし、内容を確認
	OPEN OptionSet2

	--行の取り出し
	FETCH NEXT FROM OptionSet2 INTO @tmpSetData

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			--数値に変換
			SET @Start_Min = CONVERT(int,@tmpSetData)

			--行の取り出し
			FETCH NEXT FROM OptionSet2 INTO @tmpSetData
		END
	--カーソルを閉じる
	CLOSE OptionSet2
	DEALLOCATE OptionSet2

	--処理確認
	IF((@Start_Hour = -1) or (@Start_Min = -1))
		BEGIN
			--処理を抜ける
			goto proc_end

		END

	--集計対象日時の設定
	--検索開始日時
	SET @Start_Date = CONVERT(datetime,FORMAT(@Target_Date,'yyyy/MM/dd') + ' ' + RIGHT('00' + CONVERT(varchar, @Start_Hour),2) + ':' + RIGHT('00' + CONVERT(varchar, @Start_Min),2) + ':00')
	--検索終了日時
	SET @End_Date = DATEADD(day,1,@Start_Date)

	--現在時刻チェック
	if(@End_Date > GETDATE())
		BEGIN
			SET @End_Date = GETDATE()
		END

	DECLARE @CountFlg AS int
	DECLARE @AddTime AS int
	DECLARE @Old_Date AS datetime
	DECLARE @Old_Status AS int
	DECLARE @Old_GetFlg AS int
	DECLARE @NULL_GetFlg AS int
	DECLARE @NULL_GetDate as datetime
	DECLARE @NULL_State as int
	DECLARE @tmpDate as datetime
	DECLARE @tmpInt1 AS int
	DECLARE @tmpInt2 AS int
	DECLARE @tmpInt3 AS int

	--対象データ取得
	DECLARE STAT_VAL CURSOR FOR
	SELECT *
	FROM (
		SELECT TD_ST1.Equipment_No,TD_ST1.Collect_Date,TD_ST1.Status_No,TD_ST1.Status_Time
		FROM (
			SELECT Equipment_No,MAX(Row_No) AS Row_No
			FROM TD_COLLECT_STATUS
			WHERE Equipment_No = @Equipment_No
				AND Collect_Date <= @Start_Date
			Group BY Equipment_No
		) AS A LEFT JOIN TD_COLLECT_STATUS AS TD_ST1 ON A.Row_No = TD_ST1.Row_No
		UNION 
		SELECT TD_ST2.Equipment_No,TD_ST2.Collect_Date,TD_ST2.Status_No,TD_ST2.Status_Time
		FROM TD_COLLECT_STATUS AS TD_ST2
		WHERE TD_ST2.Equipment_No = @Equipment_No
			AND Collect_Date > @Start_Date AND Collect_Date <= @End_Date
		) AS B
	ORDER BY B.Equipment_No ASC,B.Collect_Date ASC	

	--カーソルのOPEN
	OPEN STAT_VAL

	--行の取り出し
	FETCH NEXT FROM STAT_VAL INTO @tmpInt1,@tmpDate,@tmpInt2,@tmpInt3

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--初期化
			SET @CountFlg = 0
			SET @AddTime = 0

			--前回取込んだ値がNULLの場合、その差分を実績値として加算する
			IF(@NULL_GetFlg = 1)
				BEGIN
					--該当状態の終了時刻までを書込む
					SET @AddTime = DATEDIFF(second,@NULL_GetDate,@tmpDate)
					SET @CountFlg = 1

					--マイナス値チェック
					IF(@AddTime < 0)
						BEGIN
							--数値を0に変更
							SET @AddTime = 0
						END

					--状態に応じて書込み先を変更
					IF(@NULL_State = 0)
						BEGIN
							--回数の追加
							SET @Status_Count0 = @Status_Count0 + @CountFlg
							--時間の追加
							SET @Status_Time0 = @Status_Time0 + @AddTime
						END
					ELSE IF(@NULL_State = 1)
						BEGIN
							--回数の追加
							SET @Status_Count1 = @Status_Count1 + @CountFlg
							--時間の追加
							SET @Status_Time1 = @Status_Time1 + @AddTime
						END
					ELSE IF(@NULL_State = 2)
						BEGIN
							--回数の追加
							SET @Status_Count2 = @Status_Count2 + @CountFlg
							--時間の追加
							SET @Status_Time2 = @Status_Time2 + @AddTime
						END
					ELSE IF(@NULL_State = 3)
						BEGIN
							--回数の追加
							SET @Status_Count3 = @Status_Count3 + @CountFlg
							--時間の追加
							SET @Status_Time3 = @Status_Time3 + @AddTime
						END
					ELSE IF(@NULL_State = 4)
						BEGIN
							--回数の追加
							SET @Status_Count4 = @Status_Count4 + @CountFlg
							--時間の追加
							SET @Status_Time4 = @Status_Time4 + @AddTime
						END
					ELSE IF(@NULL_State = 5)
						BEGIN
							--回数の追加
							SET @Status_Count5 = @Status_Count5 + @CountFlg
							--時間の追加
							SET @Status_Time5 = @Status_Time5 + @AddTime
						END
					ELSE IF(@NULL_State = 6)
						BEGIN
							--回数の追加
							SET @Status_Count6 = @Status_Count6 + @CountFlg
							--時間の追加
							SET @Status_Time6 = @Status_Time6 + @AddTime
						END
					ELSE IF(@NULL_State = 7)
						BEGIN
							--回数の追加
							SET @Status_Count7 = @Status_Count7 + @CountFlg
							--時間の追加
							SET @Status_Time7 = @Status_Time7 + @AddTime
						END
					ELSE IF(@NULL_State = 8)
						BEGIN
							--回数の追加
							SET @Status_Count8 = @Status_Count8 + @CountFlg
							--時間の追加
							SET @Status_Time8 = @Status_Time8 + @AddTime
						END
					ELSE IF(@NULL_State = 9)
						BEGIN
							--回数の追加
							SET @Status_Count9 = @Status_Count9 + @CountFlg
							--時間の追加
							SET @Status_Time9 = @Status_Time9 + @AddTime
						END
					--書込み完了後、フラグを初期化
					SET @NULL_GetFlg = 0

					--初期化
					SET @CountFlg = 0
					SET @AddTime = 0

				END

			--開始時刻以前のデータ確認
			IF(@Old_GetFlg = 1)
				BEGIN
					--開始時刻以前からのデータを加算
					SET @CountFlg = 1
					SET @AddTime = DATEDIFF(second,@Start_Date,@tmpDate)

					--マイナス値チェック
					IF(@AddTime < 0)
						BEGIN
							--数値を0に変更
							SET @AddTime = 0
						END

					--取得した日付が過去の場合、値を初期化
					IF(@Start_Date > @tmpDate)
						BEGIN
							--過去の値になるため、演算値を初期化
							SET @CountFlg = 0
							SET @AddTime = 0

						END

					--状態に応じて書込み先を変更
					IF(@Old_Status = 0)
						BEGIN
							--回数の追加
							SET @Status_Count0 = @Status_Count0 + @CountFlg
							--時間の追加
							SET @Status_Time0 = @Status_Time0 + @AddTime
						END
					ELSE IF(@Old_Status = 1)
						BEGIN
							--回数の追加
							SET @Status_Count1 = @Status_Count1 + @CountFlg
							--時間の追加
							SET @Status_Time1 = @Status_Time1 + @AddTime
						END
					ELSE IF(@Old_Status = 2)
						BEGIN
							--回数の追加
							SET @Status_Count2 = @Status_Count2 + @CountFlg
							--時間の追加
							SET @Status_Time2 = @Status_Time2 + @AddTime
						END
					ELSE IF(@Old_Status = 3)
						BEGIN
							--回数の追加
							SET @Status_Count3 = @Status_Count3 + @CountFlg
							--時間の追加
							SET @Status_Time3 = @Status_Time3 + @AddTime
						END
					ELSE IF(@Old_Status = 4)
						BEGIN
							--回数の追加
							SET @Status_Count4 = @Status_Count4 + @CountFlg
							--時間の追加
							SET @Status_Time4 = @Status_Time4 + @AddTime
						END
					ELSE IF(@Old_Status = 5)
						BEGIN
							--回数の追加
							SET @Status_Count5 = @Status_Count5 + @CountFlg
							--時間の追加
							SET @Status_Time5 = @Status_Time5 + @AddTime
						END
					ELSE IF(@Old_Status = 6)
						BEGIN
							--回数の追加
							SET @Status_Count6 = @Status_Count6 + @CountFlg
							--時間の追加
							SET @Status_Time6 = @Status_Time6 + @AddTime
						END
					ELSE IF(@Old_Status = 7)
						BEGIN
							--回数の追加
							SET @Status_Count7 = @Status_Count7 + @CountFlg
							--時間の追加
							SET @Status_Time7 = @Status_Time7 + @AddTime
						END
					ELSE IF(@Old_Status = 8)
						BEGIN
							--回数の追加
							SET @Status_Count8 = @Status_Count8 + @CountFlg
							--時間の追加
							SET @Status_Time8 = @Status_Time8 + @AddTime
						END
					ELSE IF(@Old_Status = 9)
						BEGIN
							--回数の追加
							SET @Status_Count9 = @Status_Count9 + @CountFlg
							--時間の追加
							SET @Status_Time9 = @Status_Time9 + @AddTime
						END
					
					--値を初期化
					SET @CountFlg = 0
					SET @AddTime = 0

					--フラグを更新
					SET @Old_GetFlg = 2
				END

			--取得した日時が開始時刻以前かをチェック
			IF(@tmpDate <= @Start_Date)
				BEGIN
					--前回値を記録
					SET @Old_Date = @tmpDate
					SET @Old_Status = @tmpInt2
					--フラグを更新
					SET @Old_GetFlg = 1
				END
			ELSE
				BEGIN
					--取得した項目の状態変化時間のNULLチェック
					IF(@tmpInt3 IS NULL)
						BEGIN
							--NULLフラグを設定
							SET @NULL_GetFlg = 1
							--NULLだった値を設定
							SET @NULL_GetDate = @tmpDate
							SET @NULL_State = @tmpInt2
							--初期化
							SET @CountFlg = 0
							SET @AddTime = 0
	
						END
					ELSE
						BEGIN
							--該当状態の終了時間が表示範囲内かをチェック
							IF(@End_Date >= DATEADD(second,@tmpInt3,@tmpDate))
								BEGIN
									--状態変化時間をそのまま書込み
									SET @CountFlg = 1
									SET @AddTime = @tmpInt3
								END
							ELSE
								BEGIN
									--NULLフラグを設定
									SET @NULL_GetFlg = 1
									--NULLだった値を設定
									SET @NULL_GetDate = @tmpDate
									SET @NULL_State = @tmpInt2
									--初期化
									SET @CountFlg = 0
									SET @AddTime = 0
								END									
						END
				END

			--状態に応じて書込み先を変更
			IF(@tmpInt2 = 0)
				BEGIN
					--回数の追加
					SET @Status_Count0 = @Status_Count0 + @CountFlg
					--時間の追加
					SET @Status_Time0 = @Status_Time0 + @AddTime
				END
			ELSE IF(@tmpInt2 = 1)
				BEGIN
					--回数の追加
					SET @Status_Count1 = @Status_Count1 + @CountFlg
					--時間の追加
					SET @Status_Time1 = @Status_Time1 + @AddTime
				END
			ELSE IF(@tmpInt2 = 2)
				BEGIN
					--回数の追加
					SET @Status_Count2 = @Status_Count2 + @CountFlg
					--時間の追加
					SET @Status_Time2 = @Status_Time2 + @AddTime
				END
			ELSE IF(@tmpInt2 = 3)
				BEGIN
					--回数の追加
					SET @Status_Count3 = @Status_Count3 + @CountFlg
					--時間の追加
					SET @Status_Time3 = @Status_Time3 + @AddTime
				END
			ELSE IF(@tmpInt2 = 4)
				BEGIN
					--回数の追加
					SET @Status_Count4 = @Status_Count4 + @CountFlg
					--時間の追加
					SET @Status_Time4 = @Status_Time4 + @AddTime
				END
			ELSE IF(@tmpInt2 = 5)
				BEGIN
					--回数の追加
					SET @Status_Count5 = @Status_Count5 + @CountFlg
					--時間の追加
					SET @Status_Time5 = @Status_Time5 + @AddTime
				END
			ELSE IF(@tmpInt2 = 6)
				BEGIN
					--回数の追加
					SET @Status_Count6 = @Status_Count6 + @CountFlg
					--時間の追加
					SET @Status_Time6 = @Status_Time6 + @AddTime
				END
			ELSE IF(@tmpInt2 = 7)
				BEGIN
					--回数の追加
					SET @Status_Count7 = @Status_Count7 + @CountFlg
					--時間の追加
					SET @Status_Time7 = @Status_Time7 + @AddTime
				END
			ELSE IF(@tmpInt2 = 8)
				BEGIN
					--回数の追加
					SET @Status_Count8 = @Status_Count8 + @CountFlg
					--時間の追加
					SET @Status_Time8 = @Status_Time8 + @AddTime
				END
			ELSE IF(@tmpInt2 = 9)
				BEGIN
					--回数の追加
					SET @Status_Count9 = @Status_Count9 + @CountFlg
					--時間の追加
					SET @Status_Time9 = @Status_Time9 + @AddTime
				END

			--行の移動
			FETCH NEXT FROM STAT_VAL INTO @tmpInt1,@tmpDate,@tmpInt2,@tmpInt3
		END

	--カーソルを閉じる
	CLOSE STAT_VAL
	DEALLOCATE STAT_VAL

	--フラグ残りチェック
	IF(@Old_GetFlg = 1)
		BEGIN
			--表示範囲にて稼働状態の変化がなかったため、表示範囲の時間を
			--該当するステータスに加算
			SET @CountFlg = 1
			SET @AddTime = DATEDIFF(second,@Start_Date,@End_Date)

			--マイナス値チェック
			IF(@AddTime < 0)
				BEGIN
					--数値を0に変更
					SET @AddTime = 0
				END

			--状態に応じて書込み先を変更
			IF(@Old_Status = 0)
				BEGIN
					--回数の追加
					SET @Status_Count0 = @Status_Count0 + @CountFlg
					--時間の追加
					SET @Status_Time0 = @Status_Time0 + @AddTime
				END
			ELSE IF(@Old_Status = 1)
				BEGIN
					--回数の追加
					SET @Status_Count1 = @Status_Count1 + @CountFlg
					--時間の追加
					SET @Status_Time1 = @Status_Time1 + @AddTime
				END
			ELSE IF(@Old_Status = 2)
				BEGIN
					--回数の追加
					SET @Status_Count2 = @Status_Count2 + @CountFlg
					--時間の追加
					SET @Status_Time2 = @Status_Time2 + @AddTime
				END
			ELSE IF(@Old_Status = 3)
				BEGIN
					--回数の追加
					SET @Status_Count3 = @Status_Count3 + @CountFlg
					--時間の追加
					SET @Status_Time3 = @Status_Time3 + @AddTime
				END
			ELSE IF(@Old_Status = 4)
				BEGIN
					--回数の追加
					SET @Status_Count4 = @Status_Count4 + @CountFlg
					--時間の追加
					SET @Status_Time4 = @Status_Time4 + @AddTime
				END
			ELSE IF(@Old_Status = 5)
				BEGIN
					--回数の追加
					SET @Status_Count5 = @Status_Count5 + @CountFlg
					--時間の追加
					SET @Status_Time5 = @Status_Time5 + @AddTime
				END
			ELSE IF(@Old_Status = 6)
				BEGIN
					--回数の追加
					SET @Status_Count6 = @Status_Count6 + @CountFlg
					--時間の追加
					SET @Status_Time6 = @Status_Time6 + @AddTime
				END
			ELSE IF(@Old_Status = 7)
				BEGIN
					--回数の追加
					SET @Status_Count7 = @Status_Count7 + @CountFlg
					--時間の追加
					SET @Status_Time7 = @Status_Time7 + @AddTime
				END
			ELSE IF(@Old_Status = 8)
				BEGIN
					--回数の追加
					SET @Status_Count8 = @Status_Count8 + @CountFlg
					--時間の追加
					SET @Status_Time8 = @Status_Time8 + @AddTime
				END
			ELSE IF(@Old_Status = 9)
				BEGIN
					--回数の追加
					SET @Status_Count9 = @Status_Count9 + @CountFlg
					--時間の追加
					SET @Status_Time9 = @Status_Time9 + @AddTime
				END
			--書込み完了後、フラグを初期化
			SET @Old_GetFlg = 0
		END
	--NULLデータ取得チェック
	IF(@NULL_GetFlg = 1)
		BEGIN
			--該当状態の終了時刻までを書込む
			SET @AddTime = DATEDIFF(second,@NULL_GetDate,@End_Date)
			SET @CountFlg = 1

			--マイナス値チェック
			IF(@AddTime < 0)
				BEGIN
					--数値を0に変更
					SET @AddTime = 0
				END

			--状態に応じて書込み先を変更
			IF(@NULL_State = 0)
				BEGIN
					--回数の追加
					SET @Status_Count0 = @Status_Count0 + @CountFlg
					--時間の追加
					SET @Status_Time0 = @Status_Time0 + @AddTime
				END
			ELSE IF(@NULL_State = 1)
				BEGIN
					--回数の追加
					SET @Status_Count1 = @Status_Count1 + @CountFlg
					--時間の追加
					SET @Status_Time1 = @Status_Time1 + @AddTime
				END
			ELSE IF(@NULL_State = 2)
				BEGIN
					--回数の追加
					SET @Status_Count2 = @Status_Count2 + @CountFlg
					--時間の追加
					SET @Status_Time2 = @Status_Time2 + @AddTime
				END
			ELSE IF(@NULL_State = 3)
				BEGIN
					--回数の追加
					SET @Status_Count3 = @Status_Count3 + @CountFlg
					--時間の追加
					SET @Status_Time3 = @Status_Time3 + @AddTime
				END
			ELSE IF(@NULL_State = 4)
				BEGIN
					--回数の追加
					SET @Status_Count4 = @Status_Count4 + @CountFlg
					--時間の追加
					SET @Status_Time4 = @Status_Time4 + @AddTime
				END
			ELSE IF(@NULL_State = 5)
				BEGIN
					--回数の追加
					SET @Status_Count5 = @Status_Count5 + @CountFlg
					--時間の追加
					SET @Status_Time5 = @Status_Time5 + @AddTime
				END
			ELSE IF(@NULL_State = 6)
				BEGIN
					--回数の追加
					SET @Status_Count6 = @Status_Count6 + @CountFlg
					--時間の追加
					SET @Status_Time6 = @Status_Time6 + @AddTime
				END
			ELSE IF(@NULL_State = 7)
				BEGIN
					--回数の追加
					SET @Status_Count7 = @Status_Count7 + @CountFlg
					--時間の追加
					SET @Status_Time7 = @Status_Time7 + @AddTime
				END
			ELSE IF(@NULL_State = 8)
				BEGIN
					--回数の追加
					SET @Status_Count8 = @Status_Count8 + @CountFlg
					--時間の追加
					SET @Status_Time8 = @Status_Time8 + @AddTime
				END
			ELSE IF(@NULL_State = 9)
				BEGIN
					--回数の追加
					SET @Status_Count9 = @Status_Count9 + @CountFlg
					--時間の追加
					SET @Status_Time9 = @Status_Time9 + @AddTime
				END
			--書込み完了後、フラグを初期化
			SET @NULL_GetFlg = 0

		END

	DECLARE @Status_No as int

	--初期化
	SET @Status_No =-1

	--稼働時間の取得
	DECLARE STATUS_DATA1 CURSOR FOR
	SELECT Status_No
	FROM TM_STATUS_INFO
	WHERE Non_Working_Flg = 0

	--カーソルをOPEN
	OPEN STATUS_DATA1

	--行の取り出し
	FETCH NEXT FROM STATUS_DATA1 INTO @Status_No

	--初期化
	SET @Normal_Time = 0
	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			--該当する状態の値を加算
			IF(@Status_No = 0)
				BEGIN
					SET @Normal_Time = @Normal_Time + @Status_Time0
				END
			ELSE IF (@Status_No = 1)
				BEGIN
					SET @Normal_Time = @Normal_Time + @Status_Time1
				END
			ELSE IF (@Status_No = 2)
				BEGIN
					SET @Normal_Time = @Normal_Time + @Status_Time2
				END
			ELSE IF (@Status_No = 3)
				BEGIN
					SET @Normal_Time = @Normal_Time + @Status_Time3
				END
			ELSE IF (@Status_No = 4)
				BEGIN
					SET @Normal_Time = @Normal_Time + @Status_Time4
				END
			ELSE IF (@Status_No = 5)
				BEGIN
					SET @Normal_Time = @Normal_Time + @Status_Time5
				END
			ELSE IF (@Status_No = 6)
				BEGIN
					SET @Normal_Time = @Normal_Time + @Status_Time6
				END
			ELSE IF (@Status_No = 7)
				BEGIN
					SET @Normal_Time = @Normal_Time + @Status_Time7
				END
			ELSE IF (@Status_No = 8)
				BEGIN
					SET @Normal_Time = @Normal_Time + @Status_Time8
				END
			ELSE IF (@Status_No = 9)
				BEGIN
					SET @Normal_Time = @Normal_Time + @Status_Time9
				END
			ELSE
				BEGIN
					SET @Normal_Time = @Normal_Time 

				END

			--行の取り出し
			FETCH NEXT FROM STATUS_DATA1 INTO @Status_No

		END

	--カーソルを閉じる
	CLOSE STATUS_DATA1
	DEALLOCATE STATUS_DATA1

	--初期化
	SET @Status_No =-1

	--生産時間の取得
	DECLARE STATUS_DATA2 CURSOR FOR
	SELECT Status_No
	FROM TM_STATUS_INFO
	WHERE Production_Flg = 1

	--カーソルをOPEN
	OPEN STATUS_DATA2

	--行の取り出し
	FETCH NEXT FROM STATUS_DATA2 INTO @Status_No

	--初期化
	SET @All_Time = 0
	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			
			--該当する状態の値を加算
			IF(@Status_No = 0)
				BEGIN
					SET @All_Time = @All_Time + @Status_Time0
				END
			ELSE IF (@Status_No = 1)
				BEGIN
					SET @All_Time = @All_Time + @Status_Time1
				END
			ELSE IF (@Status_No = 2)
				BEGIN
					SET @All_Time = @All_Time + @Status_Time2
				END
			ELSE IF (@Status_No = 3)
				BEGIN
					SET @All_Time = @All_Time + @Status_Time3
				END
			ELSE IF (@Status_No = 4)
				BEGIN
					SET @All_Time = @All_Time + @Status_Time4
				END
			ELSE IF (@Status_No = 5)
				BEGIN
					SET @All_Time = @All_Time + @Status_Time5
				END
			ELSE IF (@Status_No = 6)
				BEGIN
					SET @All_Time = @All_Time + @Status_Time6
				END
			ELSE IF (@Status_No = 7)
				BEGIN
					SET @All_Time = @All_Time + @Status_Time7
				END
			ELSE IF (@Status_No = 8)
				BEGIN
					SET @All_Time = @All_Time + @Status_Time8
				END
			ELSE IF (@Status_No = 9)
				BEGIN
					SET @All_Time = @All_Time + @Status_Time9
				END
			ELSE
				BEGIN
					SET @All_Time = @All_Time 

				END

			--行の取り出し
			FETCH NEXT FROM STATUS_DATA2 INTO @Status_No

		END

	--カーソルを閉じる
	CLOSE STATUS_DATA2
	DEALLOCATE STATUS_DATA2

	--データの削除
	DELETE FROM TD_COLLECT_DAY_STATUS WHERE Equipment_No = @Equipment_No AND Data_Date = @Target_Date

	--データの挿入
	INSERT INTO TD_COLLECT_DAY_STATUS (Data_Date, Equipment_No, Normal_Time, All_Time, Status_Count0, 
		Status_Time0, Status_Count1, Status_Time1, Status_Count2, Status_Time2, Status_Count3, Status_Time3,
		Status_Count4, Status_Time4, Status_Count5, Status_Time5, Status_Count6, Status_Time6, Status_Count7, 
		Status_Time7, Status_Count8, Status_Time8, Status_Count9, Status_Time9, Last_Update)
	VALUES (@Target_Date,@Equipment_No,@Normal_Time,@All_Time,@Status_Count0,@Status_Time0,
		@Status_Count1,@Status_Time1,@Status_Count2,@Status_Time2,@Status_Count3,@Status_Time3,
		@Status_Count4,@Status_Time4,@Status_Count5,@Status_Time5,@Status_Count6,@Status_Time6,
		@Status_Count7,@Status_Time7,@Status_Count8,@Status_Time8,@Status_Count9,@Status_Time9,GETDATE())

proc_end:

END

go

