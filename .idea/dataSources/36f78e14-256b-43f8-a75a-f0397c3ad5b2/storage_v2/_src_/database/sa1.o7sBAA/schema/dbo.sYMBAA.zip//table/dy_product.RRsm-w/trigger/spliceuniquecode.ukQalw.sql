create TRIGGER spliceUniqueCode on DY_Product after insert
as
begin

	-- 定义字段
	DECLARE @ProductID as VARCHAR(255)  --产品型号
	DECLARE @Length as int   --长度
	DECLARE @Width as int  --宽度
	DECLARE @SerialNumber as int --序号
	DECLARE @UniqueCode as VARCHAR(255)   --唯一码(拼接之后)

	-- 获取插入的值
	select @ProductID = ProductID,
	@Length = Length,
	@Width = Width,
	@SerialNumber = @@IDENTITY
	FROM INSERTED

	-- 将各个字段拼接成UniqueCode
	set @UniqueCode = @ProductID + '-' + CONVERT(varchar(10),@Length) + '-' + CONVERT(varchar(10),@Width) + '-' + CONVERT(varchar(10),@SerialNumber)  --int转换成string
	
	-- 打印uniqueCode
	print(@UniqueCode)
	
	-- cdvf
	update DY_Product set UniqueCode = @UniqueCode where SerialNumber = @SerialNumber;

end
go

