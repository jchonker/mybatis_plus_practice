create procedure selectProduct
		@ProductID varchar(255),  -- 产品型号
		@DeviceID varchar(255),   -- 设备ID
		@EmployeeID varchar(255),  -- 员工ID
		@UniqueCode varchar(255),  -- 唯一码
		@ManufactureDateStart varchar(255),  -- 生产日期开始
		@ManufactureDateEnd varchar(255),  -- 生产日期结尾
		@RecoveryDateStart varchar(255),  -- 恢复日期开始
		@RecoveryDateEnd varchar(255),     -- 恢复日期结尾
		@pageIndex int,		-- 第几页
		@pageSize int	-- 每页包含的记录数
as
	DECLARE @SqlStr NVARCHAR(955),   -- 这个变量是用于存储查询全部数据的sql语句
			@SqlPage NVARCHAR(955),  -- 这个变量用于存储根据每页数查询到的总页数
			@SqlAll NVARCHAR(955)    -- 这个变量是用于储存分页后的sql语句
	set @SqlStr = 'select * from DY_Product where 1=1 and '
	if ISNULL(@ProductID, '') != '' and @ProductID <> ''
		set @SqlStr = @SqlStr + 'ProductID = ''' + @ProductID + ''' and '
		if ISNULL(@DeviceID, '') != '' and @DeviceID <> ''
			set @SqlStr = @SqlStr + 'DeviceID = ''' + @DeviceID + ''' and '
			if ISNULL(@EmployeeID, '') != '' and @EmployeeID <> ''
				set @SqlStr = @SqlStr + 'EmployeeID = ''' + @EmployeeID + ''' and '
				if ISNULL(@UniqueCode, '') != '' and @UniqueCode <> ''
					set @SqlStr = @SqlStr + 'UniqueCode = ''' + @UniqueCode + ''' and '
					if ISNULL(@ManufactureDateStart, '') != ''  and @ManufactureDateStart <> ''
						if ISNULL(@ManufactureDateEnd, '') != '' and @ManufactureDateEnd <> ''
							begin
							set @SqlStr = @SqlStr + 'ManufactureDate between ''' + @ManufactureDateStart + ''' and ''' + @ManufactureDateEnd + ''' and '	
							if ISNULL(@RecoveryDateStart, '') != '' and @RecoveryDateStart <> ''
								if ISNULL(@RecoveryDateEnd, '') != '' and @RecoveryDateEnd <> ''
									set @SqlStr = @SqlStr + 'RecoveryDate between ''' + @RecoveryDateStart + ''' and ''' + @RecoveryDateEnd + ''''
								else
									BEGIN set @SqlStr = @SqlStr + 'RecoveryDate between ''' + @RecoveryDateStart + ''' and ''' + GETDATE() + '''' END
							end
						else
							begin
							set @SqlStr = @SqlStr + 'ManufactureDate between ''' + @ManufactureDateStart + ''' and ''' + GETDATE() + ''' and '   -- 如果生产日期结尾为空，就以当前时间为准
							if ISNULL(@RecoveryDateStart, '') != '' and @RecoveryDateStart <> ''
								if ISNULL(@RecoveryDateEnd, '') != '' and @RecoveryDateEnd <> ''
									set @SqlStr = @SqlStr + 'RecoveryDate between ''' + @RecoveryDateStart + ''' and ''' + @RecoveryDateEnd + ''''
								else
									set @SqlStr = @SqlStr + 'RecoveryDate between ''' + @RecoveryDateStart + ''' and ''' + GETDATE() + ''''
							end
	-- 如果页码和页数不为空才进行分页查询,否则就不进行分页查询
	if ISNULL(@pageIndex, '') != '' and @pageIndex <> '' and ISNULL(@pageSize, '') != '' and @pageSize <> ''
		begin
			-- CEILING :SQL中的取整函数(遇到小数位就加1，非四舍五入)
			-- cast(@pageSize*1.0 as decimal(18,1)  将int型数据转换为小数类型
			set @SqlPage = 'select CEILING((select count(*) from DY_Product)/'+CONVERT(varchar,cast(@pageSize*1.0 as decimal(18,1)))+')'
			-- 使用子查询时要定义一个别名(这里是t)
			set @SqlAll = 'select top (select '+convert(varchar,@pageSize)+') * from (select row_number() over(order by SerialNumber) as rownumber,* from ('+@SqlStr+') as t) temp_row where rownumber > '+convert(varchar,(@pageIndex-1)*@pageSize)+';'
			--select @SqlPage
			--select @SqlAll
			EXEC(@SqlAll)  -- 执行字符串
			EXEC(@SqlPage)  -- 执行字符串
			select '分页查询'
		end
	else
		begin
			EXEC(@SqlStr)  --执行字符串
			select '不分页查询'
		end
go

