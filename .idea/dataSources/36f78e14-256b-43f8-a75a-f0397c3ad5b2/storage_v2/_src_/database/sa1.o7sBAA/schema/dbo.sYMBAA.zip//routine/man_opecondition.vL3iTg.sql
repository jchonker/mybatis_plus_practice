
/***********************************************************************************
*
* 製品名			：生産分析機能
* 処理名			：稼働状態収集処理
* ファンクション名	：MAN_OpeCondition
* 概要				：指定された階層に含まれる装置の稼働状態の取得
* バージョン		：1.800
*
* 作成者			：Takasima Hironori
* 作成日			：2016/03/16
* 更新者			：
* 更新日			：
*
* (C) 2016 Mitsubishi Electric System & Service Co.,Ltd. All Rights Reserved.
*
************************************************************************************/
CREATE FUNCTION [dbo].[MAN_OpeCondition]
(
	@Hierarchy_No			int,				--階層No.
	@Lang_Mode				int,				--言語モード
	@Start_Date				datetime,			--開始時刻
	@End_Date				datetime			--終了時刻
)
RETURNS @retTbl TABLE
(
	Equipment_No int NOT NULL,					--装置No.
	Equipment_Name varchar(32) NULL,			--装置名称
	Equipment_Unit varchar(16) NULL,			--装置単位
	Error_Count int NULL,						--異常回数
	Error_Time int NULL,						--異常時間
	Status_Count0 int NULL,						--稼働状態0 発生回数
	Status_Time0 int NULL,						--稼働状態0 発生時間
	Status_Count1 int NULL,						--稼働状態1 発生回数
	Status_Time1 int NULL,						--稼働状態1 発生時間
	Status_Count2 int NULL,						--稼働状態2 発生回数
	Status_Time2 int NULL,						--稼働状態2 発生時間
	Status_Count3 int NULL,						--稼働状態3 発生回数
	Status_Time3 int NULL,						--稼働状態3 発生時間
	Status_Count4 int NULL,						--稼働状態4 発生回数
	Status_Time4 int NULL,						--稼働状態4 発生時間
	Status_Count5 int NULL,						--稼働状態5 発生回数
	Status_Time5 int NULL,						--稼働状態5 発生時間
	Status_Count6 int NULL,						--稼働状態6 発生回数
	Status_Time6 int NULL,						--稼働状態6 発生時間
	Status_Count7 int NULL,						--稼働状態7 発生回数
	Status_Time7 int NULL,						--稼働状態7 発生時間
	Status_Count8 int NULL,						--稼働状態8 発生回数
	Status_Time8 int NULL,						--稼働状態8 発生時間
	Status_Count9 int NULL,						--稼働状態9 発生回数
	Status_Time9 int NULL						--稼働状態9 発生時間
)
BEGIN

	DECLARE @Equipment_No AS int				--装置No.
	DECLARE @Equipment_Name AS varchar(32)		--装置名称
	DECLARE @Equipment_Unit AS varchar(16)		--装置単位
	DECLARE @Error_Count AS int					--異常回数
	DECLARE @Error_Time AS int					--異常時間
	DECLARE @Status_Count0 AS int				--稼働状態0 発生回数
	DECLARE @Status_Time0 AS int				--稼働状態0 発生時間
	DECLARE @Status_Count1 AS int				--稼働状態1 発生回数
	DECLARE @Status_Time1 AS int				--稼働状態1 発生時間
	DECLARE @Status_Count2 AS int				--稼働状態2 発生回数
	DECLARE @Status_Time2 AS int				--稼働状態2 発生時間
	DECLARE @Status_Count3 AS int				--稼働状態3 発生回数
	DECLARE @Status_Time3 AS int				--稼働状態3 発生時間
	DECLARE @Status_Count4 AS int				--稼働状態4 発生回数
	DECLARE @Status_Time4 AS int				--稼働状態4 発生時間
	DECLARE @Status_Count5 AS int				--稼働状態5 発生回数
	DECLARE @Status_Time5 AS int				--稼働状態5 発生時間
	DECLARE @Status_Count6 AS int				--稼働状態6 発生回数
	DECLARE @Status_Time6 AS int				--稼働状態6 発生時間
	DECLARE @Status_Count7 AS int				--稼働状態7 発生回数
	DECLARE @Status_Time7 AS int				--稼働状態7 発生時間
	DECLARE @Status_Count8 AS int				--稼働状態8 発生回数
	DECLARE @Status_Time8 AS int				--稼働状態8 発生時間
	DECLARE @Status_Count9 AS int				--稼働状態9 発生回数
	DECLARE @Status_Time9 AS int				--稼働状態9 発生時間

	DECLARE @Hierarchy_ID AS varchar(18)		--階層ID
	DECLARE @Hierarchy_Level AS int				--階層レベル

	--初期化
	SET @Hierarchy_ID = ''
	SET @Hierarchy_Level = 0

	--一時格納データ
	DECLARE @tmpHieID AS varchar(18)

	--表示終了時刻の確認
	IF(@End_Date > GETDATE())
		BEGIN
			--未来の日付チェック
			IF(@Start_Date < GETDATE())
				BEGIN
					--終了時刻を現在時刻に変更
					SET @End_Date = GETDATE()
				END
		END

	--階層情報の取得
	DECLARE HIE_VAL CURSOR FOR
	SELECT HIE_INFO.Hierarchy_ID
	FROM TM_HIERARCHY_INFO AS HIE_INFO LEFT JOIN 
		TM_HIERARCHY_NAME AS HIE_NAME ON HIE_INFO.Hierarchy_No = HIE_NAME.Hierarchy_No
	WHERE HIE_INFO.Hierarchy_No = @Hierarchy_No AND HIE_NAME.Lang_Mode = @Lang_Mode

	--カーソルをOPEN
	OPEN HIE_VAL

	--行の取り出し
	FETCH NEXT FROM HIE_VAL INTO @tmpHieID
		
	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--データの格納
			SET @Hierarchy_ID = @tmpHieID

			--行の移動
			FETCH NEXT FROM HIE_VAL INTO @tmpHieID
		END

	--カーソルを閉じる
	CLOSE HIE_VAL
	DEALLOCATE HIE_VAL

	IF(@Hierarchy_ID = '')
		BEGIN
			GOTO Proc_End
		END

	DECLARE @tmpHieLevel AS int
	DECLARE @tmpData AS int

	SET @tmpHieLevel = 1

	--階層IDから階層レベルを求める
	WHILE (@Hierarchy_Level = 0)
		BEGIN
			--文字列から数値の取得
			SET @tmpData = CONVERT(int,SUBSTRING(@Hierarchy_ID,(@tmpHieLevel-1)*3+1,3))
			--数値チェック
			IF(@tmpData = 0)
				BEGIN
					--階層レベルを設定
					SET @Hierarchy_Level = @tmpHieLevel -1

				END
			ELSE IF (@tmpData = 0 AND @tmpHieLevel = 6)
				BEGIN
					--階層レベルを6に設定
					SET @Hierarchy_Level = 6

				END
			--テンポラリを追加
			SET @tmpHieLevel = @tmpHieLevel + 1

		END

	DECLARE @tmpEquNo AS int
	DECLARE @tmpEquName AS varchar(32)
	DECLARE @tmpUnit AS varchar(16)

	--階層に含まれる装置をもとに、各装置の稼働状態を取得
	DECLARE EQU_VAL CURSOR FOR
	SELECT A.Equipment_No,B.Equipment_Name,D.Unit_Name
	FROM (SELECT MIN(HIE_INFO.Hierarchy_No) AS HieNo,HIE_INFO.Equipment_No
	FROM TM_HIERARCHY_INFO AS HIE_INFO LEFT JOIN TM_HIERARCHY_NAME AS HIE_NAME ON HIE_INFO.Hierarchy_No = HIE_NAME.Hierarchy_No
	WHERE  ((SELECT SUBSTRING(Hierarchy_ID, 1, @Hierarchy_Level*3) FROM TM_HIERARCHY_INFO WHERE (Hierarchy_No = @Hierarchy_No)) = SUBSTRING(Hierarchy_ID,1,@Hierarchy_Level*3))
	GROUP BY Equipment_No) AS A 
	LEFT JOIN TM_EQUIPMENT_NAME AS B ON A.Equipment_No = B.Equipment_No 
	LEFT JOIN TM_EQUIPMENT_INFO AS C ON B.Equipment_No = C.Equipment_No
	LEFT JOIN TM_UNIT AS D ON C.Unit_No = D.Unit_No AND B.Lang_Mode = D.Lang_Mode
	WHERE B.Lang_Mode = @Lang_Mode
	ORDER BY HieNo ASC

	--カーソルをOPEN
	OPEN EQU_VAL

	--行の取り出し
	FETCH NEXT FROM EQU_VAL INTO @tmpEquNo,@tmpEquName,@tmpUnit

	--ループ処理
	WHILE (@@FETCH_STATUS = 0)
		BEGIN
			--テンポラリ宣言
			DECLARE @tmpInt1 AS int
			DECLARE @tmpDate AS datetime
			DECLARE @tmpInt2 AS int
			DECLARE @tmpInt3 AS int

			--値の初期化
			SET @Equipment_No = @tmpEquNo
			SET @Equipment_Name = @tmpEquName
			SET @Equipment_Unit = @tmpUnit
			SET @Error_Count = 0
			SET @Error_Time = 0
			SET @Status_Count0 = 0
			SET @Status_Time0 = 0
			SET @Status_Count1 = 0
			SET @Status_Time1 = 0
			SET @Status_Count2 = 0
			SET @Status_Time2 = 0
			SET @Status_Count3 = 0
			SET @Status_Time3 = 0
			SET @Status_Count4 = 0
			SET @Status_Time4 = 0
			SET @Status_Count5 = 0
			SET @Status_Time5 = 0
			SET @Status_Count6 = 0
			SET @Status_Time6 = 0
			SET @Status_Count7 = 0
			SET @Status_Time7 = 0
			SET @Status_Count8 = 0
			SET @Status_Time8 = 0
			SET @Status_Count9 = 0
			SET @Status_Time9 = 0

			--******************************************************
			--               故障回数の取得
			--******************************************************
			DECLARE ERR_COUNT CURSOR FOR
			SELECT COUNT(A.St_Date) AS  Alarm_Count
			FROM(
				SELECT TD_AL1.Equipment_No,TD_AL1.Alarm_Code,TD_AL1.St_Date
				FROM TD_COLLECT_ALARM AS TD_AL1
				WHERE TD_AL1.Equipment_No = @Equipment_No
					AND TD_AL1.St_Date > @Start_Date
					AND TD_AL1.St_Date <= @End_Date
			) AS A 
				LEFT JOIN TM_ALARM_NAME AS TM_AL ON A.Equipment_No = TM_AL.Equipment_No
					AND A.Alarm_Code = TM_AL.Alarm_Code
			WHERE TM_AL.Lang_Mode = @Lang_Mode
			GROUP BY A.Equipment_No


			--カーソルのOPEN
			OPEN ERR_COUNT

			--行の取り出し
			FETCH NEXT FROM ERR_COUNT INTO @tmpInt1

			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					--データの格納
					SET @Error_Count = @tmpInt1

					--行の移動
					FETCH NEXT FROM ERR_COUNT INTO @tmpInt1
				END

			--カーソルを閉じる
			CLOSE ERR_COUNT
			DEALLOCATE ERR_COUNT

			--******************************************************
			--               故障時間の取得
			--******************************************************
			DECLARE ERR_TIME CURSOR FOR
			SELECT sum(D.Data_Count) AS Sum_Time
			FROM (
				SELECT C.Equipment_No,C.Alarm_Code,SUM(C.Data_Count) AS Data_Count
				FROM(
					SELECT *
					FROM(
						SELECT TD_AL1.Equipment_No,TD_AL1.Alarm_Code,sum(TD_AL1.Alarm_Time) AS Data_Count
						FROM TD_COLLECT_ALARM AS TD_AL1
						WHERE TD_AL1.Equipment_No = @Equipment_No
							AND TD_AL1.St_Date > @Start_Date
							AND TD_AL1.St_Date <= @End_Date
							AND NOT(TD_AL1.Alarm_Time IS NULL)
						GROUP BY TD_AL1.Equipment_No,TD_AL1.Alarm_Code
					) AS A 
					UNION (
							SELECT B.Equipment_No,B.Alarm_Code,sum(B.Data_Count) AS Data_Count
							FROM (
								SELECT TD_AL2.Equipment_No,TD_AL2.Alarm_Code,
									CASE WHEN @End_Date <= GETDATE() 
											THEN DATEDIFF(second,TD_AL2.St_Date,@End_Date)
										 WHEN @End_Date > GETDATE() 
											THEN DATEDIFF(second,TD_AL2.St_Date,GETDATE()) END AS Data_Count
								FROM TD_COLLECT_ALARM AS TD_AL2
								WHERE TD_AL2.Equipment_No = @Equipment_No
									AND TD_AL2.St_Date > @Start_Date
									AND TD_AL2.St_Date <= @End_Date
									AND TD_AL2.Alarm_Time IS NULL
							) AS B
							GROUP BY B.Equipment_No,B.Alarm_Code
					)
				) AS C
				GROUP BY C.Equipment_No,C.Alarm_Code
			) AS D LEFT JOIN TM_ALARM_NAME AS TM_AL ON D.Equipment_No = TM_AL.Equipment_No AND D.Alarm_Code = TM_AL.Alarm_Code
			WHERE TM_AL.Lang_Mode = @Lang_Mode
			GROUP BY D.Equipment_No

			--カーソルのOPEN
			OPEN ERR_TIME

			--行の取り出し
			FETCH NEXT FROM ERR_TIME INTO @tmpInt1

			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					--データの格納
					SET @Error_Time = @tmpInt1

					--行の移動
					FETCH NEXT FROM ERR_TIME INTO @tmpInt1
				END

			--カーソルを閉じる
			CLOSE ERR_TIME
			DEALLOCATE ERR_TIME

			--******************************************************
			--               稼働状態の取得
			--******************************************************
			DECLARE @CountFlg AS int
			DECLARE @AddTime AS int
			DECLARE @Old_Date AS datetime
			DECLARE @Old_Status AS int
			DECLARE @Old_GetFlg AS int
			DECLARE @NULL_GetFlg AS int
			DECLARE @NULL_GetDate as datetime
			DECLARE @NULL_State as int

			DECLARE STAT_VAL CURSOR FOR
			SELECT *
			FROM (
				SELECT TD_ST1.Equipment_No,TD_ST1.Collect_Date,TD_ST1.Status_No,TD_ST1.Status_Time
				FROM (
					SELECT Equipment_No,MAX(Row_No) AS Row_No
					FROM TD_COLLECT_STATUS
					WHERE Equipment_No = @Equipment_No
						AND Collect_Date <= @Start_Date
					Group BY Equipment_No
				) AS A LEFT JOIN TD_COLLECT_STATUS AS TD_ST1 ON A.Row_No = TD_ST1.Row_No
				UNION 
				SELECT TD_ST2.Equipment_No,TD_ST2.Collect_Date,TD_ST2.Status_No,TD_ST2.Status_Time
				FROM TD_COLLECT_STATUS AS TD_ST2
				WHERE TD_ST2.Equipment_No = @Equipment_No
					AND Collect_Date > @Start_Date AND Collect_Date <= @End_Date
			) AS B
			ORDER BY B.Equipment_No ASC,B.Collect_Date ASC			

			--カーソルのOPEN
			OPEN STAT_VAL

			--行の取り出し
			FETCH NEXT FROM STAT_VAL INTO @tmpInt1,@tmpDate,@tmpInt2,@tmpInt3

			--ループ処理
			WHILE (@@FETCH_STATUS = 0)
				BEGIN
					--初期化
					SET @CountFlg = 0
					SET @AddTime = 0

					--前回取込んだ値がNULLの場合、その差分を実績値として加算する
					IF(@NULL_GetFlg = 1)
						BEGIN
							--該当状態の終了時刻までを書込む
							SET @AddTime = DATEDIFF(second,@NULL_GetDate,@tmpDate)
							SET @CountFlg = 1

							--状態に応じて書込み先を変更
							IF(@NULL_State = 0)
								BEGIN
									--回数の追加
									SET @Status_Count0 = @Status_Count0 + @CountFlg
									--時間の追加
									SET @Status_Time0 = @Status_Time0 + @AddTime
								END
							ELSE IF(@NULL_State = 1)
								BEGIN
									--回数の追加
									SET @Status_Count1 = @Status_Count1 + @CountFlg
									--時間の追加
									SET @Status_Time1 = @Status_Time1 + @AddTime
								END
							ELSE IF(@NULL_State = 2)
								BEGIN
									--回数の追加
									SET @Status_Count2 = @Status_Count2 + @CountFlg
									--時間の追加
									SET @Status_Time2 = @Status_Time2 + @AddTime
								END
							ELSE IF(@NULL_State = 3)
								BEGIN
									--回数の追加
									SET @Status_Count3 = @Status_Count3 + @CountFlg
									--時間の追加
									SET @Status_Time3 = @Status_Time3 + @AddTime
								END
							ELSE IF(@NULL_State = 4)
								BEGIN
									--回数の追加
									SET @Status_Count4 = @Status_Count4 + @CountFlg
									--時間の追加
									SET @Status_Time4 = @Status_Time4 + @AddTime
								END
							ELSE IF(@NULL_State = 5)
								BEGIN
									--回数の追加
									SET @Status_Count5 = @Status_Count5 + @CountFlg
									--時間の追加
									SET @Status_Time5 = @Status_Time5 + @AddTime
								END
							ELSE IF(@NULL_State = 6)
								BEGIN
									--回数の追加
									SET @Status_Count6 = @Status_Count6 + @CountFlg
									--時間の追加
									SET @Status_Time6 = @Status_Time6 + @AddTime
								END
							ELSE IF(@NULL_State = 7)
								BEGIN
									--回数の追加
									SET @Status_Count7 = @Status_Count7 + @CountFlg
									--時間の追加
									SET @Status_Time7 = @Status_Time7 + @AddTime
								END
							ELSE IF(@NULL_State = 8)
								BEGIN
									--回数の追加
									SET @Status_Count8 = @Status_Count8 + @CountFlg
									--時間の追加
									SET @Status_Time8 = @Status_Time8 + @AddTime
								END
							ELSE IF(@NULL_State = 9)
								BEGIN
									--回数の追加
									SET @Status_Count9 = @Status_Count9 + @CountFlg
									--時間の追加
									SET @Status_Time9 = @Status_Time9 + @AddTime
								END
							--書込み完了後、フラグを初期化
							SET @NULL_GetFlg = 0

							--初期化
							SET @CountFlg = 0
							SET @AddTime = 0

						END

					--開始時刻以前のデータ確認
					IF(@Old_GetFlg = 1)
						BEGIN
							--開始時刻以前からのデータを加算
							SET @CountFlg = 1
							SET @AddTime = DATEDIFF(second,@Start_Date,@tmpDate)

							--取得した日付が過去の場合、値を初期化
							IF(@Start_Date > @tmpDate)
								BEGIN
									--過去の値になるため、演算値を初期化
									SET @CountFlg = 0
									SET @AddTime = 0

								END

							--状態に応じて書込み先を変更
							IF(@Old_Status = 0)
								BEGIN
									--回数の追加
									SET @Status_Count0 = @Status_Count0 + @CountFlg
									--時間の追加
									SET @Status_Time0 = @Status_Time0 + @AddTime
								END
							ELSE IF(@Old_Status = 1)
								BEGIN
									--回数の追加
									SET @Status_Count1 = @Status_Count1 + @CountFlg
									--時間の追加
									SET @Status_Time1 = @Status_Time1 + @AddTime
								END
							ELSE IF(@Old_Status = 2)
								BEGIN
									--回数の追加
									SET @Status_Count2 = @Status_Count2 + @CountFlg
									--時間の追加
									SET @Status_Time2 = @Status_Time2 + @AddTime
								END
							ELSE IF(@Old_Status = 3)
								BEGIN
									--回数の追加
									SET @Status_Count3 = @Status_Count3 + @CountFlg
									--時間の追加
									SET @Status_Time3 = @Status_Time3 + @AddTime
								END
							ELSE IF(@Old_Status = 4)
								BEGIN
									--回数の追加
									SET @Status_Count4 = @Status_Count4 + @CountFlg
									--時間の追加
									SET @Status_Time4 = @Status_Time4 + @AddTime
								END
							ELSE IF(@Old_Status = 5)
								BEGIN
									--回数の追加
									SET @Status_Count5 = @Status_Count5 + @CountFlg
									--時間の追加
									SET @Status_Time5 = @Status_Time5 + @AddTime
								END
							ELSE IF(@Old_Status = 6)
								BEGIN
									--回数の追加
									SET @Status_Count6 = @Status_Count6 + @CountFlg
									--時間の追加
									SET @Status_Time6 = @Status_Time6 + @AddTime
								END
							ELSE IF(@Old_Status = 7)
								BEGIN
									--回数の追加
									SET @Status_Count7 = @Status_Count7 + @CountFlg
									--時間の追加
									SET @Status_Time7 = @Status_Time7 + @AddTime
								END
							ELSE IF(@Old_Status = 8)
								BEGIN
									--回数の追加
									SET @Status_Count8 = @Status_Count8 + @CountFlg
									--時間の追加
									SET @Status_Time8 = @Status_Time8 + @AddTime
								END
							ELSE IF(@Old_Status = 9)
								BEGIN
									--回数の追加
									SET @Status_Count9 = @Status_Count9 + @CountFlg
									--時間の追加
									SET @Status_Time9 = @Status_Time9 + @AddTime
								END
							--値を初期化
							SET @CountFlg = 0
							SET @AddTime = 0

							--フラグを更新
							SET @Old_GetFlg = 2
						END

					--取得した日時が開始時刻以前かをチェック
					IF(@tmpDate <= @Start_Date)
						BEGIN
							--前回値を記録
							SET @Old_Date = @tmpDate
							SET @Old_Status = @tmpInt2
							--フラグを更新
							SET @Old_GetFlg = 1
						END
					ELSE
						BEGIN
							--取得した項目の状態変化時間のNULLチェック
							IF(@tmpInt3 IS NULL)
								BEGIN
									--NULLフラグを設定
									SET @NULL_GetFlg = 1
									--NULLだった値を設定
									SET @NULL_GetDate = @tmpDate
									SET @NULL_State = @tmpInt2
									--初期化
									SET @CountFlg = 0
									SET @AddTime = 0
	
								END
							ELSE
								BEGIN
									--該当状態の終了時間が表示範囲内かをチェック
									IF(@End_Date >= DATEADD(second,@tmpInt3,@tmpDate))
										BEGIN
											--状態変化時間をそのまま書込み
											SET @CountFlg = 1
											SET @AddTime = @tmpInt3
										END
									ELSE
										BEGIN
											--NULLフラグを設定
											SET @NULL_GetFlg = 1
											--NULLだった値を設定
											SET @NULL_GetDate = @tmpDate
											SET @NULL_State = @tmpInt2
											--初期化
											SET @CountFlg = 0
											SET @AddTime = 0
										END									
								END
						END

					--状態に応じて書込み先を変更
					IF(@tmpInt2 = 0)
						BEGIN
							--回数の追加
							SET @Status_Count0 = @Status_Count0 + @CountFlg
							--時間の追加
							SET @Status_Time0 = @Status_Time0 + @AddTime
						END
					ELSE IF(@tmpInt2 = 1)
						BEGIN
							--回数の追加
							SET @Status_Count1 = @Status_Count1 + @CountFlg
							--時間の追加
							SET @Status_Time1 = @Status_Time1 + @AddTime
						END
					ELSE IF(@tmpInt2 = 2)
						BEGIN
							--回数の追加
							SET @Status_Count2 = @Status_Count2 + @CountFlg
							--時間の追加
							SET @Status_Time2 = @Status_Time2 + @AddTime
						END
					ELSE IF(@tmpInt2 = 3)
						BEGIN
							--回数の追加
							SET @Status_Count3 = @Status_Count3 + @CountFlg
							--時間の追加
							SET @Status_Time3 = @Status_Time3 + @AddTime
						END
					ELSE IF(@tmpInt2 = 4)
						BEGIN
							--回数の追加
							SET @Status_Count4 = @Status_Count4 + @CountFlg
							--時間の追加
							SET @Status_Time4 = @Status_Time4 + @AddTime
						END
					ELSE IF(@tmpInt2 = 5)
						BEGIN
							--回数の追加
							SET @Status_Count5 = @Status_Count5 + @CountFlg
							--時間の追加
							SET @Status_Time5 = @Status_Time5 + @AddTime
						END
					ELSE IF(@tmpInt2 = 6)
						BEGIN
							--回数の追加
							SET @Status_Count6 = @Status_Count6 + @CountFlg
							--時間の追加
							SET @Status_Time6 = @Status_Time6 + @AddTime
						END
					ELSE IF(@tmpInt2 = 7)
						BEGIN
							--回数の追加
							SET @Status_Count7 = @Status_Count7 + @CountFlg
							--時間の追加
							SET @Status_Time7 = @Status_Time7 + @AddTime
						END
					ELSE IF(@tmpInt2 = 8)
						BEGIN
							--回数の追加
							SET @Status_Count8 = @Status_Count8 + @CountFlg
							--時間の追加
							SET @Status_Time8 = @Status_Time8 + @AddTime
						END
					ELSE IF(@tmpInt2 = 9)
						BEGIN
							--回数の追加
							SET @Status_Count9 = @Status_Count9 + @CountFlg
							--時間の追加
							SET @Status_Time9 = @Status_Time9 + @AddTime
						END

					--行の移動
					FETCH NEXT FROM STAT_VAL INTO @tmpInt1,@tmpDate,@tmpInt2,@tmpInt3
				END

			--カーソルを閉じる
			CLOSE STAT_VAL
			DEALLOCATE STAT_VAL

			--フラグ残りチェック
			IF(@Old_GetFlg = 1)
				BEGIN
					--表示範囲にて稼働状態の変化がなかったため、表示範囲の時間を
					--該当するステータスに加算
					SET @CountFlg = 1
					SET @AddTime = DATEDIFF(second,@Start_Date,@End_Date)

					--状態に応じて書込み先を変更
					IF(@Old_Status = 0)
						BEGIN
							--回数の追加
							SET @Status_Count0 = @Status_Count0 + @CountFlg
							--時間の追加
							SET @Status_Time0 = @Status_Time0 + @AddTime
						END
					ELSE IF(@Old_Status = 1)
						BEGIN
							--回数の追加
							SET @Status_Count1 = @Status_Count1 + @CountFlg
							--時間の追加
							SET @Status_Time1 = @Status_Time1 + @AddTime
						END
					ELSE IF(@Old_Status = 2)
						BEGIN
							--回数の追加
							SET @Status_Count2 = @Status_Count2 + @CountFlg
							--時間の追加
							SET @Status_Time2 = @Status_Time2 + @AddTime
						END
					ELSE IF(@Old_Status = 3)
						BEGIN
							--回数の追加
							SET @Status_Count3 = @Status_Count3 + @CountFlg
							--時間の追加
							SET @Status_Time3 = @Status_Time3 + @AddTime
						END
					ELSE IF(@Old_Status = 4)
						BEGIN
							--回数の追加
							SET @Status_Count4 = @Status_Count4 + @CountFlg
							--時間の追加
							SET @Status_Time4 = @Status_Time4 + @AddTime
						END
					ELSE IF(@Old_Status = 5)
						BEGIN
							--回数の追加
							SET @Status_Count5 = @Status_Count5 + @CountFlg
							--時間の追加
							SET @Status_Time5 = @Status_Time5 + @AddTime
						END
					ELSE IF(@Old_Status = 6)
						BEGIN
							--回数の追加
							SET @Status_Count6 = @Status_Count6 + @CountFlg
							--時間の追加
							SET @Status_Time6 = @Status_Time6 + @AddTime
						END
					ELSE IF(@Old_Status = 7)
						BEGIN
							--回数の追加
							SET @Status_Count7 = @Status_Count7 + @CountFlg
							--時間の追加
							SET @Status_Time7 = @Status_Time7 + @AddTime
						END
					ELSE IF(@Old_Status = 8)
						BEGIN
							--回数の追加
							SET @Status_Count8 = @Status_Count8 + @CountFlg
							--時間の追加
							SET @Status_Time8 = @Status_Time8 + @AddTime
						END
					ELSE IF(@Old_Status = 9)
						BEGIN
							--回数の追加
							SET @Status_Count9 = @Status_Count9 + @CountFlg
							--時間の追加
							SET @Status_Time9 = @Status_Time9 + @AddTime
						END
					--書込み完了後、フラグを初期化
					SET @Old_GetFlg = 0
				END
			--NULLデータ取得チェック
			IF(@NULL_GetFlg = 1)
				BEGIN
					--該当状態の終了時刻までを書込む
					SET @AddTime = DATEDIFF(second,@NULL_GetDate,@End_Date)
					SET @CountFlg = 1

					--状態に応じて書込み先を変更
					IF(@NULL_State = 0)
						BEGIN
							--回数の追加
							SET @Status_Count0 = @Status_Count0 + @CountFlg
							--時間の追加
							SET @Status_Time0 = @Status_Time0 + @AddTime
						END
					ELSE IF(@NULL_State = 1)
						BEGIN
							--回数の追加
							SET @Status_Count1 = @Status_Count1 + @CountFlg
							--時間の追加
							SET @Status_Time1 = @Status_Time1 + @AddTime
						END
					ELSE IF(@NULL_State = 2)
						BEGIN
							--回数の追加
							SET @Status_Count2 = @Status_Count2 + @CountFlg
							--時間の追加
							SET @Status_Time2 = @Status_Time2 + @AddTime
						END
					ELSE IF(@NULL_State = 3)
						BEGIN
							--回数の追加
							SET @Status_Count3 = @Status_Count3 + @CountFlg
							--時間の追加
							SET @Status_Time3 = @Status_Time3 + @AddTime
						END
					ELSE IF(@NULL_State = 4)
						BEGIN
							--回数の追加
							SET @Status_Count4 = @Status_Count4 + @CountFlg
							--時間の追加
							SET @Status_Time4 = @Status_Time4 + @AddTime
						END
					ELSE IF(@NULL_State = 5)
						BEGIN
							--回数の追加
							SET @Status_Count5 = @Status_Count5 + @CountFlg
							--時間の追加
							SET @Status_Time5 = @Status_Time5 + @AddTime
						END
					ELSE IF(@NULL_State = 6)
						BEGIN
							--回数の追加
							SET @Status_Count6 = @Status_Count6 + @CountFlg
							--時間の追加
							SET @Status_Time6 = @Status_Time6 + @AddTime
						END
					ELSE IF(@NULL_State = 7)
						BEGIN
							--回数の追加
							SET @Status_Count7 = @Status_Count7 + @CountFlg
							--時間の追加
							SET @Status_Time7 = @Status_Time7 + @AddTime
						END
					ELSE IF(@NULL_State = 8)
						BEGIN
							--回数の追加
							SET @Status_Count8 = @Status_Count8 + @CountFlg
							--時間の追加
							SET @Status_Time8 = @Status_Time8 + @AddTime
						END
					ELSE IF(@NULL_State = 9)
						BEGIN
							--回数の追加
							SET @Status_Count9 = @Status_Count9 + @CountFlg
							--時間の追加
							SET @Status_Time9 = @Status_Time9 + @AddTime
						END
					--書込み完了後、フラグを初期化
					SET @NULL_GetFlg = 0

				END
			
			--データのインサート
			INSERT INTO @retTbl VALUES (
				@Equipment_No,
				@Equipment_Name,
				@Equipment_Unit,
				@Error_Count,
				@Error_Time,
				@Status_Count0,@Status_Time0,
				@Status_Count1,@Status_Time1,
				@Status_Count2,@Status_Time2,
				@Status_Count3,@Status_Time3,
				@Status_Count4,@Status_Time4,
				@Status_Count5,@Status_Time5,
				@Status_Count6,@Status_Time6,
				@Status_Count7,@Status_Time7,
				@Status_Count8,@Status_Time8,
				@Status_Count9,@Status_Time9
			)

			--行の移動
			FETCH NEXT FROM EQU_VAL INTO @tmpEquNo,@tmpEquName,@tmpUnit
		END

	--カーソルを閉じる
	CLOSE EQU_VAL
	DEALLOCATE EQU_VAL

Proc_End:

	RETURN
END

go

